# Braseiro — Aventuras importáveis e Legado Permanente V1

Primeiro núcleo reutilizável do sistema universal de importação de aventuras JSON e continuidade de personagens. **Artefato isolado para integração; nenhum VTT foi atualizado ainda.**

## Conteúdo

- `src/legacy-engine.mjs`: biblioteca JS determinística sem dependências externas.
- `examples/a-maldicao-de-karvath.json`: exemplo original de aventura com história, segredos GM, inimigos ligados ao catálogo, locais, encontros, objetivos e consequências possíveis.
- `tests/legacy-engine.test.mjs`: 20 testes unitários.
- `examples/demo-persistencia.mjs`: demonstração com salvamento e reabertura após troca de aventura.
- `docs/ORDEM_DE_INTEGRACAO_TODOS_VTTS.md`: ordem de integração, regras de persistência, arquitetura, UX, diferenças entre sistemas e gates de aceite.

## Executar testes

Requer Node.js 20+:

```sh
node --test tests/*.test.mjs
```

## Uso resumido

```js
import fs from 'node:fs';
import { createLegacyStore, beginAdventure, applyVerifiedEvent, finishAdventure, buildCharacterLegacyContext } from './src/legacy-engine.mjs';
const adventure = JSON.parse(fs.readFileSync('./examples/a-maldicao-de-karvath.json','utf8'));
let store = createLegacyStore({system:'dnd5e-2024',worldId:'faerun-campanha-principal'});
store = beginAdventure(store, adventure, ['garrick']);
// Só chame applyVerifiedEvent quando o host confirmar um acontecimento real.
// Salve store em transação nativa após cada alteração.
```

`verifiedByHost: true` deve ser fornecido apenas pelo código confiável de regras do VTT; não aceite essa confirmação do arquivo importado nem da resposta do Gemini. Armazenamento nativo, tela de importação e integração com cada jogo são etapas pendentes.

Demonstração de preservação do legado após salvar e reabrir:

```sh
node examples/demo-persistencia.mjs
```
