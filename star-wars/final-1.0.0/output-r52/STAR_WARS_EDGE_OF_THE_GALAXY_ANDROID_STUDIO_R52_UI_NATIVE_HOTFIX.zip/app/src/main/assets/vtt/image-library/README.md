# Star Wars Image Library V3.8

- Manifesto: `3.8.0`
- Assets indexados: **369**
- Locais/offline: **148**
- Externos Kainrath: **221**
- Mapas: **18**
- NPCs: **37**
- Droides: **23**
- Criaturas: **17**
- Veículos/naves: **127**

R45 adiciona 7 referências visuais de veículos com URL direta comprovada: **Arunskin 32 Cargo Skiff, XP-291 Skimmer, Starhawk Speeder Bike, 85-XS Odyssey Heavy Speeder Bike, Ubrikkian 9000 Z001 Landspeeder, 00-3 Kravaan Medium Freighter e 431 Hauler Cargo Tug**. Todas permanecem `mechanicalBinding=null`, com cache explícito sob demanda. Nenhum filename, estatística ou mecânica foi inferido.

## R46 — Provenance freeze
The validated V3.8 subset is considered runtime-ready at 369 indexed assets. Remaining Kainrath posts without a directly observed `/wp-content/uploads/` media URL are deferred optional visual extensions and do not block gameplay. No remote filename is guessed; no mechanics are inferred from visual media. See `R46_KAINRATH_PROVENANCE_FREEZE.json`.
