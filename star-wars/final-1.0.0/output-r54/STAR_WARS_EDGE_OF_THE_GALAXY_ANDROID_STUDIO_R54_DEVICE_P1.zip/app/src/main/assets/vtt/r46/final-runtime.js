(function(){
'use strict';
const PREF_KEY='braseiro.starwars.ui.preferences.v1';
const defaults={textScale:'100',highContrast:false,reducedMotion:false,ttsEnabled:true,ttsRate:'1',ttsProvider:'android',geminiVoice:'Kore'};
const safeParse=(v,f)=>{try{return JSON.parse(v)}catch{return f}};
const prefs={...defaults,...safeParse(localStorage.getItem(PREF_KEY),{})};
function save(){try{localStorage.setItem(PREF_KEY,JSON.stringify(prefs))}catch{}}
function applyPrefs(){
 const root=document.documentElement;
 root.classList.toggle('braseiro-text-110',prefs.textScale==='110');
 root.classList.toggle('braseiro-text-120',prefs.textScale==='120');
 root.classList.toggle('braseiro-high-contrast',!!prefs.highContrast);
 root.classList.toggle('braseiro-reduced-motion',!!prefs.reducedMotion);
}
applyPrefs();
function nativeStatus(){
 const b=window.BraseiroTts;
 if(!b||typeof b.getStatus!=='function')return {available:false,detail:'Bridge TTS Android indisponível.'};
 try{return safeParse(b.getStatus(),{available:false,detail:'Resposta TTS inválida.'})}catch{return {available:false,detail:'Falha ao consultar TTS.'}}
}
function narrationText(){
 const host=document.querySelector('.scene-narrative-paper:not(.scene-narrative-reader) .scene-paper-copy');
 return String(host?.textContent||'').replace(/\s+/g,' ').trim();
}
function geminiStatus(){
 const b=window.BraseiroGemini;if(!b||typeof b.getStatus!=='function')return {available:false,configured:false};
 try{return {...safeParse(b.getStatus(),{}),available:true}}catch{return {available:true,configured:false}}
}
function speak(text){
 if(!prefs.ttsEnabled)return {ok:false,message:'TTS desativado em Ajustes.'};
 const clean=String(text||'').trim();
 if(!clean)return {ok:false,message:'Não há narração visível para ler.'};
 if(prefs.ttsProvider==='gemini'){
  const g=window.BraseiroGemini;
  if(g&&typeof g.speakTts==='function'){
   try{const r=safeParse(g.speakTts(clean,String(prefs.geminiVoice||'Kore')),{ok:false,message:'Resposta Gemini TTS inválida.'});if(r&&r.ok)return r;return r||{ok:false,message:'Gemini TTS indisponível.'}}catch{}
  }
 }
 const b=window.BraseiroTts;
 if(b&&typeof b.speak==='function'){
  try{return safeParse(b.speak(clean,String(prefs.ttsRate||'1')),{ok:false,message:'Resposta TTS inválida.'})}catch{return {ok:false,message:'Falha ao iniciar TTS Android.'}}
 }
 if('speechSynthesis' in window && 'SpeechSynthesisUtterance' in window){
  try{window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(clean);u.lang='pt-BR';u.rate=Math.max(.6,Math.min(1.4,Number(prefs.ttsRate)||1));window.speechSynthesis.speak(u);return {ok:true,fallback:true}}catch{}
 }
 return {ok:false,message:'TTS não está disponível neste dispositivo.'};
}
function stop(){
 const g=window.BraseiroGemini;if(g&&typeof g.stopTts==='function'){try{g.stopTts()}catch{}}
 const b=window.BraseiroTts;if(b&&typeof b.stop==='function'){try{b.stop()}catch{}}
 try{window.speechSynthesis?.cancel()}catch{}
 return {ok:true};
}
function speakerSvg(){return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 10v4h4l5 4V6L8 10z"/><path d="M16.5 9c1.7 1.8 1.7 4.2 0 6M19 6.5c3.4 3.2 3.4 7.8 0 11"/></svg>'}
function enhanceNarration(){
 document.querySelectorAll('.scene-narrative-paper:not(.scene-narrative-reader) .scene-narrative-heading-row').forEach(row=>{
  if(row.querySelector('.scene-narrative-tts-button'))return;
  const btn=document.createElement('button');btn.type='button';btn.className='scene-narrative-tts-button';btn.setAttribute('aria-label','Ouvir narração do Mestre');btn.title='Ouvir narração do Mestre';btn.innerHTML=speakerSvg();
  btn.addEventListener('click',()=>{const r=speak(narrationText());btn.setAttribute('aria-pressed',r&&r.ok?'true':'false');setTimeout(()=>btn.setAttribute('aria-pressed','false'),900)});
  const expand=row.querySelector('.scene-narrative-expand-button');row.insertBefore(btn,expand||null);
 });
}
function cardByTitle(title){
 return [...document.querySelectorAll('section')].find(s=>{
  const first=s.firstElementChild;return first&&String(first.textContent||'').trim()===title;
 });
}
function enhanceAccessibility(){
 const card=cardByTitle('Interface');if(!card||card.dataset.finalEnhanced==='1')return;
 card.dataset.finalEnhanced='1';const content=card.children[1];if(!content)return;
 content.innerHTML=`<div class="final-settings-grid">
 <div class="final-setting-row"><label for="final-text-scale">Escala de texto</label><select id="final-text-scale"><option value="100">100%</option><option value="110">110%</option><option value="120">120%</option></select></div>
 <div class="final-setting-row"><span>Alto contraste</span><input id="final-high-contrast" type="checkbox" aria-label="Alto contraste"></div>
 <div class="final-setting-row"><span>Reduzir movimento</span><input id="final-reduced-motion" type="checkbox" aria-label="Reduzir movimento"></div>
 <div class="final-setting-status">Preferências salvas localmente neste aparelho.</div></div>`;
 const scale=content.querySelector('#final-text-scale'), contrast=content.querySelector('#final-high-contrast'), motion=content.querySelector('#final-reduced-motion');
 scale.value=prefs.textScale;contrast.checked=!!prefs.highContrast;motion.checked=!!prefs.reducedMotion;
 scale.addEventListener('change',()=>{prefs.textScale=scale.value;save();applyPrefs()});
 contrast.addEventListener('change',()=>{prefs.highContrast=contrast.checked;save();applyPrefs()});
 motion.addEventListener('change',()=>{prefs.reducedMotion=motion.checked;save();applyPrefs()});
}
function bridgeResult(name,...args){
 const b=window.BraseiroGameBridge;
 if(!b||typeof b[name]!=='function')return {ok:false,error:'BRIDGE_UNAVAILABLE',message:'Motor Barbara indisponível.'};
 try{const r=b[name](...args);return r&&typeof r==='object'?r:{ok:false,error:'INVALID_BRIDGE',message:'Resposta inválida do Motor Barbara.'}}catch(e){return {ok:false,error:'ENGINE_REJECTED',message:String(e&&e.message||e||'Falha no Motor Barbara.')}}
}
function playerView(){
 const r=bridgeResult('scenePlayerView');
 return r&&r.ok?r.data:null;
}
function controlledText(el,value){
 if(!el)return;
 const proto=window.HTMLTextAreaElement&&window.HTMLTextAreaElement.prototype;
 const setter=proto&&Object.getOwnPropertyDescriptor(proto,'value')?.set;
 if(setter)setter.call(el,String(value??''));else el.value=String(value??'');
 el.dispatchEvent(new Event('input',{bubbles:true}));
 el.focus();
}
function initials(name){return String(name||'').trim().split(/\s+/).slice(0,2).map(x=>x[0]||'').join('').toUpperCase()||'•'}
function skillLabel(key){
 const map={actividad_criminal:'Atividade criminosa',aguante:'Resistência',alerta:'Alerta',astronavegacion:'Astronavegação',atletismo:'Atletismo',callejeo:'Vida nas ruas',carisma:'Carisma',coaccion:'Coerção',computadoras:'Computadores',conocimientos:'Conhecimentos',coordinacion:'Coordenação',disciplina:'Disciplina',engano:'Enganação',frialdad:'Frieza',liderazgo:'Liderança',mecanica:'Mecânica',medicina:'Medicina',negociacion:'Negociação',percepcion:'Percepção',pilotar:'Pilotagem',pilotar_vehiculo_espacial:'Pilotagem espacial',pilotar_vehiculo_planetario:'Pilotagem planetária',sigilo:'Furtividade',supervivencia:'Sobrevivência',armas_distancia_ligeras:'Armas de distância leves',armas_distancia_pesadas:'Armas de distância pesadas',armas_cuerpo_a_cuerpo:'Armas corpo a corpo',artilleria:'Artilharia',pelea:'Briga'};
 return map[String(key||'')]||String(key||'Teste').replace(/_/g,' ').replace(/^./,m=>m.toUpperCase());
}
function checkSummary(check){
 if(!check)return '';
 const main=check.success?'SUCESSO':'FALHA';
 const parts=[main,`${Math.abs(Number(check.netSuccess)||0)} ${Number(check.netSuccess)>=0?'sucesso(s) líquido(s)':'falha(s) líquida(s)'}`];
 const adv=Number(check.netAdvantage)||0;if(adv)parts.push(`${Math.abs(adv)} ${adv>0?'vantagem(ns)':'ameaça(s)'}`);
 const tri=Number(check.triumph)||0,des=Number(check.despair)||0;if(tri)parts.push(`${tri} triunfo(s)`);if(des)parts.push(`${des} desespero(s)`);
 return parts.join(' · ');
}
function enhanceSceneFromEngine(){
 const root=document.querySelector('.scene-concept-shell');if(!root)return;
 const view=playerView();if(!view)return;
 const situation=root.querySelector('.scene-situation-paper p');if(situation&&view.situation)situation.textContent=view.situation;
 const participantSlots=[...root.querySelectorAll('.scene-participant-slot')];
 const participants=Array.isArray(view.participants)?view.participants:[];
 participantSlots.forEach((slot,i)=>{
  const p=participants[i],frame=slot.querySelector('.scene-participant-frame'),strong=slot.querySelector('strong'),small=slot.querySelector('small');
  if(p){
   if(frame){frame.classList.remove('is-empty');frame.textContent=initials(p.name);frame.setAttribute('aria-label',`Participante: ${p.name}`)}
   if(strong)strong.textContent=p.name;if(small)small.textContent=p.meta||p.status||'Visível';
  }else{
   if(frame){frame.classList.add('is-empty');frame.innerHTML='<span class="scene-participant-empty-mark" aria-hidden="true"></span>';frame.removeAttribute('aria-label')}
   if(strong)strong.textContent='—';if(small)small.textContent='Aguardando participante';
  }
 });
 const actionSlots=[...root.querySelectorAll('.scene-action-slot')];
 const actions=Array.isArray(view.suggestedActions)?view.suggestedActions.slice(0,6):[];
 actionSlots.forEach((slot,i)=>{
  const action=actions[i],strong=slot.querySelector('strong'),small=slot.querySelector('small'),end=slot.querySelector('.scene-action-empty-end');
  if(action){
   slot.classList.remove('is-empty');slot.classList.add('is-live');slot.setAttribute('role','button');slot.tabIndex=0;slot.setAttribute('aria-label',`Usar ação sugerida: ${action}`);
   if(strong)strong.textContent=action;if(small)small.textContent='Sugestão do Mestre';if(end){end.textContent='›';end.classList.add('scene-action-chevron')}
   const activate=()=>controlledText(root.querySelector('.scene-composer textarea'),action);
   slot.onclick=activate;slot.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();activate()}};
  }else{
   slot.classList.add('is-empty');slot.classList.remove('is-live');slot.removeAttribute('role');slot.removeAttribute('tabindex');slot.removeAttribute('aria-label');slot.onclick=null;slot.onkeydown=null;
   if(strong)strong.textContent='—';if(small)small.textContent='Aguardando ação disponível';if(end){end.textContent='';end.classList.remove('scene-action-chevron')}
  }
 });
 const statusCells=[...root.querySelectorAll('.scene-status-cell')];
 if(statusCells.length&&view.vehicle){
  const vals=[view.vehicle.hull,view.vehicle.strain,view.vehicle.speed,view.vehicle.defense];
  statusCells.forEach((cell,i)=>{const spans=cell.querySelectorAll('.scene-status-copy>span');if(spans[1]){spans[1].textContent=String(vals[i]??'—');spans[1].style.color='#D5D8DC';spans[1].style.fontWeight='800'}});
 }
 const panel=root.querySelector('.scene-actions-panel');
 if(panel){
  let checkBox=panel.querySelector('.final-suggested-check');
  const c=view.suggestedCheck;
  if(c){
   if(!checkBox){checkBox=document.createElement('div');checkBox.className='final-suggested-check';panel.appendChild(checkBox)}
   const diff=Number(c.difficulty||0),chal=Number(c.challenge||0),boost=Number(c.boost||0),setback=Number(c.setback||0);
   checkBox.innerHTML=`<div><strong>${skillLabel(c.skillKey)}</strong><small>${c.reason||'Teste sugerido pelo Mestre'} · D${diff}${chal?` · C${chal}`:''}${boost?` · +${boost} impulso`:''}${setback?` · +${setback} contratempo`:''}</small></div><button type="button">ROLAR</button><output aria-live="polite"></output>`;
   const btn=checkBox.querySelector('button'),out=checkBox.querySelector('output');
   btn.onclick=()=>{btn.disabled=true;out.textContent='Rolando…';const r=bridgeResult('resolveSuggestedMasterCheck');if(r.ok){out.textContent=checkSummary(r.data?.check)||'Teste resolvido.';setTimeout(enhanceSceneFromEngine,0)}else{out.textContent=r.message||'Teste rejeitado pelo motor.';btn.disabled=false}};
  }else if(checkBox){
   const last=view.lastCheck;checkBox.innerHTML=last?`<div><strong>Último teste</strong><small>${checkSummary(last)}</small></div>`:'';
   if(!last)checkBox.remove();
  }
 }
}
function enhanceTtsSettings(){
 const card=cardByTitle('Narração / voz');if(!card||card.dataset.finalEnhanced==='1')return;
 card.dataset.finalEnhanced='1';const content=card.children[1];if(!content)return;
 const st=nativeStatus(),gst=geminiStatus();
 content.innerHTML=`<div class="final-settings-grid">
 <div class="final-setting-row"><span>TTS da narração</span><input id="final-tts-enabled" type="checkbox" aria-label="Ativar TTS da narração"></div>
 <div class="final-setting-row"><label for="final-tts-provider">Provedor</label><select id="final-tts-provider"><option value="android">Android TTS</option><option value="gemini">Gemini TTS</option></select></div>
 <div class="final-setting-row"><label for="final-tts-rate">Velocidade Android</label><select id="final-tts-rate"><option value="0.8">0,8×</option><option value="1">1,0×</option><option value="1.1">1,1×</option><option value="1.2">1,2×</option><option value="1.4">1,4×</option></select></div>
 <div class="final-setting-row"><label for="final-gemini-voice">Voz Gemini</label><select id="final-gemini-voice"><option>Kore</option><option>Aoede</option><option>Charon</option><option>Fenrir</option><option>Puck</option></select></div>
 <div class="final-setting-actions"><button type="button" id="final-tts-test">Testar voz</button><button type="button" id="final-tts-stop">Parar</button></div>
 <div class="final-setting-status" id="final-tts-status"></div></div>`;
 const enabled=content.querySelector('#final-tts-enabled'),provider=content.querySelector('#final-tts-provider'),rate=content.querySelector('#final-tts-rate'),voice=content.querySelector('#final-gemini-voice'),status=content.querySelector('#final-tts-status');
 enabled.checked=!!prefs.ttsEnabled;provider.value=String(prefs.ttsProvider||'android');rate.value=String(prefs.ttsRate||'1');voice.value=String(prefs.geminiVoice||'Kore');
 const refreshStatus=()=>{status.textContent=provider.value==='gemini'?(gst.available?(gst.configured?`Gemini TTS pronto · ${gst.ttsModel||'modelo configurado'}`:'Gemini disponível; configure a chave API na aba Gemini.'):'Bridge Gemini indisponível.'):(st.available?`Android TTS pronto · ${st.language||'pt-BR'}`:(st.detail||'Fallback do WebView será usado se disponível.'))};refreshStatus();
 enabled.addEventListener('change',()=>{prefs.ttsEnabled=enabled.checked;save()});
 provider.addEventListener('change',()=>{prefs.ttsProvider=provider.value;save();refreshStatus()});
 rate.addEventListener('change',()=>{prefs.ttsRate=rate.value;save()});
 voice.addEventListener('change',()=>{prefs.geminiVoice=voice.value;save()});
 content.querySelector('#final-tts-test').addEventListener('click',()=>{const r=speak('Teste de narração do Mestre.');status.textContent=r.ok?(provider.value==='gemini'?'Gemini TTS iniciado.':'Voz reproduzida.'):(r.message||'Não foi possível reproduzir a voz.')});
 content.querySelector('#final-tts-stop').addEventListener('click',()=>{stop();status.textContent='Voz interrompida.'});
 const stateCard=cardByTitle('Estado');if(stateCard){const body=stateCard.children[1];if(body)body.textContent='Somente o texto visível da Narração do Mestre é lido. Android TTS funciona offline quando instalado; Gemini TTS usa a chave configurada no aparelho.'}
}
function campaignMode(){const r=bridgeResult('campaignModeSummary');return r&&r.ok?String(r.data?.campaignMode||'EOTE').toUpperCase():'EOTE'}
function relabelCreationForCampaign(){
 const mode=campaignMode();if(mode!=='AOR')return;
 const replacements=new Map([
  ['Obligation / vínculo de campanha','Duty / vínculo com a Aliança'],['Tipo de Obligation','Tipo de Duty'],['Selecione uma Obligation','Selecione um Duty'],
  ['+5 Obligation → +5 PE','−5 Duty → +5 PE'],['+10 Obligation → +10 PE','−10 Duty → +10 PE'],['+5 Obligation → +1.000 créditos','−5 Duty → +1.000 créditos'],['+10 Obligation → +2.500 créditos','−10 Duty → +2.500 créditos'],
  ['Obligation inicial','Duty inicial'],['Obligation adicional','Duty gasto'],['Obligation final','Duty final'],['Obligation','Duty']
 ]);
 const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;
 while((n=walker.nextNode())){const v=String(n.nodeValue||'').trim();if(replacements.has(v))n.nodeValue=String(n.nodeValue).replace(v,replacements.get(v));}
}
function currentState(){const r=bridgeResult('readState');return r&&r.ok?r.data:null}
function sandboxReady(){const r=bridgeResult('livingSandboxStatus');return Boolean(r&&r.ok&&r.data?.sandbox?.initialized)}
function hasCharacter(){return Boolean(currentState()?.player?.character)}
function adventureStarted(){
 const st=currentState();const n=String(st?.master?.narration||st?.scene?.narration||'').trim();
 if(!n)return false;
 if(/sess[aã]o iniciada.*mestre local|narra[cç][aã]o livre exige provedor|provedor configurado/i.test(n))return false;
 return true;
}
async function startBarbaraOpening(){
 // R54_DEVICE_P0_START: local bootstrap is authoritative and never waits for network.
 const prep=bridgeResult('startLivingAdventure',{});if(!prep?.ok)return prep;
 const game=globalThis.BraseiroGameBridge;
 if(game&&typeof game.submitPlayerIntent==='function'){
  const req=prep.data?.masterOpeningRequest||{};const location=String(req.locationName||'o ponto inicial');
  const opportunity=String(req.opportunity?.summary||req.opportunity?.title||'').trim();
  const npc=String(req.npc?.name||'').trim();const faction=String(req.faction?.name||'').trim();
  const facts=[`Local inicial: ${location}.`,opportunity?`Situação ativa: ${opportunity}.`:'',npc?`NPC conhecido/presente: ${npc}.`:'',faction?`Facção relevante: ${faction}.`:''].filter(Boolean).join(' ');
  const intentText=`[ABERTURA_BARBARA] Inicie a aventura agora como Mestre Barbara. ${facts} Gere a primeira cena a partir do mundo vivo persistente, sem inventar uma missão obrigatória. Não resuma, não escolha nem aja pelo personagem. Narre a situação em português do Brasil conforme o contrato do Mestre e termine deixando a decisão ao jogador.`;
  try{Promise.resolve(game.submitPlayerIntent(intentText)).catch(()=>{});}catch(_){/* offline: campaign remains started */}
 }
 return prep;
}
function navigateRoute(route){const u=new URL(location.href);u.searchParams.set('screen',String(route));history.pushState({},'',u);window.dispatchEvent(new PopStateEvent('popstate'));window.scrollTo(0,0)}
function randomCharacterIdentity(){
 const names=['Nera Vos','Kellan Rook','Syla Venn','Dax Marr','Tarin Vale','Mira Kest','Joren Nox','Kael Sorn','Veya Tann','Rian Korr','Lysa Renn','Bren Tal'];
 const motivations=['Pagar uma dívida sem perder a própria liberdade.','Proteger alguém que ficou para trás.','Encontrar uma oportunidade grande o bastante para mudar de vida.','Descobrir quem sabotou seu antigo grupo.','Construir reputação entre contrabandistas e pilotos.','Ajudar pessoas esmagadas pelo poder do Império.'];
 return {name:names[Math.floor(Math.random()*names.length)],motivation:motivations[Math.floor(Math.random()*motivations.length)]};
}
function quickRandomCharacter(statusEl){const id=randomCharacterIdentity();const r=bridgeResult('generateRandomCharacter',id,{createSnapshot:true});if(!r.ok){if(statusEl)statusEl.textContent=r.message||'Não foi possível gerar a ficha.';return false}if(statusEl)statusEl.textContent=`Ficha criada: ${id.name}.`;setTimeout(enhance,0);return true}
function quickImportCharacter(statusEl){
 const input=document.createElement('input');input.type='file';input.accept='application/json,.json';input.hidden=true;document.body.appendChild(input);
 input.onchange=()=>{const f=input.files?.[0];if(!f){input.remove();return}if(f.size>16*1024*1024){if(statusEl)statusEl.textContent='O JSON excede 16 MB.';input.remove();return}const reader=new FileReader();reader.onload=()=>{const r=bridgeResult('importCharacterJson',String(reader.result||''),{createSnapshot:true});if(statusEl)statusEl.textContent=r.ok?'Ficha importada.':(r.message||'Falha ao importar ficha.');input.remove();setTimeout(enhance,0)};reader.onerror=()=>{if(statusEl)statusEl.textContent='Falha ao ler o arquivo JSON.';input.remove()};reader.readAsText(f)};input.click();
}
const START_POINTS=[{"name":"Coruscant","x":53.4,"y":51.2,"desc":"ecumenopolis","region":"Core Worlds","grid":"L10","key":"coruscant"},{"name":"Alderaan","x":57.8,"y":54.7,"desc":"Core Worlds","region":"Core Worlds","grid":"M10","key":"alderaan"},{"name":"Corellia","x":61.7,"y":50.4,"desc":"Forests, hills, plains","region":"Core Worlds","grid":"N10","key":"corellia"},{"name":"Kashyyyk","x":71.1,"y":46.7,"desc":"Mid Rim","region":"Mid Rim","grid":"Q10","key":"kashyyyk"},{"name":"Naboo","x":76.5,"y":77.1,"desc":"Mid Rim","region":"Mid Rim","grid":"R16","key":"naboo"},{"name":"Tatooine","x":73.2,"y":78.4,"desc":"desert","region":"Outer Rim","grid":"R16","key":"tatooine"},{"name":"Hoth","x":43.6,"y":83.9,"desc":"Outer Rim","region":"Outer Rim","grid":"J18","key":"hoth"},{"name":"Bespin","x":45.1,"y":17.8,"desc":"gas clouds","region":"Outer Rim","grid":"J4","key":"bespin"},{"name":"Dagobah","x":59.0,"y":87.8,"desc":"Outer Rim","region":"Outer Rim","grid":"M18","key":"dagobah"},{"name":"Mustafar","x":51.0,"y":91.1,"desc":"Outer Rim","region":"Outer Rim","grid":"K19","key":"mustafar"},{"name":"Endor","x":37.7,"y":75.6,"desc":"Outer Rim","region":"Outer Rim","grid":"H16","key":"endor"},{"name":"Geonosis","x":78.1,"y":82.2,"desc":"Outer Rim","region":"Outer Rim","grid":"R17","key":"geonosis"},{"name":"Dantooine","x":48.2,"y":16.2,"desc":"Outer Rim","region":"Outer Rim","grid":"K4","key":"dantooine"},{"name":"Mandalore","x":66.8,"y":35.5,"desc":"Outer Rim","region":"Outer Rim","grid":"P7","key":"mandalore"},{"name":"Kessel","x":82.5,"y":48.6,"desc":"alkali flats, mountains, caves","region":"Outer Rim","grid":"S10","key":"kessel"},{"name":"Jakku","x":31.3,"y":61.5,"desc":"Unknown Regions","region":"Unknown Regions","grid":"G13","key":"jakku"},{"name":"Ahch-To","x":29.2,"y":66.2,"desc":"Unknown Regions","region":"Unknown Regions","grid":"F14","key":"ahch_to"},{"name":"Rakata Prime","x":29.8,"y":49.6,"desc":"Unknown Regions","region":"Unknown Regions","grid":"G11","key":"rakata_prime"},{"name":"Mon Calamari","x":94.7,"y":29.4,"desc":"Outer Rim","region":"Outer Rim","grid":"V6","key":"mon_calamari"},{"name":"Ryloth","x":77.1,"y":84.4,"desc":"caves, deserts, mountains, plains","region":"Outer Rim","grid":"R17","key":"ryloth"},{"name":"Montross","x":43.5,"y":9.6,"desc":"Unknown Regions","region":"Unknown Regions","grid":"","key":"montross"},{"name":"Sernpidal","x":52.7,"y":8.1,"desc":"Outer Rim","region":"Outer Rim","grid":"","key":"sernpidal"},{"name":"Birgis","x":54.9,"y":10.6,"desc":"Outer Rim","region":"Outer Rim","grid":"","key":"birgis"},{"name":"Maltha Obex","x":59.9,"y":12.4,"desc":"Unknown Regions","region":"Unknown Regions","grid":"","key":"maltha_obex"},{"name":"Kalee","x":39.9,"y":14.5,"desc":"Outer Rim","region":"Outer Rim","grid":"","key":"kalee"},{"name":"Bimmiel","x":56.6,"y":14.8,"desc":"Outer Rim","region":"Outer Rim","grid":"","key":"bimmiel"},{"name":"Kadavo","x":83.1,"y":15.4,"desc":"Corporate Sector","region":"Corporate Sector","grid":"","key":"kadavo"},{"name":"Naraka","x":74.6,"y":16.1,"desc":"Corporate Sector","region":"Corporate Sector","grid":"","key":"naraka"},{"name":"Rekkiad","x":85.2,"y":16.3,"desc":"Unknown Regions","region":"Unknown Regions","grid":"","key":"rekkiad"},{"name":"Valce","x":40.4,"y":16.7,"desc":"Outer Rim","region":"Outer Rim","grid":"","key":"valce"},{"name":"Akuria","x":55.0,"y":18.3,"desc":"Mid Rim","region":"Mid Rim","grid":"","key":"akuria"},{"name":"Ord Radama","x":72.3,"y":18.3,"desc":"Mid Rim","region":"Mid Rim","grid":"","key":"ord_radama"},{"name":"Dromund Kaas","x":78.2,"y":18.2,"desc":"Unknown Regions","region":"Unknown Regions","grid":"","key":"dromund_kaas"},{"name":"Karkaris","x":83.5,"y":18.4,"desc":"Corporate Sector","region":"Corporate Sector","grid":"","key":"karkaris"},{"name":"Toofa","x":82.8,"y":19.4,"desc":"Corporate Sector","region":"Corporate Sector","grid":"","key":"toofa"},{"name":"Phaeda","x":51.7,"y":24.1,"desc":"Mid Rim","region":"Mid Rim","grid":"","key":"phaeda"},{"name":"Raydonia","x":65.0,"y":23.9,"desc":"Mid Rim","region":"Mid Rim","grid":"","key":"raydonia"},{"name":"Munto Codru","x":88.8,"y":24.1,"desc":"Outer Rim","region":"Outer Rim","grid":"","key":"munto_codru"},{"name":"Ossus","x":79.6,"y":26.4,"desc":"Outer Rim","region":"Outer Rim","grid":"","key":"ossus"},{"name":"Lothal","x":67.0,"y":28.0,"desc":"Outer Rim","region":"Outer Rim","grid":"","key":"lothal"},{"name":"Parnassos","x":36.0,"y":28.0,"desc":"Outer Rim","region":"Outer Rim","grid":"","key":"parnassos"},{"name":"Bogano","x":79.0,"y":31.0,"desc":"Outer Rim","region":"Outer Rim","grid":"","key":"bogano"},{"name":"Garel","x":72.0,"y":31.0,"desc":"Outer Rim","region":"Outer Rim","grid":"","key":"garel"},{"name":"Paatus","x":25.0,"y":31.0,"desc":"Unknown Regions","region":"Unknown Regions","grid":"","key":"paatus"},{"name":"Crustai","x":34.0,"y":33.0,"desc":"Unknown Regions","region":"Unknown Regions","grid":"","key":"crustai"},{"name":"Exegol","x":24.0,"y":34.0,"desc":"Unknown Regions","region":"Unknown Regions","grid":"","key":"exegol"},{"name":"Karthon","x":69.0,"y":34.0,"desc":"Mid Rim","region":"Mid Rim","grid":"","key":"karthon"},{"name":"Toongl","x":85.0,"y":35.0,"desc":"Outer Rim","region":"Outer Rim","grid":"","key":"toongl"},{"name":"Targonn","x":91.0,"y":35.0,"desc":"Outer Rim","region":"Outer Rim","grid":"","key":"targonn"},{"name":"Avidich","x":20.0,"y":38.0,"desc":"Unknown Regions","region":"Unknown Regions","grid":"","key":"avidich"},{"name":"Naporar","x":27.0,"y":38.0,"desc":"Unknown Regions","region":"Unknown Regions","grid":"","key":"naporar"},{"name":"Brask Oto","x":32.0,"y":38.0,"desc":"Unknown Regions","region":"Unknown Regions","grid":"","key":"brask_oto"},{"name":"Schesa","x":27.0,"y":42.0,"desc":"Unknown Regions","region":"Unknown Regions","grid":"","key":"schesa"},{"name":"Gand","x":83.0,"y":42.0,"desc":"Outer Rim","region":"Outer Rim","grid":"","key":"gand"},{"name":"Centrality","x":91.0,"y":42.0,"desc":"Outer Rim","region":"Outer Rim","grid":"","key":"centrality"},{"name":"Csilla","x":23.0,"y":45.0,"desc":"Unknown Regions","region":"Unknown Regions","grid":"","key":"csilla"},{"name":"Jamiron","x":27.0,"y":45.0,"desc":"Unknown Regions","region":"Unknown Regions","grid":"","key":"jamiron"},{"name":"Shantipole","x":80.0,"y":45.0,"desc":"Outer Rim","region":"Outer Rim","grid":"","key":"shantipole"},{"name":"Renatasia","x":90.0,"y":45.0,"desc":"Outer Rim","region":"Outer Rim","grid":"","key":"renatasia"},{"name":"Kinoss","x":22.0,"y":48.0,"desc":"Unknown Regions","region":"Unknown Regions","grid":"","key":"kinoss"},{"name":"Pesfari","x":31.0,"y":48.0,"desc":"Unknown Regions","region":"Unknown Regions","grid":"","key":"pesfari"},{"name":"Jetha","x":43.0,"y":50.0,"desc":"Mid Rim","region":"Mid Rim","grid":"","key":"jetha"},{"name":"Vakkar","x":46.0,"y":50.0,"desc":"Mid Rim","region":"Mid Rim","grid":"","key":"vakkar"},{"name":"Borleias","x":57.0,"y":51.0,"desc":"Core Worlds","region":"Core Worlds","grid":"","key":"borleias"},{"name":"Castell","x":66.0,"y":53.0,"desc":"Core Worlds","region":"Core Worlds","grid":"","key":"castell"},{"name":"Corulag","x":71.0,"y":53.0,"desc":"Core Worlds","region":"Core Worlds","grid":"","key":"corulag"},{"name":"Caamas","x":76.0,"y":53.0,"desc":"Core Worlds","region":"Core Worlds","grid":"","key":"caamas"},{"name":"Bardram Scott","x":60.0,"y":57.0,"desc":"Core Worlds","region":"Core Worlds","grid":"","key":"bardram_scott"},{"name":"Nikardun","x":29.0,"y":58.0,"desc":"Core Worlds","region":"Core Worlds","grid":"","key":"nikardun"},{"name":"Zakuul","x":39.0,"y":57.0,"desc":"Unknown Regions","region":"Unknown Regions","grid":"","key":"zakuul"},{"name":"Wortan","x":43.0,"y":60.0,"desc":"Core Worlds","region":"Core Worlds","grid":"","key":"wortan"},{"name":"Aargau","x":51.0,"y":59.0,"desc":"Core Worlds","region":"Core Worlds","grid":"","key":"aargau"},{"name":"Kattada","x":66.0,"y":59.0,"desc":"Core Worlds","region":"Core Worlds","grid":"","key":"kattada"},{"name":"Fedalle","x":59.0,"y":62.0,"desc":"Core Worlds","region":"Core Worlds","grid":"","key":"fedalle"},{"name":"Vulpter","x":48.0,"y":62.0,"desc":"Core Worlds","region":"Core Worlds","grid":"","key":"vulpter"},{"name":"Balmorra","x":62.0,"y":63.0,"desc":"Core Worlds","region":"Core Worlds","grid":"","key":"balmorra"},{"name":"Tython","x":49.0,"y":65.0,"desc":"Core Worlds","region":"Core Worlds","grid":"","key":"tython"},{"name":"Sarapin","x":53.0,"y":65.0,"desc":"Core Worlds","region":"Core Worlds","grid":"","key":"sarapin"},{"name":"Gatalenta","x":57.0,"y":65.0,"desc":"Core Worlds","region":"Core Worlds","grid":"","key":"gatalenta"},{"name":"Humbarine","x":56.0,"y":68.0,"desc":"Core Worlds","region":"Core Worlds","grid":"","key":"humbarine"},{"name":"Commenor","x":67.0,"y":68.0,"desc":"Core Worlds","region":"Core Worlds","grid":"","key":"commenor"},{"name":"Rapacc","x":26.0,"y":69.0,"desc":"Unknown Regions","region":"Unknown Regions","grid":"","key":"rapacc"}];
function setupOverlay(){
 if(document.getElementById('braseiro-sandbox-setup')||sandboxReady())return;
 const modeResult=bridgeResult('campaignModeSummary');if(!modeResult.ok)return;
 const host=document.createElement('div');host.id='braseiro-sandbox-setup';host.setAttribute('role','dialog');host.setAttribute('aria-modal','true');host.setAttribute('aria-label','Configurar campanha sandbox');host.className='final-sandbox-overlay';
 host.innerHTML=`<div class="final-sandbox-card"><div class="final-kicker">MUNDO LIVRE</div><h2>Começar sem roteiro</h2><p>Escolha o perfil da campanha e onde a história começa. Você não precisa escrever o ponto inicial.</p>
 <label class="final-field"><span>Campanha</span><select id="sandbox-mode"><option value="EOTE">Edge of the Empire</option><option value="AOR">Age of Rebellion</option><option value="MIXED">Mista · EotE + AoR</option></select></label>
 <div class="final-field"><span>Ponto inicial</span><div class="final-mode-tabs"><button type="button" data-start-mode="list" class="is-active">LISTA</button><button type="button" data-start-mode="map">MAPA</button><button type="button" data-start-mode="random">ALEATÓRIO</button></div></div>
 <input id="sandbox-point-search" class="r54-start-search" type="search" placeholder="Buscar planeta ou local…" aria-label="Buscar ponto inicial"><div id="sandbox-list" class="final-start-list">${START_POINTS.map((p,i)=>`<button type="button" data-point="${i}" class="${i===0?'is-selected':''}"><strong>${p.name}</strong><small>${p.desc}</small></button>`).join('')}</div>
 <div id="sandbox-map" class="final-start-map" hidden><img src="assets/maps/galaxy_map.jpg" alt="Mapa da galáxia para escolher o ponto inicial">${START_POINTS.map((p,i)=>`<button type="button" data-point="${i}" style="left:${p.x}%;top:${p.y}%" aria-label="Escolher ${p.name}"><span class="sr-only">${i+1}</span></button>`).join('')}<div class="final-map-caption" id="sandbox-map-caption">${START_POINTS[0].name}</div></div>
 <div class="final-selected-point"><span>Selecionado</span><strong id="sandbox-selected-point">${START_POINTS[0].name}</strong></div>
 <div id="sandbox-setup-status" role="status" class="final-status"></div><button id="sandbox-start-button" type="button" class="final-primary-button">CRIAR MUNDO VIVO</button>
 <p class="final-footnote">Seed inicial: 6 facções, 36 NPCs persistentes, 12 locais, relógios, mercados e oportunidades. Sem roteiro obrigatório; aventuras publicadas são opcionais.</p></div>`;
 document.body.appendChild(host);
 const select=host.querySelector('#sandbox-mode'),button=host.querySelector('#sandbox-start-button'),status=host.querySelector('#sandbox-setup-status'),list=host.querySelector('#sandbox-list'),map=host.querySelector('#sandbox-map'),selected=host.querySelector('#sandbox-selected-point'),caption=host.querySelector('#sandbox-map-caption');select.value=String(modeResult.data?.campaignMode||'EOTE');let pointIndex=0,mode='list';
 const search=host.querySelector('#sandbox-point-search');search?.addEventListener('input',()=>{const q=r53Norm(search.value);list.querySelectorAll('[data-point]').forEach(el=>{const p=START_POINTS[Number(el.dataset.point)];el.hidden=Boolean(q&&!r53Norm(`${p?.name||''} ${p?.region||''} ${p?.grid||''}`).includes(q))})});
 const choose=i=>{pointIndex=Math.max(0,Math.min(START_POINTS.length-1,Number(i)||0));host.querySelectorAll('[data-point]').forEach(x=>x.classList.toggle('is-selected',Number(x.dataset.point)===pointIndex));selected.textContent=START_POINTS[pointIndex].name;caption.textContent=START_POINTS[pointIndex].name};host.querySelectorAll('[data-point]').forEach(x=>x.onclick=()=>choose(x.dataset.point));
 host.querySelectorAll('[data-start-mode]').forEach(x=>x.onclick=()=>{mode=x.dataset.startMode;host.querySelectorAll('[data-start-mode]').forEach(y=>y.classList.toggle('is-active',y===x));if(mode==='random'){choose(Math.floor(Math.random()*START_POINTS.length));list.hidden=false;map.hidden=true}else{list.hidden=mode!=='list';map.hidden=mode!=='map'}});
 button.onclick=()=>{const point=START_POINTS[pointIndex].name;button.disabled=true;status.textContent='Criando mundo persistente…';const m=bridgeResult('setCampaignMode',select.value);if(!m.ok){status.textContent=m.message||'Modo inválido.';button.disabled=false;return}const chosen=START_POINTS[pointIndex];const r=bridgeResult('initializeLivingSandbox',{startingPoint:point,regionLabel:chosen.region||`Região de ${point}`,startMapPoint:{x:chosen.x,y:chosen.y}});if(!r.ok){status.textContent=r.message||'Falha ao criar mundo.';button.disabled=false;return}status.textContent='Mundo criado.';host.remove();setTimeout(()=>{relabelCreationForCampaign();enhance()},0)};
}
function enhanceAdventureGate(){
 const existing=document.querySelector('.final-adventure-gate');
 if(!sandboxReady()||adventureStarted()){document.querySelectorAll('.final-adventure-gate').forEach(el=>el.remove());return}
 const route=new URLSearchParams(location.search).get('screen')||'00';const character=hasCharacter(),gateKey=`${route}:${character?'character':'empty'}`;
 if(existing?.dataset?.gateKey===gateKey)return;
 document.querySelectorAll('.final-adventure-gate').forEach(el=>el.remove());
 if(route==='00'){
  const root=document.querySelector('.scene-concept-shell');if(!root)return;const gate=document.createElement('section');gate.className='final-adventure-gate final-adventure-card';gate.dataset.gateKey=gateKey;
  gate.innerHTML=character?`<div><span>PRONTO PARA JOGAR</span><strong>Seu mundo vivo está criado.</strong><small>Barbara vai gerar a situação inicial a partir do local, facções, NPCs e oportunidades persistentes.</small></div><button type="button" data-start-adventure>INICIAR AVENTURA</button>`:`<div><span>ANTES DE COMEÇAR</span><strong>Crie ou carregue um personagem.</strong><small>Você pode criar manualmente, gerar uma ficha completa aleatória ou importar .json.</small></div><div class="final-adventure-actions"><button type="button" data-manual-character>CRIAR FICHA</button><button type="button" data-random-character>ALEATÓRIA</button><button type="button" data-import-character>IMPORTAR JSON</button></div><output></output>`;
  root.prepend(gate);const out=gate.querySelector('output');gate.querySelector('[data-manual-character]')?.addEventListener('click',()=>navigateRoute('18'));gate.querySelector('[data-random-character]')?.addEventListener('click',()=>quickRandomCharacter(out));gate.querySelector('[data-import-character]')?.addEventListener('click',()=>quickImportCharacter(out));gate.querySelector('[data-start-adventure]')?.addEventListener('click',async()=>{const b=gate.querySelector('[data-start-adventure]');b.disabled=true;b.textContent='INICIANDO…';const r=await startBarbaraOpening();if(!r.ok){b.disabled=false;b.textContent='INICIAR AVENTURA';alert(r.message||'Não foi possível iniciar a aventura.');return}setTimeout(()=>{enhanceSceneFromEngine();enhanceNarration();enhanceSceneGeminiButton()},0)});
 }else if(character){
  const bar=document.createElement('button');bar.type='button';bar.className='final-adventure-gate final-adventure-fab';bar.dataset.gateKey=gateKey;bar.textContent='▶ INICIAR AVENTURA';bar.onclick=async()=>{const r=await startBarbaraOpening();if(!r.ok){alert(r.message||'Não foi possível iniciar a aventura.');return}navigateRoute('00')};document.body.appendChild(bar);
 }
}
function currentSceneRecord(){try{const state=safeParse(localStorage.getItem('braseiro.starwars.edge.state.v1'),null);return state&&state.scene&&typeof state.scene==='object'?state.scene:null}catch{return null}}
function sceneGeminiPrompt(){
 const view=playerView()||{},scene=currentSceneRecord()||{};
 const narration=narrationText(),situation=String(document.querySelector('.scene-situation-paper p')?.textContent||view?.situation||'').trim();
 const location=String(view?.scene?.location?.name||scene?.locationName||scene?.title||'').trim();
 const participants=(Array.isArray(view?.participants)?view.participants:[]).map(p=>String(p?.name||'').trim()).filter(Boolean);
 const facts=[];if(location)facts.push(`Local: ${location}`);if(situation)facts.push(`Situação visível: ${situation}`);if(narration)facts.push(`Narração visível ao jogador: ${narration}`);if(participants.length)facts.push(`Participantes visíveis: ${participants.join(', ')}`);
 if(!facts.length)return '';
 return [
  'Crie uma ilustração horizontal cinematográfica para uma cena de STAR WARS — EDGE OF THE GALAXY, usada em um VTT.',
  'Estética: concept art cinematográfica, retro-industrial Star Wars, materiais gastos, iluminação dramática, atmosfera crível; não parecer captura de videogame e não parecer fotografia moderna.',
  'Use SOMENTE os fatos visíveis abaixo. Não revele informação do Mestre e não invente personagens nomeados, facções, armas, veículos ou acontecimentos não citados.',
  'Não coloque texto, letras, legendas, molduras, HUD, menus, botões, marcas d’água ou interface na imagem.',
  `FATOS VISÍVEIS DA CENA:\n${facts.join('\n')}`,
  'Composição horizontal 16:9, cenário legível e espaço visual suficiente para uso como imagem de cena.'
 ].join('\n\n');
}
function sceneKeyFor(value){const text=String(value??'Cena').trim()||'Cena';let h=2166136261;for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,16777619)}return `scene_${(h>>>0).toString(16).padStart(8,'0')}`}
function currentSceneKey(){const scene=currentSceneRecord();return sceneKeyFor(scene?.id??scene?.sceneId??scene?.title??'Cena')}
function enhanceSceneGeminiButton(){
 const media=document.querySelector('.scene-media-slot');if(!media||media.querySelector('.final-scene-gemini'))return;
 const wrap=document.createElement('div');wrap.className='final-scene-gemini';wrap.innerHTML='<button type="button">✦ GERAR ILUSTRAÇÃO</button><small></small>';media.appendChild(wrap);
 const btn=wrap.querySelector('button'),msg=wrap.querySelector('small');
 btn.onclick=()=>{const g=window.BraseiroGemini,prompt=sceneGeminiPrompt();if(!prompt){msg.textContent='Inicie a aventura para montar o prompt da cena.';return}if(!g||typeof g.openGeminiWithPrompt!=='function'){msg.textContent='Handoff para Gemini indisponível.';return}btn.disabled=true;msg.textContent='Abrindo Gemini com o prompt da cena…';try{const r=safeParse(g.openGeminiWithPrompt(prompt),{});btn.disabled=false;msg.textContent=r.ok?'Prompt copiado e enviado ao Gemini.':(r.message||'Não foi possível abrir o Gemini.')}catch(err){btn.disabled=false;msg.textContent='Não foi possível abrir o Gemini.'}};
}
function enhanceGeminiModels(){
 const card=cardByTitle('Chave da API Gemini');if(!card||card.querySelector('.final-gemini-models'))return;const g=window.BraseiroGemini;if(!g||typeof g.configureModels!=='function')return;const st=geminiStatus();const box=document.createElement('div');box.className='final-gemini-models';box.innerHTML=`<div class="final-model-title">Modelos Gemini</div><label>Texto / Mestre<input data-model="master" value="${String(st.masterModel||'gemini-3.8-flash')}"></label><label>Imagem de cena<input data-model="image" value="${String(st.model||'gemini-3.1-flash-image')}"></label><label>TTS<input data-model="tts" value="${String(st.ttsModel||'gemini-3.1-flash-tts-preview')}"></label><button type="button">SALVAR MODELOS</button><output></output>`;card.children[1]?.appendChild(box);box.querySelector('button').onclick=()=>{const vals=[...box.querySelectorAll('input')].map(x=>x.value.trim());try{const r=safeParse(g.configureModels(vals[0],vals[1],vals[2]),{});box.querySelector('output').textContent=r.ok?'Modelos salvos no aparelho.':(r.message||'Falha ao salvar modelos.')}catch{box.querySelector('output').textContent='Falha ao salvar modelos.'}};
}
function enhanceCharacterEmptyActions(){
 const route=new URLSearchParams(location.search).get('screen')||'00';if(route!=='06')return;const headings=[...document.querySelectorAll('section')].find(s=>String(s.firstElementChild?.textContent||'').trim()==='Personagem');if(!headings||!String(headings.textContent||'').includes('Nenhum personagem carregado'))return;if(document.querySelector('.final-empty-character-actions'))return;const existing=[...document.querySelectorAll('button')].find(b=>String(b.textContent||'').includes('Abrir fluxo de criação'));if(!existing)return;const box=document.createElement('div');box.className='final-empty-character-actions';box.innerHTML='<button type="button" data-random>GERAR FICHA ALEATÓRIA</button><button type="button" data-import>IMPORTAR .JSON</button><output></output>';existing.insertAdjacentElement('afterend',box);const out=box.querySelector('output');box.querySelector('[data-random]').onclick=()=>quickRandomCharacter(out);box.querySelector('[data-import]').onclick=()=>quickImportCharacter(out);
}
function enhanceUtilityShortcuts(){document.querySelectorAll('.final-utility-shortcuts').forEach(el=>el.remove());}
function enhance(){enhanceNarration();enhanceSceneFromEngine();enhanceAccessibility();enhanceTtsSettings();relabelCreationForCampaign();setupOverlay();enhanceAdventureGate();enhanceSceneGeminiButton();enhanceGeminiModels();enhanceCharacterEmptyActions();enhanceUtilityShortcuts()}
let scheduled=false;const observer=new MutationObserver(()=>{if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;enhance()})});
observer.observe(document.documentElement,{subtree:true,childList:true});
window.addEventListener('popstate',()=>setTimeout(enhance,0));
window.addEventListener('DOMContentLoaded',enhance);setTimeout(enhance,0);
window.BraseiroFinalRuntime={version:'1.0.0',speakVisibleNarration:()=>speak(narrationText()),stopNarration:stop,refreshScene:enhanceSceneFromEngine,preferences:prefs};


/* R53 targeted runtime fixes: no R46 redesign. */
const R53_PATCH_ID='r53-real-device-2026-09-16';
function r53Norm(v){return String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('pt-BR').replace(/\s+/g,' ').trim()}
function r53Bridge(){return (typeof window!=='undefined'&&window.BraseiroGameBridge&&typeof window.BraseiroGameBridge==='object')?window.BraseiroGameBridge:null}
function r53Unwrap(raw){if(raw&&raw.ok===false)throw new Error(raw.message||raw.error||'Operação recusada pelo motor.');let data=raw&&raw.ok===true?raw.data:raw;if(data&&data.check)data=data.check;return data}
function r53Close(selector){document.querySelector(selector)?.remove()}
function r53OpenDice(){
 if(document.querySelector('.r53-dice-overlay'))return;
 const ov=document.createElement('div');ov.className='r53-overlay r53-dice-overlay';
 ov.innerHTML='<div class="r53-modal"><div class="r53-modal-head"><div><small>DADOS NARRATIVOS</small><h2>Rolagem livre</h2></div><button class="r53-close" aria-label="Fechar">×</button></div><p style="margin:0;color:#aeb7bc;font-size:.78rem">Usa o mesmo motor de dados narrativos do jogo. Característica + perícia montam os dados positivos; dificuldade, desafio, bônus e contratempo completam a parada.</p><div class="r53-dice-grid"><label>Característica<input data-die="characteristic" type="number" min="0" max="5" value="2"></label><label>Perícia<input data-die="skill" type="number" min="0" max="5" value="1"></label><label>Dificuldade<input data-die="difficulty" type="number" min="0" max="5" value="2"></label><label>Desafio<input data-die="challenge" type="number" min="0" max="5" value="0"></label><label>Bônus<input data-die="boost" type="number" min="0" max="5" value="0"></label><label>Contratempo<input data-die="setback" type="number" min="0" max="5" value="0"></label></div><button class="r53-primary r53-roll">ROLAR DADOS</button><div class="r53-result" aria-live="polite">Aguardando rolagem.</div></div>';
 document.body.appendChild(ov);
 ov.querySelector('.r53-close').onclick=()=>ov.remove();
 ov.addEventListener('click',e=>{if(e.target===ov)ov.remove()});
 ov.querySelector('.r53-roll').onclick=()=>{
  const out=ov.querySelector('.r53-result');const b=r53Bridge();
  if(!b||typeof b.resolveCheck!=='function'){out.innerHTML='<span class="bad">Motor de dados indisponível.</span>';return}
  const n=k=>Math.max(0,Math.min(5,Number(ov.querySelector(`[data-die="${k}"]`).value)||0));
  try{
   const d=r53Unwrap(b.resolveCheck({characteristic:n('characteristic'),skill:n('skill'),difficulty:n('difficulty'),challenge:n('challenge'),boost:n('boost'),setback:n('setback')}))||{};
   const success=Number(d.netSuccess||0),adv=Number(d.netAdvantage||0),tri=Number(d.triumph||0),des=Number(d.despair||0);
   out.innerHTML=`<strong>Resultado</strong><br><span class="${success>0?'ok':'bad'}">${success>0?'SUCESSO':'FALHA'} · ${success} sucesso(s) líquido(s)</span><br>${adv} vantagem(ns) líquida(s) · ${tri} triunfo(s) · ${des} desespero(s)`;
  }catch(err){out.innerHTML='<span class="bad">'+String(err?.message||err)+'</span>'}
 };
}
function r53EnsureDiceFab(){
 if(document.querySelector('.r53-dice-fab'))return;
 const b=document.createElement('button');b.type='button';b.className='r53-fab r53-dice-fab';b.innerHTML='<img src="assets/ui/icons-v2/dice.png" alt="">DADOS';b.onclick=r53OpenDice;document.body.appendChild(b);
}
function r53RestartAdventure(){
 if(!confirm('Reiniciar a aventura? Isto apaga o estado atual da campanha neste aparelho e volta à criação do mundo.'))return;
 try{
  localStorage.removeItem('braseiro.starwars.edge.state.v1');
  localStorage.removeItem('braseiro.starwars.edge.snapshots.v1');
  sessionStorage.clear();
  location.href='r46-shell.html';
 }catch(err){alert('Falha ao reiniciar: '+String(err?.message||err))}
}
function r53EnsureRestart(){
 const old=document.querySelector('.r53-restart-fab');
 if(!adventureStarted()){old?.remove();return}
 if(old)return;
 const b=document.createElement('button');b.type='button';b.className='r53-fab r53-restart-fab';b.textContent='↻ REINICIAR';b.onclick=r53RestartAdventure;document.body.appendChild(b);
}
function r53OpenLibrary(){
 if(document.querySelector('.r53-library-overlay'))return;
 const ov=document.createElement('div');ov.className='r53-overlay r53-library-overlay';
 ov.innerHTML='<div class="r53-modal"><div class="r53-modal-head"><div><small>BIBLIOTECA LOCAL</small><h2>Fontes e PDFs</h2></div><button class="r53-close" aria-label="Fechar">×</button></div><div class="r53-library-tools"><input type="search" placeholder="Buscar nas fontes locais…" aria-label="Buscar na biblioteca"><button class="r53-secondary r53-search">BUSCAR</button></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:7px"><button class="r53-primary r53-import">IMPORTAR PDF</button><button class="r53-secondary r53-refresh">ATUALIZAR</button></div><div class="r53-lib-status" style="font-size:.72rem;color:#9ccbd7"></div><div class="r53-docs"></div></div>';
 document.body.appendChild(ov);const docs=ov.querySelector('.r53-docs'),status=ov.querySelector('.r53-lib-status');
 const native=()=>window.BraseiroLibrary;
 const render=(rows)=>{docs.innerHTML='';if(!Array.isArray(rows)||!rows.length){docs.innerHTML='<div class="r53-empty">Nenhum PDF importado.</div>';return}for(const d of rows){const el=document.createElement('div');el.className='r53-doc';const title=String(d.title||d.fileName||'PDF');const st=String(d.status||'ANEXADO');const pages=Number(d.pageCount||0);const auth=String(d.authorityType||'SUPLEMENTO');el.innerHTML=`<strong>${title.replace(/[<&]/g,'')}</strong><small>${st} · ${pages?pages+' pág. · ':''}${auth}</small>`;docs.appendChild(el)}};
 const refresh=()=>{try{const api=native();if(!api||typeof api.listDocuments!=='function'){status.textContent='Biblioteca Android indisponível neste host.';render([]);return}const raw=api.listDocuments();render(typeof raw==='string'?JSON.parse(raw):raw);status.textContent='Biblioteca pronta.'}catch(err){status.textContent=String(err?.message||err);render([])}};
 ov.querySelector('.r53-close').onclick=()=>ov.remove();ov.addEventListener('click',e=>{if(e.target===ov)ov.remove()});ov.querySelector('.r53-refresh').onclick=refresh;
 ov.querySelector('.r53-import').onclick=()=>{try{const api=native();if(!api||typeof api.pickPdf!=='function')throw new Error('Importação de PDF indisponível.');api.pickPdf();status.textContent='Selecione o PDF…'}catch(err){status.textContent=String(err?.message||err)}};
 ov.querySelector('.r53-search').onclick=()=>{try{const q=ov.querySelector('input').value.trim();const api=native();if(!q){refresh();return}if(!api||typeof api.searchDocuments!=='function')throw new Error('Busca local indisponível.');const raw=api.searchDocuments(q,25),data=typeof raw==='string'?JSON.parse(raw):raw;render(data?.results||[]);status.textContent=data?.grounded?'Resultados encontrados nas fontes locais.':'Busca concluída.'}catch(err){status.textContent=String(err?.message||err)}};
 const previous=window.braseiroLibraryNativeEvent;window.braseiroLibraryNativeEvent=(raw)=>{try{if(typeof previous==='function')previous(raw)}finally{setTimeout(refresh,120)}};
 refresh();
}
function r53InterceptLibrary(){
 if(document.documentElement.dataset.r53LibraryCapture)return;document.documentElement.dataset.r53LibraryCapture='1';
 document.addEventListener('click',e=>{const hit=e.target?.closest?.('button,a,[role="button"],.list-item');if(!hit)return;const t=r53Norm(hit.textContent);if(!t.startsWith('biblioteca'))return;e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();r53OpenLibrary()},true);
}
function r53FindItemHost(button){let el=button.parentElement,best=null;for(let i=0;el&&i<7;i++,el=el.parentElement){const proposes=[...el.querySelectorAll('button')].filter(x=>r53Norm(x.textContent).includes('propor ao mestre'));const strong=el.querySelector('strong');if(proposes.length===1&&strong)best=el;if(proposes.length>1)break}return best||button.parentElement}
const r53ImageCache=new Map();
function r53PickAsset(name){
 const key=r53Norm(name);if(r53ImageCache.has(key))return r53ImageCache.get(key);const b=r53Bridge();let assets=[];
 try{if(b&&typeof b.searchImageLibrary==='function'){const raw=b.searchImageLibrary({query:name,category:'equipment',limit:30});const d=raw?.ok===true?raw.data:raw;if(Array.isArray(d))assets=d}}catch(_){ }
 const words=key.split(/[^a-z0-9]+/).filter(x=>x.length>2);let best=null,score=-1;
 for(const a of assets){if(a?.category!=='equipment')continue;const title=r53Norm(a.title),tags=r53Norm(Array.isArray(a.tags)?a.tags.join(' '):'');let s=0;if(title===key)s+=100;if(title.includes(key)||key.includes(title))s+=35;for(const w of words)if((title+' '+tags).includes(w))s+=5;if(a.sourceType!=='external_reference')s+=3;if(s>score){score=s;best=a}}
 const picked=score>=10?best:null;r53ImageCache.set(key,picked);return picked;
}
function r53AssetUrl(a){if(!a)return null;if(a.sourceType==='external_reference')return a.remoteReady&&a.remoteUrl?a.remoteUrl:null;return a.localPath||null}
function r53EnhanceItemImages(){
 const params=new URLSearchParams(location.search),route=params.get('screen')||'00';if(route!=='09'&&route!=='08')return;
 for(const btn of [...document.querySelectorAll('button')].filter(x=>r53Norm(x.textContent).includes('propor ao mestre'))){const host=r53FindItemHost(btn);if(!host||host.querySelector('.r53-item-visual'))continue;const strong=host.querySelector('strong');const name=strong?.textContent?.trim();if(!name)continue;const asset=r53PickAsset(name),src=r53AssetUrl(asset)||'assets/ui/icons-v2/inventory.png';const fig=document.createElement('figure');fig.className='r53-item-visual'+(asset?'':' is-fallback');fig.innerHTML=`<img loading="lazy" alt="${name.replace(/["<&]/g,'')}" src="${src}"><figcaption>${asset?asset.title:'Sem imagem específica associada'}</figcaption>`;host.insertBefore(fig,host.firstChild)}
}
function r53RemoveBadShortcuts(){document.querySelectorAll('.final-utility-shortcuts').forEach(el=>el.remove())}
function r53Tick(){r53RemoveBadShortcuts();r53EnsureDiceFab();r53EnsureRestart();r53EnhanceItemImages()}
r53InterceptLibrary();r53Tick();new MutationObserver(()=>r53Tick()).observe(document.documentElement,{subtree:true,childList:true});addEventListener('popstate',()=>setTimeout(r53Tick,0));



/* R54 — recover the user's visual library and real-device affordances. */
const R54_ASSET_ROOT='image-library/local/r54/';
let r54BindingsPromise=null;
function r54Bindings(){if(!r54BindingsPromise)r54BindingsPromise=fetch(R54_ASSET_ROOT+'bindings.json').then(r=>{if(!r.ok)throw new Error('bindings');return r.json()}).catch(()=>({weapons:{},equipment:{},portraits:{},maps:{}}));return r54BindingsPromise}
function r54Norm(v){return String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('pt-BR').replace(/[^a-z0-9]+/g,' ').trim()}
function r54AssetIndex(bind){const map=new Map();for(const group of ['weapons','equipment'])for(const item of Object.values(bind?.[group]||{}))for(const a of item.aliases||[])map.set(r54Norm(a),R54_ASSET_ROOT+item.file);return map}
async function r54EnhanceItemImages(){
 const route=new URLSearchParams(location.search).get('screen')||'00';if(route!=='09'&&route!=='08')return;
 const bind=await r54Bindings(),idx=r54AssetIndex(bind);
 for(const btn of [...document.querySelectorAll('button')].filter(x=>r54Norm(x.textContent).includes('propor ao mestre'))){
  const host=r53FindItemHost(btn);if(!host)continue;const strong=host.querySelector('strong');const name=strong?.textContent?.trim();if(!name)continue;
  const exact=idx.get(r54Norm(name));if(!exact)continue;
  const key=r54Norm(name),current=host.querySelector(':scope > .r54-item-visual');
  if(current){const img=current.querySelector('img');if(current.dataset.r54VisualBound===key&&img?.getAttribute('src')===exact)continue;current.remove()}
  host.querySelectorAll(':scope > .r53-item-visual').forEach(x=>x.remove());
  const fig=document.createElement('figure');fig.className='r54-item-visual';fig.dataset.r54VisualBound=key;fig.innerHTML=`<img loading="lazy" alt="${name.replace(/["<&]/g,'')}" src="${exact}">`;host.insertBefore(fig,host.firstChild);
 }
}
function r54CharacterPortrait(){
 const route=new URLSearchParams(location.search).get('screen')||'00';if(route!=='06')return;
 if(document.querySelector('.r54-character-portrait'))return;const state=currentState(),c=state?.player?.character;if(!c)return;
 const species=r54Norm(c.species||c.speciesName||'');let src='';if(species.includes('twi lek')||species.includes('twilek'))src=R54_ASSET_ROOT+'portraits/twilek_female_blue.webp';
 if(!src)return;const heading=[...document.querySelectorAll('h2,h3,div')].find(el=>r54Norm(el.textContent)==='identidade');const card=heading?.closest('section,article,.card')||heading?.parentElement;if(!card)return;
 const fig=document.createElement('figure');fig.className='r54-character-portrait';fig.innerHTML=`<img src="${src}" alt="Retrato visual de ${String(c.name||'personagem').replace(/["<&]/g,'')}"><figcaption>${String(c.name||'Personagem')}</figcaption>`;heading.insertAdjacentElement('afterend',fig);
}
function r54FixSceneIcon(){
 const btn=document.querySelector('.bottom-navigation .bottom-nav-button:first-child');if(!btn)return;const icon=btn.querySelector('.reference-icon-mask');if(!icon||icon.dataset.r54Fixed)return;icon.dataset.r54Fixed='1';icon.classList.add('r54-scene-icon');icon.style.backgroundImage='none';icon.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h16v11H4zM5 4l3 4M10 4l3 4M15 4l3 4M4 4h16v4H4z"/></svg>';
}
function r54ContextMapPreview(){
 const overlay=document.getElementById('braseiro-sandbox-setup');if(!overlay||overlay.querySelector('.r54-map-hint'))return;const selected=overlay.querySelector('#sandbox-selected-point');if(!selected)return;
 const box=document.createElement('div');box.className='r54-map-hint';box.innerHTML='<small>82 locais catalogados disponíveis. O mapa galáctico serve para localização; mapas locais aparecem quando existe asset confirmado.</small><figure hidden><img alt="Mapa local"><figcaption></figcaption></figure>';selected.parentElement.insertAdjacentElement('afterend',box);
 const refresh=()=>{const name=String(selected.textContent||'');const fig=box.querySelector('figure'),img=fig.querySelector('img'),cap=fig.querySelector('figcaption');let src='',label='';if(/shantipole/i.test(name)){src=R54_ASSET_ROOT+'maps/shantipole_base.webp';label='Base Rebelde Shantipole — mapa do acervo'}else if(/mos eisley/i.test(name)){src='https://kainrath.wordpress.com/wp-content/uploads/2024/07/mos-eisley-city-1.png';label='Mos Eisley — mapa local'}else if(/tatooine/i.test(name)){src='https://kainrath.wordpress.com/wp-content/uploads/2021/01/tatooine-map.png';label='Tatooine — mapa local'}if(src){img.src=src;cap.textContent=label;fig.hidden=false}else fig.hidden=true};
 const mo=new MutationObserver(refresh);mo.observe(selected,{childList:true,subtree:true,characterData:true});refresh();
}
function r54Tick(){r54FixSceneIcon();r54CharacterPortrait();r54ContextMapPreview();r54EnhanceItemImages();r54SupplementSpeciesPanel()}
r54Tick();new MutationObserver(()=>r54Tick()).observe(document.documentElement,{subtree:true,childList:true});addEventListener('popstate',()=>setTimeout(r54Tick,0));


/* R54_SUPPLEMENT_SPECIES_REFERENCE */
var r54SupplementSpeciesPromise=null;
function r54SupplementSpeciesCatalog(){
 if(!r54SupplementSpeciesPromise)r54SupplementSpeciesPromise=fetch('js/reference/speciesCreationReferenceCatalog.json').then(r=>{if(!r.ok)throw new Error('species supplement reference');return r.json()}).catch(()=>[]);
 return r54SupplementSpeciesPromise;
}
async function r54SupplementSpeciesForMode(mode='MIXED',query=''){
 if(!['EOTE','AOR','MIXED'].includes(mode))throw new Error('campaign mode');
 const q=r54Norm(query),rows=await r54SupplementSpeciesCatalog();
 return rows.filter(x=>(mode==='MIXED'||(x.activeLines||[]).includes(mode))&&(!q||r54Norm(`${x.name||''} ${(x.references||[]).filter(r=>r.line==='EOTE'||r.line==='AOR').map(r=>r.citation).join(' ')}`).includes(q)));
}
async function r54SupplementSpeciesCoverage(){
 const rows=await r54SupplementSpeciesCatalog(),byLine={EOTE:0,AOR:0},books={};
 for(const x of rows){for(const l of x.activeLines||[])if(l in byLine)byLine[l]++;for(const r of (x.references||[]).filter(r=>r.line==='EOTE'||r.line==='AOR')){const b=String(r.citation||'').replace(/ p\.\d+.*$/,'').replace(/,$/,'');books[b]=(books[b]||0)+1}}
 return {uniqueSpecies:rows.length,byLine,books};
}
window.BraseiroSupplementReference=Object.freeze({speciesForMode:r54SupplementSpeciesForMode,coverage:r54SupplementSpeciesCoverage,mechanicalPolicy:'REFERENCE_ONLY_UNTIL_SOURCE_BINDING'});
async function r54SupplementSpeciesPanel(){
 const route=new URLSearchParams(location.search).get('screen')||'00';if(route!=='06'||document.querySelector('[data-r54-supplement-species]'))return;
 const rows=await r54SupplementSpeciesCatalog();if(!rows.length)return;
 const state=(typeof currentState==='function'?currentState():null)||{};const raw=String(state?.campaign?.mode||state?.mode||'MIXED').toUpperCase();const mode=['EOTE','AOR','MIXED'].includes(raw)?raw:'MIXED';
 const host=document.querySelector('main,.screen-content,.page-content,.r46-content')||document.body;const panel=document.createElement('section');panel.dataset.r54SupplementSpecies='1';panel.className='r54-supplement-species';
 panel.innerHTML='<h3>ESPÉCIES · SUPLEMENTOS</h3><p><small>Referências EotE/AoR recuperadas. Entradas sem bloco mecânico vinculado continuam apenas como referência.</small></p><input type="search" aria-label="Buscar espécie ou suplemento" placeholder="Buscar espécie ou suplemento…"><div class="r54-supplement-species-results"></div>';
 const input=panel.querySelector('input'),results=panel.querySelector('.r54-supplement-species-results');host.appendChild(panel);
 const render=async()=>{const found=await r54SupplementSpeciesForMode(mode,input.value);results.innerHTML=found.slice(0,12).map(x=>`<article><strong>${String(x.name||'').replace(/[<>&]/g,'')}</strong><small>${(x.references||[]).filter(r=>r.line==='EOTE'||r.line==='AOR').map(r=>r.citation).join(' · ').replace(/[<>&]/g,'')}</small></article>`).join('')||'<small>Nenhuma referência nesse modo.</small>'};
 input.addEventListener('input',render);render();
}

})();

/* R54 HISTORICAL VISUAL RESTORE — approved R38 assets, visual-only. */
const FINAL_SCENE_VISUALS=Object.freeze({"customs_checkpoint":["image-library/local/final/scenes/customs_checkpoint_01.webp","image-library/local/final/scenes/customs_checkpoint_02.webp","image-library/local/final/scenes/customs_checkpoint_03.webp","image-library/local/final/scenes/customs_checkpoint_04.webp","image-library/local/final/scenes/customs_checkpoint_05.webp","image-library/local/final/scenes/customs_checkpoint_06.webp"],"medbay":["image-library/local/final/scenes/medbay_01.webp","image-library/local/final/scenes/medbay_02.webp","image-library/local/final/scenes/medbay_03.webp","image-library/local/final/scenes/medbay_04.webp"],"cargo_warehouse":["image-library/local/final/scenes/cargo_warehouse_01.webp","image-library/local/final/scenes/cargo_warehouse_02.webp","image-library/local/final/scenes/cargo_warehouse_03.webp","image-library/local/final/scenes/cargo_warehouse_04.webp"],"outer_rim_settlement":["image-library/local/final/scenes/outer_rim_settlement_01.webp","image-library/local/final/scenes/outer_rim_settlement_02.webp","image-library/local/final/scenes/outer_rim_settlement_03.webp","image-library/local/final/scenes/outer_rim_settlement_04.webp","image-library/local/final/scenes/outer_rim_settlement_05.webp"],"relay_station":["image-library/local/final/scenes/relay_station_01.webp","image-library/local/final/scenes/relay_station_02.webp"],"mining_complex":["image-library/local/final/scenes/mining_complex_01.webp"],"remote_hideout":["image-library/local/final/scenes/remote_hideout_01.webp"],"repair_dock":["image-library/local/final/scenes/repair_dock_01.webp"],"industrial_district":["image-library/local/final/scenes/industrial_district_01.webp"],"wreck_field":["image-library/local/final/scenes/wreck_field_01.webp"]});
const FINAL_SCENE_KEYWORDS=Object.freeze({"customs_checkpoint":["alfand","aduana","customs","inspeção","inspecao","checkpoint","contrabando","controle imperial"],"medbay":["medbay","centro médico","centro medico","médico","medico","hospital","bacta","enfermaria","ferido"],"cargo_warehouse":["armaz","entreposto","carga","warehouse","depósito","deposito","contêiner","conteiner","mercadoria"],"relay_station":["retransmiss","relay","antena","comunicaç","comunicac","transmissor","sinal"],"mining_complex":["minera","mining","mina","minério","minerio","escava","perfur"],"remote_hideout":["esconderijo","refúgio","refugio","hideout","fugitiv","clandestin","abrigo remoto"],"repair_dock":["doca de repar","hangar-oficina","hangar oficina","oficina","manutenção","manutencao","reparo"],"industrial_district":["distrito industrial","zona industrial","fábrica","fabrica","tubulaç","tubulac","fuligem"],"wreck_field":["destroço","destroco","wreck","sucata de nave","nave destruída","nave destruida"],"outer_rim_settlement":["assentamento","orla exterior","outer rim","colônia","colonia","povoado","fronteira","mercado","rua"]});
const FINAL_EXPLICIT_VISUALS=Object.freeze([{"id":"vehicle.digger_crawler","kind":"vehicle","title":"Digger Crawler","aliases":["Digger Crawler","digger crawler"],"src":"image-library/local/final/vehicles/digger_crawler.png"},{"id":"vehicle.at_est","kind":"vehicle","title":"AT-EST Exploration and Survey Walker","aliases":["AT-EST Exploration and Survey Walker","at est"],"src":"image-library/local/final/vehicles/at_est.png"},{"id":"vehicle.cloakshape","kind":"vehicle","title":"CloakShape","aliases":["CloakShape","cloakshape"],"src":"image-library/local/final/vehicles/cloakshape.png"},{"id":"vehicle.jumpmaster_jm5000","kind":"vehicle","title":"JM-5000 JumpMaster","aliases":["JM-5000 JumpMaster","jumpmaster jm5000","JM-5000 JumpMaster","JumpMaster"],"src":"image-library/local/final/vehicles/jumpmaster_jm5000.png"},{"id":"vehicle.firespray","kind":"vehicle","title":"Firespray","aliases":["Firespray","firespray"],"src":"image-library/local/final/vehicles/firespray.png"},{"id":"vehicle.skipray_gat12h","kind":"vehicle","title":"GAT-12h Skipray Blastboat","aliases":["GAT-12h Skipray Blastboat","skipray gat12h","GAT-12h Skipray","Skipray"],"src":"image-library/local/final/vehicles/skipray_gat12h.png"},{"id":"vehicle.alpha_xg1_star_wing","kind":"vehicle","title":"Alpha-class XG-1 Star Wing","aliases":["Alpha-class XG-1 Star Wing","alpha xg1 star wing","XG-1 Star Wing","Alpha-class XG-1"],"src":"image-library/local/final/vehicles/alpha_xg1_star_wing.png"},{"id":"vehicle.vt49_decimator","kind":"vehicle","title":"VT-49 Decimator","aliases":["VT-49 Decimator","vt49 decimator","VT-49 Decimator"],"src":"image-library/local/final/vehicles/vt49_decimator.png"},{"id":"vehicle.wud500","kind":"vehicle","title":"CEC WUD-500","aliases":["CEC WUD-500","wud500","WUD-500","CEC WUD-500"],"src":"image-library/local/final/vehicles/wud500.png"},{"id":"creature.kowakian_monkey_lizard","kind":"creature","title":"Kowakian Monkey-Lizard","aliases":["Kowakian Monkey-Lizard"],"src":"image-library/local/final/creatures/kowakian_monkey_lizard.png"},{"id":"creature.lurking_scrange","kind":"creature","title":"Lurking Scrange","aliases":["Lurking Scrange"],"src":"image-library/local/final/creatures/lurking_scrange.png"},{"id":"creature.gigantic_dragonsnake","kind":"creature","title":"Gigantic Dragonsnake","aliases":["Gigantic Dragonsnake"],"src":"image-library/local/final/creatures/gigantic_dragonsnake.png"},{"id":"npc.son_barab","kind":"npc","title":"Capitão Son Barab, ISB","aliases":["Son Barab","Capitão Son Barab","Captain Son Barab"],"src":"image-library/local/final/npcs/son_barab_portrait.webp"},{"id":"equipment.spacesuit","kind":"equipment","title":"Traje espacial","aliases":["Traje espacial","traje espacial","spacesuit","space suit"],"src":"image-library/local/final/equipment/spacesuit.webp"},{"id":"equipment.reload_power_pack","kind":"equipment","title":"Recarga adicional / Power Pack","aliases":["Recarga adicional / Power Pack","recarga adicional","power pack","ammo reload","recarga"],"src":"image-library/local/final/equipment/power_pack_reload.webp"}]);
function r54HistNorm(v){return String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('pt-BR')}
function r54HistHash(text){let h=2166136261>>>0;for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0}
function r54HistoricalSceneVisual(){
 const media=document.querySelector('.scene-media-slot');if(!media)return;
 const live=media.querySelector('img.scene-media-image:not(.final-scene-library-image)');let fallback=media.querySelector('img.final-scene-library-image[data-r54-historical]');
 if(live){if(fallback)fallback.remove();return}
 const root=document.querySelector('main')||document.body,context=r54HistNorm(root?.innerText||'');let best='outer_rim_settlement',score=0;
 for(const [arch,terms] of Object.entries(FINAL_SCENE_KEYWORDS)){let s=0;for(const term of terms){const n=r54HistNorm(term);if(n&&context.includes(n))s+=n.length+(n.includes(' ')?8:3)}if(s>score){score=s;best=arch}}
 const variants=FINAL_SCENE_VISUALS[best]||FINAL_SCENE_VISUALS.outer_rim_settlement;if(!variants?.length)return;
 const seed=(document.querySelector('.scene-context-title')?.textContent||'')+'|'+(document.querySelector('.scene-situation-paper')?.textContent||'')+'|'+location.search;
 const src=variants[r54HistHash(seed||best)%variants.length];
 if(!fallback){fallback=document.createElement('img');fallback.className='scene-media-image final-scene-library-image';fallback.dataset.r54Historical='1';fallback.alt='Imagem de referência compatível com a cena atual';fallback.decoding='async';media.prepend(fallback)}
 if(fallback.getAttribute('src')!==src)fallback.setAttribute('src',src);media.classList.add('has-scene-image','has-recovered-scene');media.classList.remove('is-empty');
 const surface=media.querySelector('.scene-media-surface'),caption=media.querySelector('figcaption');if(surface)surface.hidden=true;if(caption)caption.hidden=true;
}
function r54HistSmallest(alias){const n=r54HistNorm(alias),nodes=[...document.querySelectorAll('main section,main article,main [class*=card],main [class*=panel],section,article')];const hits=nodes.filter(el=>{const t=r54HistNorm(el.textContent);return n&&t.includes(n)&&t.length<7000});hits.sort((a,b)=>(a.textContent||'').length-(b.textContent||'').length);return hits[0]||null}
function r54HistMount(v){const host=v.aliases.map(r54HistSmallest).find(Boolean);if(!host||host.querySelector(`[data-final-visual="${v.id}"]`))return;const wrap=document.createElement('figure');wrap.className='final-explicit-visual final-explicit-'+v.kind;wrap.dataset.finalVisual=v.id;const img=document.createElement('img');img.src=v.src;img.alt=v.title;img.decoding='async';wrap.append(img);const cap=document.createElement('figcaption');cap.textContent=v.title;wrap.append(cap);const target=host.querySelector(':scope > div:last-child')||host;target.prepend(wrap)}
function r54HistoricalVisualTick(){if((new URLSearchParams(location.search).get('screen')||'00')==='00')r54HistoricalSceneVisual();for(const v of FINAL_EXPLICIT_VISUALS)r54HistMount(v)}
(function(){let queued=false;const schedule=()=>{if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;r54HistoricalVisualTick()})};if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',schedule,{once:true});else schedule();new MutationObserver(schedule).observe(document.documentElement,{subtree:true,childList:true,characterData:true});document.addEventListener('click',()=>setTimeout(schedule,0),true);window.BraseiroFinalVisualCompletion=Object.freeze({scenes:26,vehicles:9,creatures:3,npcs:1,equipment:2,policy:'explicit-validated-r54'});})();
