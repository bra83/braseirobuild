package com.braseiro.starwarsedge;

import android.app.Activity;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;

import org.json.JSONObject;

import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

/** Native PT-BR narration bridge. Reads only text explicitly supplied by the visible shell. */
public final class TtsBridge implements TextToSpeech.OnInitListener {
    private static final int MAX_TEXT_CHARS = 12000;
    private final Activity activity;
    private final TextToSpeech tts;
    private final AtomicBoolean ready = new AtomicBoolean(false);
    private final AtomicBoolean closed = new AtomicBoolean(false);
    private final Object lifecycleLock = new Object();
    private volatile String detail = "Inicializando TTS.";

    public TtsBridge(Activity activity) {
        this.activity = activity;
        this.tts = new TextToSpeech(activity.getApplicationContext(), this);
    }

    @Override
    public void onInit(int status) {
        synchronized (lifecycleLock) {
            if (closed.get()) return;
            if (status != TextToSpeech.SUCCESS) {
                detail = "Motor TTS do Android indisponível.";
                ready.set(false);
                return;
            }
            int language = tts.setLanguage(Locale.forLanguageTag("pt-BR"));
            boolean supported = language != TextToSpeech.LANG_MISSING_DATA && language != TextToSpeech.LANG_NOT_SUPPORTED;
            if (closed.get()) {
                ready.set(false);
                return;
            }
            ready.set(supported);
            detail = supported ? "TTS PT-BR pronto." : "Voz PT-BR não instalada no dispositivo.";
        }
    }

    @JavascriptInterface
    public String getStatus() {
        try {
            return new JSONObject()
                    .put("ok", true)
                    .put("available", ready.get())
                    .put("language", "pt-BR")
                    .put("detail", detail)
                    .toString();
        } catch (Exception e) {
            return "{\"ok\":false,\"available\":false,\"detail\":\"Falha ao consultar TTS.\"}";
        }
    }

    @JavascriptInterface
    public String speak(String rawText, String rawRate) {
        String text = rawText == null ? "" : rawText.trim();
        if (text.isEmpty()) return fail("INVALID_INPUT", "Não há narração visível para ler.");
        if (text.length() > MAX_TEXT_CHARS) text = text.substring(0, MAX_TEXT_CHARS);
        if (closed.get()) return fail("TTS_CLOSED", "Motor TTS encerrado.");
        if (!ready.get()) return fail("TTS_UNAVAILABLE", detail);

        float rate = 1.0f;
        try { rate = Float.parseFloat(rawRate == null ? "1" : rawRate); } catch (Exception ignored) { }
        rate = Math.max(0.6f, Math.min(1.4f, rate));
        final String finalText = text;
        final float finalRate = rate;
        final String utteranceId = "braseiro-" + UUID.randomUUID();
        activity.runOnUiThread(() -> {
            if (closed.get()) return;
            tts.stop();
            tts.setSpeechRate(finalRate);
            tts.speak(finalText, TextToSpeech.QUEUE_FLUSH, null, utteranceId);
        });
        try {
            return new JSONObject().put("ok", true).put("rate", rate).put("language", "pt-BR").toString();
        } catch (Exception e) {
            return "{\"ok\":true}";
        }
    }

    @JavascriptInterface
    public String stop() {
        if (closed.get()) return fail("TTS_CLOSED", "Motor TTS encerrado.");
        activity.runOnUiThread(() -> { if (!closed.get()) tts.stop(); });
        return "{\"ok\":true}";
    }

    public void shutdown() {
        synchronized (lifecycleLock) {
            if (!closed.compareAndSet(false, true)) return;
            ready.set(false);
            detail = "Motor TTS encerrado.";
            try { tts.stop(); } catch (Exception ignored) { }
            try { tts.shutdown(); } catch (Exception ignored) { }
        }
    }

    private static String fail(String error, String message) {
        try { return new JSONObject().put("ok", false).put("error", error).put("message", message).toString(); }
        catch (Exception e) { return "{\"ok\":false,\"error\":\"TTS_FAILED\"}"; }
    }
}
