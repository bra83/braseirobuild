export function resolveWeaponHit(weapon, check) {
    if (!weapon || typeof weapon !== 'object')
        throw new Error('Arma inválida.');
    if (!check || typeof check !== 'object')
        throw new Error('Resultado de ataque inválido.');
    const damage = Number(weapon.damage);
    if (!Number.isInteger(damage) || damage < 0)
        throw new Error('Dano da arma inválido.');
    if (!check.success) {
        return {
            hit: false,
            damage: 0,
            criticalAvailable: false,
            blastAvailable: false,
            weapon: structuredClone(weapon),
            check
        };
    }
    const netSuccess = Math.max(0, Number(check.netSuccess) || 0);
    const netAdvantage = Math.max(0, Number(check.netAdvantage) || 0);
    return {
        hit: true,
        damage: damage + netSuccess,
        pierce: Number(weapon.pierce ?? 0),
        damageType: weapon.damageType ?? 'wounds',
        criticalAvailable: Number.isInteger(weapon.crit) ? (Number(check.triumph ?? 0) > 0 || netAdvantage >= weapon.crit) : false,
        criticalCost: Number.isInteger(weapon.crit) ? weapon.crit : null,
        criticalByTriumph: Number.isInteger(weapon.crit) ? Number(check.triumph ?? 0) > 0 : false,
        blastAvailable: Number.isInteger(weapon.blast) && netAdvantage >= Number(weapon.blastActivationCost ?? 2),
        blastDamage: Number.isInteger(weapon.blast) ? weapon.blast + netSuccess : null,
        weapon: structuredClone(weapon),
        check
    };
}
