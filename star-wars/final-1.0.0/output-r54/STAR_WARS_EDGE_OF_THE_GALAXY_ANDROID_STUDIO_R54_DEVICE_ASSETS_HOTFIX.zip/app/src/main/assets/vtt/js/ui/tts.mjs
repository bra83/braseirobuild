export function normalizeTtsRate(value){
  const n=Number(value);
  if(!Number.isFinite(n)) return 1;
  return Math.max(0.6,Math.min(1.4,n));
}

export function ttsAvailable({speech=globalThis.speechSynthesis,Utterance=globalThis.SpeechSynthesisUtterance}={}){
  return Boolean(speech && typeof speech.speak==='function' && typeof speech.cancel==='function' && typeof Utterance==='function');
}

export function speakNarration(text,{speech=globalThis.speechSynthesis,Utterance=globalThis.SpeechSynthesisUtterance,rate=1,lang='pt-BR'}={}){
  const content=String(text??'').trim();
  if(!content) throw new Error('Não há narração para ler.');
  if(!ttsAvailable({speech,Utterance})) throw new Error('TTS não está disponível neste navegador/WebView.');
  speech.cancel();
  const utterance=new Utterance(content);
  utterance.lang=lang;
  utterance.rate=normalizeTtsRate(rate);
  speech.speak(utterance);
  return {text:content,lang,rate:utterance.rate};
}

export function stopNarration({speech=globalThis.speechSynthesis}={}){
  if(!speech || typeof speech.cancel!=='function') return false;
  speech.cancel(); return true;
}
