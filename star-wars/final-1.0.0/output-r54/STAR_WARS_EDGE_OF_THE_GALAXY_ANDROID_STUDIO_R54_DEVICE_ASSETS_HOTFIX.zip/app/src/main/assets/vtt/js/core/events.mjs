export function applyEvent(state, event) {
  if (!event?.id) throw new Error('Evento sem identificador.');
  if (state.appliedActionIds.includes(event.id)) return state;

  const next = structuredClone(state);
  next.appliedActionIds.push(event.id);
  next.events.push(event);
  next.updatedAt = event.at ?? new Date().toISOString();

  if (event.type === 'CHECK_RESOLVED') next.lastCheck = event.payload;
  if (event.type === 'PLAYER_INTENT') next.scene.lastPlayerIntent = event.payload.text;
  if (event.type === 'SCENE_UPDATED' && event.payload.scene) next.scene = {...next.scene,...structuredClone(event.payload.scene)};
  if (event.type === 'CHARACTER_UPDATED') next.player.character = structuredClone(event.payload.character);
  if (event.type === 'MASTER_RULE_QUERY') {
    next.master.lastRuleQuery = event.payload.query;
    next.master.lastRuleResults = structuredClone(event.payload.results ?? []);
    next.master.lastRuleAuthority = structuredClone(event.payload.authority ?? null);
  }
  if (event.type === 'MASTER_CONTEXT_PREPARED') next.master.lastContext = structuredClone(event.payload);
  if (event.type === 'EQUIPMENT_ACQUISITION_PENDING') next.master.pendingAcquisition = structuredClone(event.payload.pending);
  if (event.type === 'EQUIPMENT_ACQUISITION_RESOLVED') {
    next.master.pendingAcquisition = null;
    next.master.acquisitionHistory = [...(next.master.acquisitionHistory ?? []), structuredClone(event.payload.record)];
    if (event.payload.character) next.player.character = structuredClone(event.payload.character);
  }
  if (event.type === 'COMBAT_UPDATED') next.combat = structuredClone(event.payload.combat);
  if (event.type === 'SESSION_STARTED') {
    next.session = structuredClone(event.payload.session);
    if (event.payload.sessionId) next.sessionId = event.payload.sessionId;
    if (event.payload.scene) next.scene = {...next.scene,...structuredClone(event.payload.scene)};
    if (event.payload.character) next.player.character = structuredClone(event.payload.character);
    if (event.payload.group) next.group = structuredClone(event.payload.group);
  }
  if (event.type === 'SESSION_PHASE') next.session = structuredClone(event.payload.session);
  if (event.type === 'SESSION_CHECK_RESOLVED') next.session = structuredClone(event.payload.session);
  if (event.type === 'SESSION_COMBAT_STARTED') next.session = structuredClone(event.payload.session);
  if (event.type === 'SESSION_COMBAT_ENDED') next.session = structuredClone(event.payload.session);
  if (event.type === 'SESSION_CLOSED') {
    next.session = structuredClone(event.payload.session);
    next.sessionHistory = [...(next.sessionHistory ?? []), structuredClone(event.payload.historyEntry)];
    if (event.payload.character) next.player.character = structuredClone(event.payload.character);
  }
  if (event.type === 'XP_GRANTED' && event.payload.character) next.player.character = structuredClone(event.payload.character);
  if (event.type === 'VEHICLES_UPDATED' && event.payload.vehicles) next.vehicles = structuredClone(event.payload.vehicles);
  if (event.type === 'GROUP_UPDATED' && event.payload.group) next.group = structuredClone(event.payload.group);
  if (event.type === 'CAMPAIGN_MODE_UPDATED' && event.payload.campaignMode) next.campaignMode = String(event.payload.campaignMode);
  if (event.type === 'REBEL_GROUP_UPDATED' && event.payload.rebelGroup) next.rebelGroup = structuredClone(event.payload.rebelGroup); // legacy replay only
  if (event.type === 'WORLD_UPDATED' && event.payload.world) next.world = structuredClone(event.payload.world);
  if (event.type === 'COMBAT_ACTION') {
    if (event.payload.combat) next.combat = structuredClone(event.payload.combat);
    if (event.payload.character) next.player.character = structuredClone(event.payload.character);
    if (event.payload.check) next.lastCheck = structuredClone(event.payload.check);
    if (event.payload.attack) next.combat.lastAttack = structuredClone(event.payload.attack);
    if (event.payload.group) next.group = structuredClone(event.payload.group);
  }
  return next;
}
