import {AOR_TALENT_TREES} from './aorTalentTreesData.mjs';
export const AOR_CORE_CAREER_KEYS=Object.freeze(Object.keys(AOR_TALENT_TREES));
export function aorTree(career,specialization){return AOR_TALENT_TREES?.[career]?.[specialization]||null;}
export function aorTalentCatalog({career=null,specialization=null,query=''}={}){
 const q=String(query).trim().toLowerCase(),rows=[];
 for(const [c,ss] of Object.entries(AOR_TALENT_TREES)) for(const [sp,t] of Object.entries(ss)){
  if(career&&c!==career)continue;if(specialization&&sp!==specialization)continue;
  for(const n of t.nodes){const r={campaignMode:'AOR',career:c,specialization:sp,...n,mechanicallyActive:true};if(!q||`${c} ${sp} ${n.name} ${n.originalName}`.toLowerCase().includes(q))rows.push(r);}
 } return rows;
}
export function aorProgressionTreeSeed(career,specialization){const t=aorTree(career,specialization);if(!t)throw new Error('Árvore AoR não encontrada');return {campaignMode:'AOR',career,specialization,tree:t,sourcePolicy:'AUDITED_PRIMARY_SOURCE'};}
export function aorTalentCoverage(){return {careers:AOR_CORE_CAREER_KEYS.length,specializations:Object.values(AOR_TALENT_TREES).reduce((n,x)=>n+Object.keys(x).length,0),positions:aorTalentCatalog().length};}
