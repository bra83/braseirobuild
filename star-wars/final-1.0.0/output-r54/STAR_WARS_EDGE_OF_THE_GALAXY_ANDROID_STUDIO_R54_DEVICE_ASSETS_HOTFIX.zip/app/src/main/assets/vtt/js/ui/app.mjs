import { LocalStorageRepository } from '../core/storage.mjs';
import { GameController } from '../core/controller.mjs';
import { SKILLS } from '../rules/character.mjs';
import { getHealthStatus } from '../rules/health.mjs';
import { CHARACTERISTIC_LABELS_PT_BR, SKILL_LABELS_PT_BR } from '../rules/labelsPtBr.mjs';
import { availableTargetRanges, attackDifficultyForWeapon } from '../rules/attackDifficulty.mjs';
import { currentSlot } from '../rules/encounter.mjs';
import { adversaryHealthStatus, aliveMinions, upgradeDifficultyForAdversaryTalent } from '../rules/adversaries.mjs';
import { nativeLibraryAvailable, listLibraryDocuments, searchImportedLibrary, requestPdfImport, removeLibraryDocument, reindexLibraryDocument, updateLibraryDocumentPolicy, libraryStatusLabel, libraryAuthorityTypeLabel } from '../library/nativeLibrary.mjs';
import { skillRankCostForCharacter, isCareerSkill, MAX_SKILL_RANK } from '../rules/progression.mjs';
import { SESSION_PHASE_LABELS_PT_BR } from '../master/sessionFlow.mjs';
import { EOTE_SPECIES, EOTE_CAREERS, OBLIGATION_TYPES_PT_BR, eoteCreationPreview } from '../rules/eoteCharacterCreation.mjs';
import { vehicleStatus, PLANETARY_RANGE_BANDS } from '../rules/vehicles.mjs';
import { speakNarration, stopNarration } from './tts.mjs';
import { IMAGE_LIBRARY_MANIFEST } from '../library/imageLibraryData.mjs';
import { getImageAsset, searchImageAssets, imageAssetRuntimeDescriptor } from '../library/imageLibrary.mjs';

const repo = new LocalStorageRepository();
const game = new GameController(repo);
const $ = id => document.getElementById(id);
const escapeHtml = value => String(value ?? '').replace(/[&<>\"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]));

const galaxyMapUi={scale:1,x:0,y:0,dragging:false,pointerId:null,lastX:0,lastY:0};
function clampMapScale(value){ return Math.max(1,Math.min(4,Number(value)||1)); }
function applyGalaxyMapTransform(){
  const img=$('galaxyMapImage'); if(!img) return;
  img.style.transform=`translate(${galaxyMapUi.x}px, ${galaxyMapUi.y}px) scale(${galaxyMapUi.scale})`;
}
function resetGalaxyMap(){ galaxyMapUi.scale=1; galaxyMapUi.x=0; galaxyMapUi.y=0; applyGalaxyMapTransform(); }
function zoomGalaxyMap(delta){
  galaxyMapUi.scale=clampMapScale(galaxyMapUi.scale+delta);
  if(galaxyMapUi.scale===1){ galaxyMapUi.x=0; galaxyMapUi.y=0; }
  applyGalaxyMapTransform();
}

const mapLibraryUi={selectedAssetId:'local.map.galaxy',statuses:new Map(),query:''};
function nativeImageLibrary(){ return globalThis.BraseiroImages && typeof globalThis.BraseiroImages.getStatus==='function' ? globalThis.BraseiroImages : null; }
function parseNativeJson(raw){ try{ const value=typeof raw==='string'?JSON.parse(raw):raw; return value&&typeof value==='object'?value:null; }catch{return null;} }
function localImageUrl(asset){ return asset?.localPath ? asset.localPath : null; }
function mapAssets(query=''){
  return searchImageAssets(IMAGE_LIBRARY_MANIFEST,{category:'map',query,limit:200});
}
function getMapCacheStatus(assetId){
  if(mapLibraryUi.statuses.has(assetId)) return mapLibraryUi.statuses.get(assetId);
  const bridge=nativeImageLibrary(); if(!bridge) return null;
  const parsed=parseNativeJson(bridge.getStatus(assetId));
  if(parsed?.ok) mapLibraryUi.statuses.set(assetId,parsed);
  return parsed?.ok?parsed:null;
}
function mapImageUrl(asset){
  if(!asset) return null;
  if(asset.sourceType!=='external_reference') return localImageUrl(asset);
  const cached=getMapCacheStatus(asset.assetId);
  if(cached?.cached && cached.runtimeUrl) return cached.runtimeUrl;
  // Browser preview fallback. Android uses only private validated cache for remote assets.
  return nativeImageLibrary()?null:(asset.remoteReady?asset.remoteUrl:null);
}
function renderMapLibrary(){
  const list=$('imageMapCatalog'); if(!list) return;
  const query=$('imageMapSearch')?.value?.trim()||''; mapLibraryUi.query=query;
  const assets=mapAssets(query);
  if(!assets.some(a=>a.assetId===mapLibraryUi.selectedAssetId)) mapLibraryUi.selectedAssetId=assets[0]?.assetId||null;
  list.innerHTML=assets.length?assets.map(asset=>{
    const cached=asset.sourceType==='external_reference'?getMapCacheStatus(asset.assetId):null;
    const offline=asset.sourceType!=='external_reference'||cached?.cached;
    return `<button type="button" class="map-library-item${asset.assetId===mapLibraryUi.selectedAssetId?' active':''}" data-map-asset="${escapeHtml(asset.assetId)}"><strong>${escapeHtml(asset.title)}</strong><span>${escapeHtml(asset.mapKind||asset.subtype||'mapa')} · ${offline?'offline':'online'}</span></button>`;
  }).join(''):'<p class="microcopy">Nenhum mapa encontrado.</p>';
  renderSelectedMapAsset();
}
function renderSelectedMapAsset(){
  const asset=getImageAsset(IMAGE_LIBRARY_MANIFEST,mapLibraryUi.selectedAssetId);
  const title=$('imageMapSelectedTitle'), meta=$('imageMapSelectedMeta'), source=$('imageMapSource'), cache=$('imageMapCache'), clear=$('imageMapClearCache');
  if(!asset){ if(title) title.textContent='Nenhum mapa selecionado'; return; }
  const status=asset.sourceType==='external_reference'?getMapCacheStatus(asset.assetId):null;
  const imgUrl=mapImageUrl(asset); const img=$('galaxyMapImage');
  if(imgUrl){ img.src=imgUrl; img.alt=asset.title; resetGalaxyMap(); }
  if(title) title.textContent=asset.title;
  if(meta) meta.textContent=`${asset.mapKind||asset.subtype||'mapa'} · ${asset.sourceType==='external_reference'?(status?.cached?'cache offline':'fonte externa'):'empacotado'}`;
  if(source){ source.hidden=!asset.sourcePageUrl; source.href=asset.sourcePageUrl||'#'; }
  if(cache){ cache.hidden=asset.sourceType!=='external_reference'||Boolean(status?.cached); cache.disabled=!asset.remoteReady||!nativeImageLibrary(); }
  if(clear){ clear.hidden=asset.sourceType!=='external_reference'||!status?.cached; }
  const feedback=$('imageMapLibraryFeedback');
  if(feedback && asset.sourceType==='external_reference' && !status?.cached && nativeImageLibrary()) feedback.textContent='Mapa externo indexado. Toque em “Guardar offline” para baixar pela origem permitida.';
  else if(feedback && imgUrl) feedback.textContent='Seleção visual apenas: não altera posição, viagem, tempo ou estado da campanha.';
}
function cacheSelectedMap(){
  const asset=getImageAsset(IMAGE_LIBRARY_MANIFEST,mapLibraryUi.selectedAssetId); const bridge=nativeImageLibrary();
  if(!asset||asset.sourceType!=='external_reference'||!bridge) return;
  const descriptor=imageAssetRuntimeDescriptor(IMAGE_LIBRARY_MANIFEST,asset);
  if(!descriptor?.remoteReady) return;
  const r=parseNativeJson(bridge.cacheRemoteImage(asset.assetId,descriptor.remoteUrl));
  const feedback=$('imageMapLibraryFeedback'); if(feedback) feedback.textContent=r?.ok?'Download enfileirado. O mapa aparecerá offline quando o cache terminar.':(r?.message||'Não foi possível iniciar o cache.');
}
function clearSelectedMapCache(){
  const asset=getImageAsset(IMAGE_LIBRARY_MANIFEST,mapLibraryUi.selectedAssetId); const bridge=nativeImageLibrary(); if(!asset||!bridge) return;
  const r=parseNativeJson(bridge.clearCachedAsset(asset.assetId)); if(r?.ok) mapLibraryUi.statuses.set(asset.assetId,{ok:true,assetId:asset.assetId,cached:false});
  renderMapLibrary();
}

const visualLibraryUi={selectedAssetId:null,query:'',kind:'all'};
function visualEntityAssets(query='',kind='all'){
  const common={query,sourceType:'external_reference',limit:500};
  let items=[];
  if(kind==='all'||kind==='npc') items.push(...searchImageAssets(IMAGE_LIBRARY_MANIFEST,{...common,category:'portrait',subtype:'npc'}));
  if(kind==='all'||kind==='droid') items.push(...searchImageAssets(IMAGE_LIBRARY_MANIFEST,{...common,category:'droid'}));
  if(kind==='all'||kind==='beast') items.push(...searchImageAssets(IMAGE_LIBRARY_MANIFEST,{...common,category:'creature',subtype:'beast'}));
  if(kind==='all'||kind==='vehicle') items.push(...searchImageAssets(IMAGE_LIBRARY_MANIFEST,{...common,category:'vehicle'}));
  return items.sort((a,b)=>a.title.localeCompare(b.title,'pt-BR')||a.assetId.localeCompare(b.assetId));
}
function visualEntityImageUrl(asset){
  if(!asset) return null;
  const cached=getMapCacheStatus(asset.assetId);
  if(cached?.cached&&cached.runtimeUrl) return cached.runtimeUrl;
  return nativeImageLibrary()?null:(asset.remoteReady?asset.remoteUrl:null);
}
function renderVisualLibrary(){
  const list=$('imageVisualCatalog'); if(!list) return;
  visualLibraryUi.query=$('imageVisualSearch')?.value?.trim()||'';
  visualLibraryUi.kind=$('imageVisualKind')?.value||'all';
  const assets=visualEntityAssets(visualLibraryUi.query,visualLibraryUi.kind);
  if(!assets.some(a=>a.assetId===visualLibraryUi.selectedAssetId)) visualLibraryUi.selectedAssetId=assets[0]?.assetId||null;
  list.innerHTML=assets.length?assets.slice(0,60).map(asset=>{
    const cached=getMapCacheStatus(asset.assetId); const kind=asset.category==='portrait'?'NPC':asset.category==='droid'?'droide':asset.category==='vehicle'?'veículo/nave':'criatura';
    return `<button type="button" class="map-library-item${asset.assetId===visualLibraryUi.selectedAssetId?' active':''}" data-visual-asset="${escapeHtml(asset.assetId)}"><strong>${escapeHtml(asset.title)}</strong><span>${kind} · ${cached?.cached?'offline':'online'}</span></button>`;
  }).join(''):'<p class="microcopy">Nenhuma referência visual encontrada.</p>';
  renderSelectedVisualAsset();
}
function renderSelectedVisualAsset(){
  const asset=getImageAsset(IMAGE_LIBRARY_MANIFEST,visualLibraryUi.selectedAssetId);
  const title=$('imageVisualSelectedTitle'),meta=$('imageVisualSelectedMeta'),source=$('imageVisualSource'),cache=$('imageVisualCache'),clear=$('imageVisualClearCache'),preview=$('imageVisualPreview');
  if(!asset){ if(title) title.textContent='Nenhuma referência selecionada'; if(preview) preview.hidden=true; return; }
  const status=getMapCacheStatus(asset.assetId); const url=visualEntityImageUrl(asset); const kind=asset.category==='portrait'?'NPC':asset.category==='droid'?'droide':asset.category==='vehicle'?'veículo/nave':'criatura';
  if(title) title.textContent=asset.title;
  if(meta) meta.textContent=`${kind} · ${status?.cached?'cache offline':'fonte externa'} · sem vínculo mecânico`;
  if(source){source.hidden=!asset.sourcePageUrl;source.href=asset.sourcePageUrl||'#';}
  if(cache){cache.hidden=Boolean(status?.cached);cache.disabled=!asset.remoteReady||!nativeImageLibrary();}
  if(clear){clear.hidden=!status?.cached;}
  if(preview){ if(url){preview.src=url;preview.alt=asset.title;preview.hidden=false;} else {preview.removeAttribute('src');preview.hidden=true;} }
}
function cacheSelectedVisualAsset(){
  const asset=getImageAsset(IMAGE_LIBRARY_MANIFEST,visualLibraryUi.selectedAssetId), bridge=nativeImageLibrary(); if(!asset||!bridge) return;
  const descriptor=imageAssetRuntimeDescriptor(IMAGE_LIBRARY_MANIFEST,asset); if(!descriptor?.remoteReady) return;
  const r=parseNativeJson(bridge.cacheRemoteImage(asset.assetId,descriptor.remoteUrl)); const feedback=$('imageVisualFeedback');
  if(feedback) feedback.textContent=r?.ok?'Download enfileirado. A referência ficará offline quando o cache terminar.':(r?.message||'Não foi possível iniciar o cache.');
}
function clearSelectedVisualAssetCache(){
  const asset=getImageAsset(IMAGE_LIBRARY_MANIFEST,visualLibraryUi.selectedAssetId), bridge=nativeImageLibrary(); if(!asset||!bridge) return;
  const r=parseNativeJson(bridge.clearCachedAsset(asset.assetId)); if(r?.ok) mapLibraryUi.statuses.set(asset.assetId,{ok:true,assetId:asset.assetId,cached:false}); renderVisualLibrary();
}
globalThis.braseiroImageLibraryNativeEvent=raw=>{
  const event=parseNativeJson(raw); const assetId=event?.data?.assetId; if(assetId){ mapLibraryUi.statuses.delete(assetId); if(assetId===mapLibraryUi.selectedAssetId) renderMapLibrary(); if(assetId===visualLibraryUi.selectedAssetId) renderVisualLibrary(); }
};


function checkedValues(hostId) {
  return [...$(hostId).querySelectorAll('input[type="checkbox"]:checked')].map(input=>input.value);
}

function populateSkillChecks(hostId, skills, namePrefix) {
  const host=$(hostId); host.innerHTML='';
  for (const key of skills) {
    const label=document.createElement('label'); label.className='creator-skill-option';
    label.innerHTML=`<input type="checkbox" value="${escapeHtml(key)}" name="${escapeHtml(namePrefix)}"> <span>${escapeHtml(SKILL_LABELS_PT_BR[key] ?? key)}</span>`;
    host.append(label);
  }
}

function creatorSelections() {
  const speciesKey=$('customSpecies').value;
  const careerKey=$('customCareer').value;
  const specializationKey=$('customSpecialization').value;
  const characteristics={};
  for (const input of $('customCharacteristics').querySelectorAll('input[data-characteristic]')) characteristics[input.dataset.characteristic]=Number(input.value);
  return {
    name:$('customName').value,
    speciesKey,careerKey,specializationKey,
    partySize:1,startingObligation:Number($('customObligation').value),obligationType:$('customObligationType').value,
    obligationBenefits:{xp5:$('obligationXp5').checked,xp10:$('obligationXp10').checked,credits1000:$('obligationCredits').checked,credits2500:$('obligationCredits2500').checked},
    speciesVariant:speciesKey==='gand'?$('customSpeciesVariant').value:null,
    characteristics,
    careerFreeSkills:checkedValues('careerFreeSkills'),
    specializationFreeSkills:checkedValues('specializationFreeSkills'),
    speciesChoiceSkills:checkedValues('speciesChoiceSkills'),
    motivation:$('customMotivation').value,
    background:$('customBackground').value
  };
}

function renderCreatorCharacteristics(speciesKey, preserve={}) {
  const species=EOTE_SPECIES[speciesKey]; const host=$('customCharacteristics'); host.innerHTML='';
  if (!species) return;
  for (const [key,base] of Object.entries(species.characteristics)) {
    const box=document.createElement('label'); box.className='creator-stat';
    const val=Math.max(base,Math.min(5,Number(preserve[key] ?? base)));
    box.innerHTML=`<span>${escapeHtml(CHARACTERISTIC_LABELS_PT_BR[key] ?? key)}</span><input data-characteristic="${escapeHtml(key)}" type="number" min="${base}" max="5" value="${val}"><small>base ${base}</small>`;
    host.append(box);
  }
}

function renderSpeciesChoice(speciesKey, careerKey, specializationKey) {
  const species=EOTE_SPECIES[speciesKey]; const wrap=$('speciesChoiceWrap'); const host=$('speciesChoiceSkills'); host.innerHTML='';
  const variantWrap=$('speciesVariantWrap');
  if(variantWrap) variantWrap.hidden=species?.speciesChoice?.type!=='gandRespiration';
  if (!species?.speciesChoice || species.speciesChoice.type==='gandRespiration') { wrap.hidden=true; return; }
  wrap.hidden=false;
  if (species.speciesChoice.type==='oneSkill') {
    $('speciesChoiceHint').textContent='Espécie: escolha 1 das perícias abaixo para receber 1 grau gratuito.';
    populateSkillChecks('speciesChoiceSkills',species.speciesChoice.skills,'speciesChoice');
    return;
  }
  const career=EOTE_CAREERS[careerKey]; const spec=career?.specializations?.[specializationKey];
  const careerSet=new Set([...(career?.skills ?? []),...(spec?.skills ?? [])]);
  const nonCareer=Object.keys(SKILLS).filter(key=>!careerSet.has(key));
  $('speciesChoiceHint').textContent='Humano: escolha exatamente 2 perícias não profissionais diferentes.';
  populateSkillChecks('speciesChoiceSkills',nonCareer,'speciesChoice');
}

function updateCharacterCreator({resetCharacteristics=false}={}) {
  const speciesKey=$('customSpecies').value;
  const careerKey=$('customCareer').value;
  const career=EOTE_CAREERS[careerKey];
  const specSelect=$('customSpecialization'); const previousSpec=specSelect.value;
  specSelect.innerHTML='';
  for (const [key,spec] of Object.entries(career?.specializations ?? {})) { const o=document.createElement('option'); o.value=key; o.textContent=spec.label; specSelect.append(o); }
  if ([...specSelect.options].some(o=>o.value===previousSpec)) specSelect.value=previousSpec;
  const specializationKey=specSelect.value;
  const species=EOTE_SPECIES[speciesKey];
  const previous={}; if (!resetCharacteristics) for (const i of $('customCharacteristics').querySelectorAll('input[data-characteristic]')) previous[i.dataset.characteristic]=Number(i.value);
  renderCreatorCharacteristics(speciesKey,previous);
  const careerCount=species?.careerFreeCount ?? 4; const specCount=species?.specFreeCount ?? 2;
  $('careerFreeHint').textContent=`Carreira: escolha exatamente ${careerCount} perícias para receber 1 grau gratuito.`;
  populateSkillChecks('careerFreeSkills',career?.skills ?? [],'careerFree');
  const spec=career?.specializations?.[specializationKey];
  $('specializationFreeHint').textContent=`Especialização: escolha exatamente ${specCount} perícias para receber 1 grau gratuito. Sobreposição pode elevar uma perícia a grau 2.`;
  populateSkillChecks('specializationFreeSkills',spec?.skills ?? [],'specFree');
  renderSpeciesChoice(speciesKey,careerKey,specializationKey);
  updateCreationPreview();
}

function updateCreationPreview() {
  try {
    const preview=eoteCreationPreview(creatorSelections());
    if (!preview) return;
    $('customCreationPreview').textContent=`PE inicial ${preview.xpBudget} · Características ${preview.characteristicCost} PE · restam ${preview.xpRemaining} PE · Obligation ${preview.obligation} · créditos ${preview.credits}.${preview.obligationOfficial?'':' Obligation solo é política local do VTT.'}`;
    $('createCustomCharacter').disabled=preview.xpRemaining<0;
  } catch(e) {
    $('customCreationPreview').textContent=e.message;
    $('createCustomCharacter').disabled=true;
  }
}

function initCharacterCreator() {
  const species=$('customSpecies'); species.innerHTML='';
  for (const [key,value] of Object.entries(EOTE_SPECIES)) { const o=document.createElement('option'); o.value=key; o.textContent=value.label; species.append(o); }
  const career=$('customCareer'); career.innerHTML='';
  for (const [key,value] of Object.entries(EOTE_CAREERS)) { const o=document.createElement('option'); o.value=key; o.textContent=value.label; career.append(o); }
  const obligation=$('customObligationType'); obligation.innerHTML=''; for(const value of OBLIGATION_TYPES_PT_BR){ const o=document.createElement('option'); o.value=value; o.textContent=value; obligation.append(o); }
  updateCharacterCreator({resetCharacteristics:true});
  for (const id of ['customSpecies','customCareer']) $(id).addEventListener('change',()=>updateCharacterCreator({resetCharacteristics:id==='customSpecies'}));
  $('customSpecialization').addEventListener('change',()=>{
    const species=EOTE_SPECIES[$('customSpecies').value]; const career=EOTE_CAREERS[$('customCareer').value]; const spec=career?.specializations?.[$('customSpecialization').value];
    populateSkillChecks('specializationFreeSkills',spec?.skills ?? [],'specFree');
    $('specializationFreeHint').textContent=`Especialização: escolha exatamente ${species?.specFreeCount ?? 2} perícias para receber 1 grau gratuito. Sobreposição pode elevar uma perícia a grau 2.`;
    renderSpeciesChoice($('customSpecies').value,$('customCareer').value,$('customSpecialization').value); updateCreationPreview();
  });
  for (const id of ['customObligation','obligationXp5','obligationXp10','obligationCredits','obligationCredits2500','customSpeciesVariant']) $(id).addEventListener('input',updateCreationPreview);
  $('customCharacteristics').addEventListener('input',updateCreationPreview);
}

function render() {
  const s = game.state;
  $('sceneTitle').textContent = s.scene.title;
  $('narration').textContent = s.scene.narration;
  $('campaignName').textContent = s.name;
  $('eventCount').textContent = `${s.events.length} evento${s.events.length===1?'':'s'}`;
  $('masterStatus').textContent = s.settings?.masterProvider==='http'
    ? 'Mestre remoto configurado · regras locais protegem a resolução'
    : 'Mestre local: índice de regras verificadas pronto; IA livre ainda não conectada';
  renderSession(s);
  renderMasterSettings(s.settings);
  renderStoredRuleResults(s.master);
  if (s.lastCheck) renderRoll(s.lastCheck);
  renderCharacter(s.player.character);
  renderProgression(s.player.character);
  renderTalents(s.player.character);
  renderEquipmentCatalog(s.player.character);
  renderFringeGroup(s);
  renderKnownFactions(s.world);
  renderKnownAftermaths(s.world);
  renderSkillSelect(s.player.character);
  renderCombat(s.player.character, s.combat);
  renderVehicle(s);
  renderLibrary();
}


function renderKnownFactions(world={}) {
  const host=$('knownFactions');
  if(!host) return;
  host.innerHTML='';
  const factions=Object.values(world?.factions??{}).filter(f=>Boolean(f.knownToPlayer));
  if(!factions.length){ host.innerHTML='<div class="result empty">Nenhuma facção conhecida ainda.</div>'; return; }
  factions.sort((a,b)=>String(a.name).localeCompare(String(b.name),'pt-BR'));
  for(const faction of factions){
    const card=document.createElement('div'); card.className='result';
    const title=document.createElement('strong'); title.textContent=faction.name; card.append(title);
    const publicFacts=(faction.facts??[]).filter(f=>f.knownToPlayer).map(f=>f.text);
    const detail=document.createElement('small'); detail.textContent=publicFacts.length?publicFacts.join(' • '):'Nenhum fato público registrado.'; card.append(detail);
    const publicPlans=(faction.plans??[]).filter(p=>p.knownToPlayer);
    for(const plan of publicPlans){ const visibleSteps=(plan.steps??[]).filter(s=>s.knownToPlayer||s.status==='completed'); const active=visibleSteps.find(s=>s.status==='active'); const line=document.createElement('small'); line.textContent=`Plano: ${plan.title} · ${plan.status==='completed'?'concluído':plan.status==='active'?'em andamento':plan.status==='aborted'?'abortado':'planejado'}${active?` · etapa atual: ${active.text}`:''}`; card.append(line); }
    host.append(card);
  }
}

function renderKnownAftermaths(world={}) {
  const host=$('knownAftermaths'); if(!host) return; host.innerHTML='';
  const items=(world?.aftermaths??[]).filter(a=>a.status==='active'&&a.knownToPlayer);
  if(!items.length){ host.innerHTML='<div class="result empty">Nenhuma consequência duradoura conhecida.</div>'; return; }
  items.sort((a,b)=>(a.createdAtTick??0)-(b.createdAtTick??0));
  for(const item of items){
    const card=document.createElement('div'); card.className='result';
    const title=document.createElement('strong'); title.textContent=item.summary || 'Consequência persistente'; card.append(title);
    const detail=document.createElement('small'); detail.textContent=`Desfecho: ${String(item.outcome||'registrado').replaceAll('_',' ')}${item.planId?' · ligado a um plano de facção':''}`; card.append(detail);
    host.append(card);
  }
}

function renderSession(state) {
  const session=state.session;
  const hasCharacter=Boolean(state.player?.character);
  const active=session?.status==='ativa';
  $('sessionStatus').textContent=active
    ? `Sessão ${session.number} · ${SESSION_PHASE_LABELS_PT_BR[session.phase] ?? session.phase}`
    : session?.status==='encerrada'
      ? `Sessão ${session.number} encerrada`
      : 'Nenhuma sessão iniciada';
  $('startSession').hidden=active;
  $('startSession').disabled=!hasCharacter || state.combat?.active;
  $('closeSession').hidden=!active;
  $('closeSession').disabled=Boolean(state.combat?.active);
  $('sessionHistoryCount').textContent=`${state.sessionHistory?.length ?? 0} sessão(ões) encerrada(s)`;
  const prompt=$('masterPrompt');
  const suggested=$('suggestedCheckCard');
  const question=state.master?.pendingQuestion;
  prompt.hidden=!question;
  prompt.textContent=question ? `Mestre: ${question}` : '';
  const check=state.master?.suggestedCheck;
  suggested.hidden=!check;
  if (check) {
    const label=SKILL_LABELS_PT_BR[check.skillKey] ?? check.skillKey;
    $('suggestedCheckText').textContent=`${label} · Dificuldade ${check.difficulty}${check.challenge?` · Desafio ${check.challenge}`:''}${check.boost?` · Impulso ${check.boost}`:''}${check.setback?` · Contratempo ${check.setback}`:''}${check.reason?` · ${check.reason}`:''}`;
  }
}

function renderMasterSettings(settings={}) {
  const mode=settings.masterProvider==='http'?'http':'none';
  $('masterProviderMode').value=mode;
  $('masterEndpointWrap').hidden=mode!=='http';
  $('masterEndpoint').value=settings.masterEndpoint ?? '';
  $('ttsEnabled').checked=Boolean(settings.ttsEnabled);
  $('ttsRate').value=String(settings.ttsRate ?? 1);
  if (![...$('ttsRate').options].some(o=>o.value===$('ttsRate').value)) $('ttsRate').value='1';
}

function renderStoredRuleResults(master) {
  if (!master?.lastRuleQuery || !Array.isArray(master.lastRuleResults) || !master.lastRuleResults.length) return;
  $('ruleQuery').value=master.lastRuleQuery;
  renderRuleResults({query:master.lastRuleQuery,grounded:master.lastRuleResults.some(r=>['TESTADO','IMPLEMENTADO','FONTE_IMPORTADA'].includes(r.status)&&r.summary&&r.summary!=='A_AUDITAR'),results:master.lastRuleResults,retrieval:{authority:master.lastRuleAuthority ?? null}});
}

function renderRuleResults(result) {
  const host=$('ruleResults'); host.innerHTML='';
  if (!result.results?.length) {
    host.innerHTML='<div class="result fail">Nenhuma regra pertinente foi encontrada no corpus auditado.</div>';
    $('ruleQueryStatus').textContent='Sem evidência local suficiente.';
    return;
  }
  const authority=result.retrieval?.authority;
  $('ruleQueryStatus').textContent=result.grounded
    ? `Consulta fundamentada · ${result.results.length} resultado(s).${authority?.precedenceApplied?' Ordem de autoridade aplicada.':''}`
    : 'Atenção: o resultado principal ainda é uma lacuna não auditada.';
  for (const rule of result.results) {
    const card=document.createElement('article'); card.className=`rule-result-card ${['TESTADO','IMPLEMENTADO','FONTE_IMPORTADA'].includes(rule.status)?'grounded':'pending'}`;
    const sourcePage=rule.page!==null&&rule.page!==undefined ? ` · pág. ${rule.page}` : '';
    const badge=rule.status==='FONTE_IMPORTADA' ? `PDF · ${libraryAuthorityTypeLabel(rule.authorityType)}` : rule.official===false ? 'Política local do Mestre' : rule.status;
    const summary=rule.summary==='A_AUDITAR'?'Ainda não há evidência auditada suficiente para esta regra.':rule.summary;
    card.innerHTML=`<div class="rule-result-head"><strong>${escapeHtml(rule.title)}</strong><span>${escapeHtml(badge)}</span></div><p>${escapeHtml(summary)}</p><small>${escapeHtml(rule.source ?? 'Fonte não registrada')}${escapeHtml(sourcePage)}</small>`;
    host.append(card);
  }
}

function formatBytes(value=0) {
  const bytes=Number(value)||0;
  if (bytes < 1024*1024) return `${Math.max(1,Math.round(bytes/1024))} KB`;
  return `${(bytes/(1024*1024)).toFixed(bytes>100*1024*1024?0:1)} MB`;
}

function renderLibrary() {
  const available=nativeLibraryAvailable();
  $('importLibraryPdf').disabled=!available;
  $('searchLibrary').disabled=!available;
  $('libraryQuery').disabled=!available;
  $('libraryEnvironmentStatus').textContent=available
    ? 'Modo Android: PDFs ficam anexados no armazenamento privado e o índice é consultável sem internet.'
    : 'Preview de navegador: a Biblioteca pode ser visualizada, mas importar/indexar PDF exige o aplicativo Android com a ponte nativa.';
  const docs=listLibraryDocuments();
  $('libraryDocumentCount').textContent=String(docs.length);
  $('libraryIndexedCount').textContent=String(docs.filter(d=>d.status==='INDEXADO').length);
  const host=$('libraryDocuments'); host.innerHTML='';
  if (!docs.length) { host.innerHTML='<div class="result empty">Nenhum PDF importado.</div>'; return; }
  for (const doc of docs) {
    const row=document.createElement('article'); row.className='library-row';
    const pages=Number(doc.pageCount||0); const indexed=Number(doc.indexedPages||0);
    const authority=String(doc.authorityType || 'SUPLEMENTO').toUpperCase();
    const enabled=doc.enabled!==false;
    row.dataset.docId=doc.docId;
    row.innerHTML=`<div class="library-row-main"><strong>${escapeHtml(doc.title || doc.fileName || 'PDF importado')}</strong><span>${escapeHtml(libraryStatusLabel(doc.status))} · ${pages} pág. · ${formatBytes(doc.sizeBytes)}</span><small>${indexed}/${pages || 0} páginas com texto · armazenamento privado offline</small><div class="library-policy"><label>Autoridade<select class="library-authority" aria-label="Autoridade de ${escapeHtml(doc.title || doc.fileName)}"><option value="ERRATA">Errata / correção</option><option value="BASE">Livro básico</option><option value="SUPLEMENTO">Complemento de regras</option><option value="AVENTURA">Aventura / cenário</option><option value="REFERENCIA">Referência</option></select></label><label class="library-enabled-label"><input class="library-enabled" type="checkbox" ${enabled?'checked':''}> Usar no Mestre</label></div>${doc.lastError?`<small class="library-error">Último erro: ${escapeHtml(doc.lastError)}</small>`:''}</div><div class="library-actions"><button class="library-reindex" data-doc-id="${escapeHtml(doc.docId)}">Reindexar</button><button class="library-remove" data-doc-id="${escapeHtml(doc.docId)}" aria-label="Remover ${escapeHtml(doc.title || doc.fileName)}">Remover</button></div>`;
    row.querySelector('.library-authority').value=['ERRATA','BASE','SUPLEMENTO','AVENTURA','REFERENCIA'].includes(authority)?authority:'SUPLEMENTO';
    host.append(row);
  }
}

function renderLibrarySearch(results=[]) {
  const host=$('librarySearchResults'); host.innerHTML='';
  if (!results.length) { host.innerHTML='<div class="result fail">Nenhum trecho encontrado nos PDFs indexados.</div>'; return; }
  for (const result of results) {
    const card=document.createElement('article'); card.className='rule-result-card grounded';
    const page=result.page ? ` · pág. ${result.page}` : '';
    card.innerHTML=`<div class="rule-result-head"><strong>${escapeHtml(result.title)}</strong><span>${escapeHtml(libraryAuthorityTypeLabel(result.authorityType))}</span></div><p>${escapeHtml(result.summary)}</p><small>${escapeHtml(result.source)}${escapeHtml(page)}</small>`;
    host.append(card);
  }
}

function renderRoll(r) {
  const el = $('rollResult');
  const state = r.success ? 'SUCESSO' : 'FALHA';
  const second = r.netAdvantage > 0 ? `Vantagem +${r.netAdvantage}` : r.netAdvantage < 0 ? `Ameaça ${Math.abs(r.netAdvantage)}` : 'Sem Vantagem/Ameaça líquida';
  const specials = [r.triumph ? `Triunfo ${r.triumph}` : '', r.despair ? `Desesperação ${r.despair}` : ''].filter(Boolean).join(' · ');
  el.className = `result ${r.success ? 'success' : 'fail'}`;
  const expert=r.expertTalent?.used ? ` · ${r.expertTalent.label}: -1 Dificuldade, 2 Tensão` : '';
  el.textContent = `${state} · Êxito líquido ${r.netSuccess} · ${second}${specials ? ` · ${specials}` : ''}${expert}`;
}

function playerInitiativeReady(combat) {
  if (!combat?.active) return false;
  if (!combat.encounter?.slots?.length) return true;
  const slot=currentSlot(combat);
  return Boolean(slot?.side==='player' && combat.encounter.waitingForPlayer);
}

function renderSkillSelect(character) {
  const select = $('skillSelect');
  select.innerHTML = '';
  if (!character) {
    const opt=document.createElement('option'); opt.value=''; opt.textContent='Sem personagem carregado'; select.append(opt); select.disabled=true;
    $('checkHint').textContent='Carregue um personagem para usar suas perícias automaticamente.';
    renderExpertTalentOption(null);
    return;
  }
  select.disabled=false;
  const keys = Object.keys(character.skills).filter(k => k in SKILLS);
  keys.sort((a,b)=>(SKILL_LABELS_PT_BR[a]??a).localeCompare(SKILL_LABELS_PT_BR[b]??b,'pt-BR'));
  for (const key of keys) {
    const opt=document.createElement('option');
    const characteristic=CHARACTERISTIC_LABELS_PT_BR[SKILLS[key]] ?? SKILLS[key];
    opt.value=key; opt.textContent=`${SKILL_LABELS_PT_BR[key] ?? key} ${character.skills[key]} · ${characteristic} ${character.characteristics[SKILLS[key]]}`;
    select.append(opt);
  }
  $('checkHint').textContent=game.state.combat.active
    ? 'Em combate, usar uma perícia consome a ação da sua posição de iniciativa.'
    : 'A reserva é montada automaticamente a partir da característica e do grau da perícia da ficha.';
  renderExpertTalentOption(character);
}

function renderExpertTalentOption(character) {
  const row=$('expertTalentRow');
  if(!row) return;
  const skill=$('skillSelect').value;
  const config=skill==='astronavegacion' ? {original:'MASSTAR',label:'Navegador mestre'} : null;
  const available=Boolean(character&&config&&game.talentRank(config.original)>0);
  row.hidden=!available;
  $('useExpertTalent').checked=available ? $('useExpertTalent').checked : false;
  if(available) $('expertTalentLabel').textContent=`Usar ${config.label}: sofrer 2 de Tensão e reduzir a Dificuldade em 1 (mín. Fácil)`;
}

function selectedWeapon(character) {
  if (!character) return null;
  return character.weapons?.[Number($('weaponSelect').value)] ?? character.weapons?.[0] ?? null;
}

function selectedAdversary() {
  const id=$('targetAdversary')?.value;
  return game.state.combat.adversaries?.find(a=>a.id===id) ?? null;
}

function renderAttackRangeControls(character) {
  const weapon=selectedWeapon(character);
  const rangeSelect=$('targetRange');
  const previous=rangeSelect.value;
  rangeSelect.innerHTML='';
  if (!weapon) {
    $('attackDifficultyText').textContent='Nenhuma arma disponível.';
    return;
  }

  const adversary=selectedAdversary();
  if (game.state.combat.encounter && adversary) {
    const opt=document.createElement('option'); opt.value=adversary.range; opt.textContent=adversary.range; rangeSelect.append(opt);
    rangeSelect.disabled=true;
    try {
      const difficulty=attackDifficultyForWeapon(weapon, adversary.range);
      const upgrades=upgradeDifficultyForAdversaryTalent(adversary);
      $('attackDifficultyText').textContent=upgrades>0
        ? `Dificuldade base ${difficulty} · Adversário ${upgrades} melhora a dificuldade · alcance ${adversary.range}.`
        : `Dificuldade automática: ${difficulty} · alcance ${adversary.range}.`;
    } catch(e) { $('attackDifficultyText').textContent=e.message; }
    return;
  }

  rangeSelect.disabled=false;
  const ranges=availableTargetRanges(weapon);
  for (const range of ranges) {
    const opt=document.createElement('option'); opt.value=range; opt.textContent=range; rangeSelect.append(opt);
  }
  const preferred=[previous, weapon.range, 'Médio', 'Curto', 'Interação'].find(v=>ranges.includes(v));
  if (preferred) rangeSelect.value=preferred;
  try {
    const difficulty=attackDifficultyForWeapon(weapon, rangeSelect.value);
    $('attackDifficultyText').textContent=`Dificuldade automática: ${difficulty} · alcance ${rangeSelect.value}.`;
  } catch(e) { $('attackDifficultyText').textContent=e.message; }
}

function stimpackQuantity(character) {
  if (!character) return 0;
  const item=character.gear.find(g=>/injetor(?:es)? de estimulantes?/i.test(g.name));
  return Number(item?.quantity ?? 0);
}

function renderCharacter(character) {
  $('noCharacter').hidden=Boolean(character);
  $('characterData').hidden=!character;
  if (!character) return;
  const health=getHealthStatus(character);
  $('characterName').textContent=character.name;
  $('characterMeta').textContent=[character.species,character.profession].filter(Boolean).join(' · ') || 'Ficha local';
  $('xpAvailable').textContent=character.xp.available;
  $('soakValue').textContent=character.derived.soak;
  $('woundsValue').textContent=`${character.derived.wounds.current}/${character.derived.wounds.threshold}`;
  $('strainValue').textContent=`${character.derived.strain.current}/${character.derived.strain.threshold}`;
  $('healthStatusValue').textContent=health.label;
  $('creditsValue').textContent=character.credits;
  $('criticalsValue').textContent=character.criticalInjuries.length;

  const stats=$('characteristics'); stats.innerHTML='';
  for (const [key,value] of Object.entries(character.characteristics)) {
    const item=document.createElement('div'); item.innerHTML=`<span>${CHARACTERISTIC_LABELS_PT_BR[key] ?? key}</span><strong>${value}</strong>`; stats.append(item);
  }

  const skills=$('trainedSkills'); skills.innerHTML='';
  const trained=Object.entries(character.skills).filter(([,rank])=>rank>0).sort((a,b)=>b[1]-a[1] || (SKILL_LABELS_PT_BR[a[0]]??a[0]).localeCompare(SKILL_LABELS_PT_BR[b[0]]??b[0],'pt-BR'));
  for (const [key,rank] of trained) {
    const row=document.createElement('div'); row.className='skill-row'; row.innerHTML=`<span>${SKILL_LABELS_PT_BR[key] ?? key}</span><strong>${rank}</strong>`; skills.append(row);
  }
  if (!trained.length) skills.textContent='Nenhuma perícia treinada.';

  const gear=$('gearList'); gear.innerHTML='';
  for (const w of character.weapons) {
    const extras=[`Dano ${w.damage}`,w.range,w.crit?`Crítico ${w.crit}`:'',w.pierce?`Perfuração ${w.pierce}`:'',w.damageType==='strain'?'Atordoante':''].filter(Boolean).join(' · ');
    const row=document.createElement('div'); row.className='gear-row'; row.innerHTML=`<span>${w.name}</span><small>${extras}</small>`; gear.append(row);
  }
  for (const g of character.gear) {
    const row=document.createElement('div'); row.className='gear-row'; row.innerHTML=`<span>${g.name}</span><small>${g.quantity && g.quantity>1 ? `x${g.quantity}` : g.quantity===0 ? 'Esgotado' : 'Equipamento'}</small>`; gear.append(row);
  }
  $('sourceNote').textContent=character.source?.type==='eote_test_fixture' ? 'Fixture local de teste EotE; não é personagem oficial nem fonte de regra.' : character.source?.type==='custom_aor_core' ? 'Ficha legada de Age of Rebellion preservada apenas para migração; Duty não é mecânica ativa no perfil EotE.' : 'Ficha local.';
}

function renderTalents(character) {
  const host=$('talentOptions'); if(!host) return; host.innerHTML='';
  if(!character){ host.innerHTML='<div class="result empty">Carregue um personagem.</div>'; return; }
  const options=game.availableTalents();
  if(!options.length){ host.innerHTML='<div class="result empty">Esta ficha não possui uma especialização inicial mapeada para compras automáticas de talentos.</div>'; return; }
  const ranks=game.talentRanks();
  for(let tier=1;tier<=5;tier++){
    const tierNodes=options.filter(t=>t.row===tier);
    if(!tierNodes.length) continue;
    const title=document.createElement('div'); title.className='talent-tier'; title.textContent=`Linha ${tier} · ${tier*5} PE por espaço`; host.append(title);
    for(const t of tierNodes){
      const status=t.purchased?'Adquirido':!t.unlocked?'Bloqueado':!t.available?'PE insuficientes':'Disponível';
      const row=document.createElement('div'); row.className=`talent-row ${t.purchased?'purchased':t.unlocked?'unlocked':'locked'}`;
      const choice=t.needsChoice&&!t.purchased ? `<select class="talent-characteristic" aria-label="Característica para Dedicação">${Object.entries(CHARACTERISTIC_LABELS_PT_BR).map(([key,label])=>`<option value="${escapeHtml(key)}">${escapeHtml(label)}</option>`).join('')}</select>` : '';
      row.innerHTML=`<div><strong>${escapeHtml(t.name)}</strong><small>Linha ${t.row} · coluna ${t.column} · ${t.cost} PE · ${status}${ranks[t.name]?` · grau atual ${ranks[t.name]}`:''}</small>${choice}</div><button class="secondary buy-talent" data-talent-id="${escapeHtml(t.id)}" ${!t.available?'disabled':''}>${t.purchased?'Adquirido':t.unlocked?'Comprar':'Bloqueado'}</button>`;
      host.append(row);
    }
  }
}

function renderEquipmentCatalog(character){
  const weaponsHost=$('catalogWeapons'), armorHost=$('catalogArmor'); if(!weaponsHost||!armorHost) return;
  weaponsHost.innerHTML=''; armorHost.innerHTML='';
  const catalog=game.equipmentCatalog();
  const pending=game.state.master?.pendingAcquisition ?? null;
  for(const item of catalog.weapons){
    const row=document.createElement('div'); row.className='catalog-row';
    const restriction=item.restricted?' · Restrita':'';
    const damage=item.damageBonus!==null&&item.damageBonus!==undefined?`Fortaleza ${item.damageBonus>=0?'+':''}${item.damageBonus}`:`${item.damage}`;
    row.innerHTML=`<div><strong>${escapeHtml(item.name)}</strong><small>Dano ${escapeHtml(damage)} · Crítico ${item.crit??'—'} · ${escapeHtml(item.range)} · ${item.price.toLocaleString('pt-BR')} créditos · raridade ${item.rarity}${restriction}</small>${item.qualities?.length?`<small>${escapeHtml(item.qualities.join(' · '))}</small>`:''}</div><button class="secondary propose-weapon" data-item-id="${escapeHtml(item.id)}" ${character&&!pending?'':'disabled'}>${pending?.itemId===item.id?'Aguardando Mestre':'Propor aquisição'}</button>`;
    weaponsHost.append(row);
  }
  if(pending) showFeedback('equipmentCatalogFeedback',`Aguardando o Mestre resolver: ${pending.itemName} · preço listado ${Number(pending.listedPrice).toLocaleString('pt-BR')} créditos · raridade ${pending.rarity}${pending.restricted?' · restrita':''}.`);
  else showFeedback('equipmentCatalogFeedback','');
  for(const item of catalog.armor){
    const row=document.createElement('div'); row.className='catalog-row reference';
    row.innerHTML=`<div><strong>${escapeHtml(item.name)}</strong><small>Defesa ${item.defense} · Proteção ${item.soak} · preço não consta nesta tabela-resumo</small></div>`;
    armorHost.append(row);
  }
}

function linesFromTextarea(id){ return $(id).value.split(/\r?\n/).map(v=>v.trim()).filter(Boolean); }
function renderFringeGroup(state){
  if(!$('groupBaseName')) return;
  const summary=game.groupSummary(); const g=summary.group;
  $('groupBaseName').value=g.base?.name??'Refúgio / Base';
  $('groupBaseLocation').value=g.base?.location??'';
  $('groupBaseDescription').value=g.base?.description??'';
  $('groupObligationTotal').textContent=String(summary.obligationTotal);
  $('groupResources').value=(g.resources??[]).join('\n');
  $('groupBelongings').value=(g.belongings??[]).join('\n');
  $('groupContacts').value=(g.contacts??[]).join('\n');
  $('groupDestinyLight').value=String(g.destiny?.light??0);
  $('groupDestinyDark').value=String(g.destiny?.dark??0);
  const host=$('groupObligationEntries'); host.innerHTML='';
  if(!(g.obligationEntries??[]).length){ host.innerHTML='<div class="result empty">Nenhuma Obligation do grupo registrada.</div>'; }
  for(const e of (g.obligationEntries??[])){
    const row=document.createElement('div'); row.className='gear-row group-obligation-row';
    row.innerHTML=`<span><strong>${escapeHtml(e.member||'Grupo')}</strong> · ${escapeHtml(e.type||'Obligation')} · ${Number(e.value)||0}</span><small>${escapeHtml(e.description||'Sem descrição')}</small><button class="icon-btn remove-group-obligation" data-obligation-id="${escapeHtml(e.id)}" aria-label="Remover Obligation">×</button>`;
    host.append(row);
  }
}

function renderProgression(character) {
  const select=$('progressSkill');
  const button=$('trainSkill');
  if (!character) {
    select.innerHTML='<option value="">Sem personagem</option>';
    select.disabled=true; button.disabled=true;
    $('progressCost').textContent='Carregue uma ficha para usar PE.';
    return;
  }
  const previous=select.value;
  select.innerHTML='';
  const keys=Object.keys(character.skills).filter(k=>Number.isInteger(character.skills[k]) && character.skills[k]<MAX_SKILL_RANK);
  keys.sort((a,b)=>(SKILL_LABELS_PT_BR[a]??a).localeCompare(SKILL_LABELS_PT_BR[b]??b,'pt-BR'));
  for (const key of keys) {
    const rank=character.skills[key];
    const career=isCareerSkill(character,key);
    let cost='—';
    try { cost=skillRankCostForCharacter(character,key); } catch {}
    const opt=document.createElement('option'); opt.value=key; opt.textContent=`${SKILL_LABELS_PT_BR[key] ?? key} ${rank}→${rank+1} · ${career?'profissional':'não profissional'} · ${cost} PE`; select.append(opt);
  }
  select.disabled=!keys.length;
  if ([...select.options].some(o=>o.value===previous)) select.value=previous;
  const selected=select.value;
  if (!selected) { $('progressCost').textContent='Todas as perícias disponíveis já estão no grau máximo.'; button.disabled=true; return; }
  const cost=skillRankCostForCharacter(character,selected);
  const career=isCareerSkill(character,selected);
  $('progressCost').textContent=`Próximo grau: ${cost} PE · ${career?'perícia profissional':'perícia não profissional'} · saldo ${character.xp.available} PE.`;
  button.disabled=character.xp.available<cost;
}

function renderEncounter(combat) {
  const panel=$('initiativePanel');
  const encounter=combat.encounter;
  const targetWrap=$('targetAdversaryWrap');
  if (!combat.active || !encounter?.slots?.length) {
    panel.hidden=true;
    targetWrap.hidden=true;
    $('targetAdversary').innerHTML='';
    return;
  }
  panel.hidden=false;
  targetWrap.hidden=false;
  const slot=currentSlot(combat);
  if (encounter.outcome==='player_incapacitated') $('initiativeStatus').textContent='Você está incapacitado';
  else if (encounter.outcome==='adversaries_defeated') $('initiativeStatus').textContent='Todos os adversários foram derrotados';
  else $('initiativeStatus').textContent=slot?.side==='player' ? 'Sua posição de iniciativa' : 'Posição de PNPC';
  $('initiativeSlots').textContent=encounter.slots.map((s,i)=>`${i===encounter.cursor?'[':''}${s.side==='player'?'PJ':'PNPC'}${i===encounter.cursor?']':''}`).join(' · ');

  const list=$('adversaryList'); list.innerHTML='';
  for (const adv of combat.adversaries ?? []) {
    const health=adversaryHealthStatus(adv);
    const row=document.createElement('div'); row.className=`adversary-row${health.incapacitated?' defeated':''}`;
    const left=document.createElement('div');
    const title=document.createElement('strong'); title.textContent=adv.name; left.append(title);
    const meta=document.createElement('span');
    const faction=adv.factionId ? game.state.world?.factions?.[adv.factionId] : null;
    const factionLabel=faction?.knownToPlayer ? ` · ${faction.name}` : '';
    meta.textContent=(adv.kind==='minion'
      ? `Lacaios ${aliveMinions(adv)}/${adv.membersTotal} · ${adv.range}`
      : `${adv.kind==='rival'?'Rival':'Antagonista'} · ${adv.range}`) + factionLabel;
    left.append(meta);
    const right=document.createElement('small'); right.textContent=`Ferimentos ${adv.wounds.current}/${adv.wounds.threshold} · ${health.label}`;
    row.append(left,right); list.append(row);
  }

  const target=$('targetAdversary');
  const previous=target.value;
  target.innerHTML='';
  for (const adv of combat.adversaries ?? []) {
    if (adversaryHealthStatus(adv).incapacitated) continue;
    const opt=document.createElement('option'); opt.value=adv.id; opt.textContent=adv.name; target.append(opt);
  }
  if ([...target.options].some(o=>o.value===previous)) target.value=previous;

  const log=$('npcTurnLog');
  const recent=(combat.log ?? []).filter(e=>e.type==='TURNO_NPC').slice(-3);
  log.textContent=recent.length ? recent.map(e=>e.summary).join(' • ') : 'Nenhum turno automático de PNPC executado ainda.';
}

function renderCombat(character, combat) {
  $('combatNoCharacter').hidden=Boolean(character);
  $('combatData').hidden=!character;
  if (!character) return;
  const health=getHealthStatus(character);
  const ready=playerInitiativeReady(combat);
  $('combatCharacterName').textContent=character.name;
  $('combatHealthLine').textContent=`${health.label} · Ferimentos ${character.derived.wounds.current}/${character.derived.wounds.threshold} · Tensão ${character.derived.strain.current}/${character.derived.strain.threshold}`;
  $('combatRound').textContent=combat.active ? combat.round : '—';
  $('combatActionState').textContent=combat.active ? (combat.playerTurn.actionUsed?'Usada':ready?'Disponível':'Aguardando') : 'Fora de combate';
  $('combatManeuverState').textContent=combat.active ? `${combat.playerTurn.maneuversUsed}/2` : '—';
  const quickRank=game.talentRank('REACCIÓN RÁPIDA');
  $('quickReactionStrain').max=String(quickRank);
  if(Number($('quickReactionStrain').value)>quickRank) $('quickReactionStrain').value=String(quickRank);
  $('quickReactionStrain').disabled=combat.active || health.unconscious || quickRank<=0;
  $('quickReactionHelp').textContent=quickRank>0 ? `Pode sofrer até ${quickRank} de Tensão para adicionar a mesma quantidade de dados de Impulso à iniciativa.` : 'Sem Reação rápida adquirida.';
  $('startEncounter').disabled=combat.active || health.unconscious;
  const pendingEncounter=game.state.master?.pendingEncounter;
  $('masterEncounterCard').hidden=!pendingEncounter || combat.active;
  if(pendingEncounter){
    const groups=pendingEncounter.adversaries.map(a=>`${a.count>1?`${a.count}× `:''}${game.adversaryProfiles()[a.profileKey]?.name ?? a.profileKey}`).join(', ');
    $('masterEncounterText').textContent=`${groups}${pendingEncounter.sourceHookId?' · consequência do mundo':''}. Você ainda escolhe se usa Reação rápida antes da iniciativa.`;
  }
  $('startPendingEncounter').disabled=!pendingEncounter || combat.active || health.unconscious;
  $('combatCause').hidden=!combat.causalHookSummary;
  $('combatCause').textContent=combat.causalHookSummary?`Consequência causal: ${combat.causalHookSummary}`:'';
  $('startCombat').disabled=combat.active || health.unconscious;
  $('nextTurn').disabled=!combat.active || health.unconscious || (combat.encounter && !ready);
  $('endCombat').disabled=!combat.active;
  renderEncounter(combat);

  $('normalManeuver').disabled=!combat.active || !ready || health.unconscious || combat.playerTurn.maneuversUsed>=2;
  $('strainManeuver').disabled=!combat.active || !ready || health.unconscious || combat.playerTurn.maneuversUsed!==1;
  $('actionManeuver').disabled=!combat.active || !ready || health.unconscious || combat.playerTurn.maneuversUsed!==1 || combat.playerTurn.actionUsed;
  $('aimButton').disabled=!combat.active || !ready || health.unconscious || combat.playerTurn.maneuversUsed>=2;
  $('aimStatus').textContent=Number(combat.pendingAttackBoost ?? 0)>0
    ? `Mirar preparado: +${combat.pendingAttackBoost} dado de Impulso no próximo ataque.`
    : 'Nenhum bônus de Mirar preparado.';

  const select=$('weaponSelect');
  const previous=select.value;
  select.innerHTML='';
  character.weapons.forEach((weapon,index)=>{
    const opt=document.createElement('option'); opt.value=String(index); opt.textContent=`${weapon.name} · Dano ${weapon.damage} · ${weapon.range}`; select.append(opt);
  });
  if ([...select.options].some(o=>o.value===previous)) select.value=previous;
  renderAttackRangeControls(character);
  $('attackButton').disabled=!character.weapons.length || health.unconscious || (combat.active && (!ready || combat.playerTurn.actionUsed));

  const last=combat.lastAttack;
  if (last) renderAttack(last);
  $('activateCritical').hidden=!combat.pendingPlayerCritical;
  $('activateCritical').disabled=!combat.pendingPlayerCritical;
  const stimHeal=Math.max(1,5-Math.max(0,Number(character?.stimpackUsesToday??0)||0));
  $('stimpackCount').textContent=`Injetores disponíveis: ${stimpackQuantity(character)}. Próximo uso cura até ${stimHeal} Ferimento${stimHeal===1?'':'s'} e consome 1 injetor.`;
  $('useStimpack').disabled=health.unconscious || stimpackQuantity(character)<=0 || (combat.active && (!ready || combat.playerTurn.maneuversUsed>=2));
  $('medicineButton').disabled=health.unconscious || (combat.active && (!ready || combat.playerTurn.actionUsed || combat.medicineUsed));
  $('restNightButton').disabled=combat.active;
}

function renderAttack(attack) {
  const el=$('attackResult');
  const context=[attack.targetName || '',attack.targetRange ? `Alcance ${attack.targetRange}` : '', Number.isFinite(attack.difficulty) ? `Dificuldade ${attack.difficulty}` : '', attack.challenge ? `Desafio ${attack.challenge}` : ''].filter(Boolean).join(' · ');
  if (!attack.hit) {
    const advantage=attack.check.netAdvantage>0?` · Vantagem ${attack.check.netAdvantage}`:attack.check.netAdvantage<0?` · Ameaça ${Math.abs(attack.check.netAdvantage)}`:'';
    el.className='result fail'; el.textContent=`FALHA${context?` · ${context}`:''}${advantage}`; return;
  }
  const parts=[`ACERTO · Dano ${attack.damage}`];
  if (context) parts.push(context);
  if (attack.pierce) parts.push(`Perfuração ${attack.pierce}`);
  if (attack.damageType==='strain') parts.push('Dano de Tensão');
  if (attack.quickStrikeBoost>0) parts.push(`Ataque rápido +${attack.quickStrikeBoost} Impulso`);
  if (attack.targetDamage) parts.push(`Alvo sofreu ${attack.targetDamage.suffered} Ferimento(s) após Proteção`);
  else parts.push('Dano deve ser reduzido pela Proteção do alvo');
  if (attack.criticalAvailable) parts.push(attack.criticalByTriumph ? 'Crítico disponível por Triunfo' : `Crítico disponível por ${attack.criticalCost} Vantagens`);
  if (attack.blastAvailable) parts.push(`Explosão disponível · dano ${attack.blastDamage}`);
  el.className='result success'; el.textContent=parts.join(' · ');
}

function initVehicleProfiles(){
  const select=$('vehicleProfileSelect'); if(!select) return; select.innerHTML='';
  for(const [key,p] of Object.entries(game.vehicleProfiles())){ const o=document.createElement('option'); o.value=key; o.textContent=`${p.shortName} · ${p.faction}`; select.append(o); }
}

function renderVehicle(state){
  if(!$('vehicleData')) return;
  const vehicle=game.activeVehicle(); $('vehicleNoActive').hidden=Boolean(vehicle); $('vehicleData').hidden=!vehicle;
  if(!vehicle) return;
  const status=vehicleStatus(vehicle,{operator:state.player?.character}); const combat=state.vehicles?.combat ?? {};
  $('vehicleName').textContent=vehicle.shortName ?? vehicle.name; $('vehicleMeta').textContent=[vehicle.type,vehicle.faction,vehicle.hyperdrive?'hiperimpulsor':'sem hiperimpulsor'].filter(Boolean).join(' · ');
  $('vehicleSpeed').textContent=`${vehicle.speed}/${vehicle.speedMax}`; $('vehicleSilhouette').textContent=vehicle.silhouette; $('vehicleHandling').textContent=vehicle.handling>=0?`+${vehicle.handling}`:vehicle.handling; $('vehicleArmor').textContent=vehicle.armor;
  $('vehicleHull').textContent=`${vehicle.hullDamage}/${vehicle.hullThreshold}`; $('vehicleStrain').textContent=`${vehicle.systemStrain}/${vehicle.systemStrainThreshold}`; $('vehicleDefense').textContent=`${status.defense.proa}/${status.defense.popa}`; $('vehicleStatus').textContent=status.label;
  const ft=vehicle.roundEffects?.fullThrottle;
  $('vehicleCombatLine').textContent=combat.active?`Assalto ${combat.round} · alcance ${combat.range} · ação ${combat.actionUsed?'usada':'disponível'} · manobras ${combat.maneuversUsed}/2${ft?` · Aceleração máxima +${ft.bonus} até o assalto ${ft.expiresAfterRound}`:''}`:'Fora de combate.';
  $('startVehicleCombat').disabled=combat.active; $('nextVehicleRound').disabled=!combat.active; $('endVehicleCombat').disabled=!combat.active; $('vehicleAttack').disabled=!combat.active || combat.actionUsed || !status.weaponsOnline;
  const hasFullThrottle=game.talentRank('FULLTH')>0;
  const hasImprovedFullThrottle=game.talentRank('FULLTHIMP')>0;
  $('fullThrottleAction').disabled=!combat.active || combat.actionUsed || !hasFullThrottle;
  $('fullThrottleManeuver').disabled=!combat.active || combat.maneuversUsed>=2 || !hasImprovedFullThrottle;
  $('controlledFireAction').hidden=true; $('controlledFireAction').disabled=true;
  const weapons=$('vehicleWeaponSelect'); const prev=weapons.value; weapons.innerHTML=''; const combatRangeIndex=PLANETARY_RANGE_BANDS.indexOf(combat.range); let firstInRange=null; for(const [i,w] of vehicle.weapons.entries()){const o=document.createElement('option');o.value=i; const maxRangeIndex=PLANETARY_RANGE_BANDS.indexOf(w.range); const inRange=!combat.active || combatRangeIndex<=maxRangeIndex; o.textContent=`${w.name} · dano ${w.damage} · alcance ${w.range}${inRange?'':' · FORA DE ALCANCE'}`; o.disabled=!inRange; if(inRange&&firstInRange===null)firstInRange=String(i); weapons.append(o);} if([...weapons.options].some(o=>o.value===prev&&!o.disabled))weapons.value=prev; else if(firstInRange!==null)weapons.value=firstInRange; $('vehicleAttack').disabled=!combat.active || combat.actionUsed || !status.weaponsOnline || firstInRange===null;
}

function renderVehicleAttack(attack){
  const el=$('vehicleAttackResult'); if(!attack){el.className='result empty';el.textContent='Nenhum ataque veicular resolvido.';return;}
  if(!attack.hit){el.className='result fail';el.textContent=`Falha · dificuldade ${attack.difficulty}.`;return;}
  const parts=[`Acerto · dano ${attack.damage}`,`Blindagem efetiva ${attack.targetDamage?.effectiveArmor ?? '—'}`,`casco sofreu ${attack.targetDamage?.suffered ?? 0}`]; if(attack.criticalAvailable)parts.push('Impacto crítico disponível'); el.className='result success';el.textContent=parts.join(' · ');
}

function showFeedback(id, text) { $(id).textContent=text; }

$('sendIntent').addEventListener('click', async () => {
  try {
    const text=$('playerIntent').value;
    if (game.state.settings?.masterProvider==='http') {
      showFeedback('intentFeedback','Consultando o Mestre remoto...');
      const result=await game.requestMasterTurn({intentText:text,endpoint:game.state.settings.masterEndpoint});
      showFeedback('intentFeedback',result.proposal.askPlayer || 'O Mestre atualizou a cena.');
    } else {
      const result=game.submitIntent(text);
      showFeedback('intentFeedback',result.master.playerMessage);
    }
    $('playerIntent').value = '';
    render();
  } catch (e) { showFeedback('intentFeedback',e.message); }
});

$('consultRules').addEventListener('click',()=>{
  try {
    const result=game.consultRules($('ruleQuery').value);
    renderRuleResults(result);
    render();
  } catch(e) {
    $('ruleQueryStatus').textContent=e.message;
  }
});
$('ruleQuery').addEventListener('keydown',e=>{ if(e.key==='Enter'){ e.preventDefault(); $('consultRules').click(); } });

$('skillSelect').addEventListener('change',()=>renderExpertTalentOption(game.state.player.character));

$('rollCheck').addEventListener('click', () => {
  try {
    const result = game.resolveSkillCheck({
      skillKey: $('skillSelect').value,
      difficulty: $('difficulty').value,
      challenge: $('challenge').value,
      boost: $('boost').value,
      setback: $('setback').value,
      useExpertTalent: $('useExpertTalent')?.checked ?? false
    });
    renderRoll(result); render();
  } catch (e) {
    const el = $('rollResult'); el.className='result fail'; el.textContent=e.message;
  }
});

$('createCustomCharacter').addEventListener('click',()=>{
  try {
    const character=game.createCustomCharacter(creatorSelections());
    showFeedback('customCreationFeedback',`${character.name} criado e salvo. Restam ${character.xp.available} PE e ${character.credits} créditos.`);
    render();
  } catch(e) { showFeedback('customCreationFeedback',e.message); }
});

$('progressSkill').addEventListener('change',()=>renderProgression(game.state.player.character));
$('trainSkill').addEventListener('click',()=>{
  try {
    const result=game.trainSkill($('progressSkill').value);
    showFeedback('progressFeedback',`Perícia aumentada para grau ${result.newRank}; ${result.cost} PE gastos.`);
    render();
  } catch(e) { showFeedback('progressFeedback',e.message); }
});

$('startSession').addEventListener('click',()=>{
  try { const result=game.startSession(); showFeedback('sessionFeedback',`Sessão ${result.session.number} iniciada.`); render(); }
  catch(e) { showFeedback('sessionFeedback',e.message); }
});
$('closeSession').addEventListener('click',()=>{
  try { const result=game.closeSession(); showFeedback('sessionFeedback',`${result.session.summary} PE não foram concedidos automaticamente.`); render(); }
  catch(e) { showFeedback('sessionFeedback',e.message); }
});
$('resolveSuggestedCheck').addEventListener('click',()=>{
  try { const check=game.resolveSuggestedMasterCheck(); renderRoll(check); showFeedback('intentFeedback','Teste sugerido pelo Mestre resolvido e registrado.'); render(); }
  catch(e) { showFeedback('intentFeedback',e.message); }
});

$('loadStarter').addEventListener('click',()=>{
  try { game.loadStarterCharacter($('starterCharacter').value); render(); }
  catch(e){ alert(e.message); }
});

$('exportCharacter').addEventListener('click',()=>{
  try {
    $('characterJson').value=game.exportCharacter();
    showFeedback('characterJsonFeedback','Ficha exportada para o campo JSON.');
  } catch(e){ showFeedback('characterJsonFeedback',e.message); }
});

$('importCharacter').addEventListener('click',()=>{
  try {
    game.importCharacter($('characterJson').value);
    showFeedback('characterJsonFeedback','Ficha validada, importada e salva.');
    render();
  } catch(e){ showFeedback('characterJsonFeedback',`Importação recusada: ${e.message}`); }
});

$('startEncounter').addEventListener('click',()=>{
  try {
    const result=game.beginPresetEncounter({playerQuickReactionStrain:Number($('quickReactionStrain').value||0)});
    const first=currentSlot(result.combat)?.side==='player' ? 'Sua posição chegou primeiro.' : 'PNPCs agiram antes de você.';
    const qr=result.quickReaction?.spend?` Reação rápida: ${result.quickReaction.spend} de Tensão por +${result.quickReaction.boost} Impulso.`:'';
    showFeedback('encounterFeedback',`Encontro iniciado. ${first}${qr}`);
    render();
  } catch(e){ showFeedback('encounterFeedback',e.message); }
});
$('startPendingEncounter').addEventListener('click',()=>{
  try {
    const result=game.beginPendingMasterEncounter({playerQuickReactionStrain:Number($('quickReactionStrain').value||0)});
    const first=currentSlot(result.combat)?.side==='player' ? 'Sua posição chegou primeiro.' : 'PNPCs agiram antes de você.';
    showFeedback('encounterFeedback',`Encontro do Mestre iniciado. ${first}`);
    render();
  } catch(e){ showFeedback('encounterFeedback',e.message); }
});
$('startCombat').addEventListener('click',()=>{ try { game.beginCombat(); showFeedback('maneuverFeedback','Combate livre iniciado, sem adversários automáticos.'); render(); } catch(e){ showFeedback('maneuverFeedback',e.message); } });
$('nextTurn').addEventListener('click',()=>{
  try {
    const result=game.advancePlayerTurn();
    const turns=result?.npcTurns?.map(t=>t.text).join(' ') ?? '';
    showFeedback('maneuverFeedback',turns ? `Seu turno terminou. ${turns}` : 'Novo turno iniciado.');
    render();
  } catch(e){ showFeedback('maneuverFeedback',e.message); }
});
$('endCombat').addEventListener('click',()=>{ try { const result=game.finishCombat(); const n=result.recovery?.recovered ?? 0; showFeedback('maneuverFeedback',`Combate encerrado. Recuperou ${n} de Tensão ao fim do encontro.`); render(); } catch(e){ showFeedback('maneuverFeedback',e.message); } });
$('normalManeuver').addEventListener('click',()=>{ try { game.useManeuver({method:'normal'}); showFeedback('maneuverFeedback','Manobra registrada.'); render(); } catch(e){ showFeedback('maneuverFeedback',e.message); } });
$('strainManeuver').addEventListener('click',()=>{ try { game.useManeuver({method:'strain'}); showFeedback('maneuverFeedback','Segunda manobra registrada; +2 de Tensão.'); render(); } catch(e){ showFeedback('maneuverFeedback',e.message); } });
$('actionManeuver').addEventListener('click',()=>{ try { game.useManeuver({method:'action'}); showFeedback('maneuverFeedback','A ação foi trocada pela segunda manobra.'); render(); } catch(e){ showFeedback('maneuverFeedback',e.message); } });

$('weaponSelect').addEventListener('change',()=>renderAttackRangeControls(game.state.player.character));
$('targetRange').addEventListener('change',()=>renderAttackRangeControls(game.state.player.character));
$('targetAdversary').addEventListener('change',()=>renderAttackRangeControls(game.state.player.character));
$('aimButton').addEventListener('click',()=>{
  try { game.aim({maneuverMethod:$('aimManeuverMethod').value}); showFeedback('maneuverFeedback','Mirar preparado: +1 Impulso no próximo ataque.'); render(); }
  catch(e){ showFeedback('maneuverFeedback',e.message); }
});

$('attackButton').addEventListener('click',()=>{
  try {
    const attack=game.resolveWeaponAttack({
      weaponIndex:$('weaponSelect').value,
      targetAdversaryId:game.state.combat.encounter ? $('targetAdversary').value : null,
      targetRange:$('targetRange').value,
      challenge:$('attackChallenge').value,
      boost:$('attackBoost').value,
      setback:$('attackSetback').value
    });
    renderAttack(attack); render();
  } catch(e){ const el=$('attackResult'); el.className='result fail'; el.textContent=e.message; }
});

$('activateCritical').addEventListener('click',()=>{
  try {
    const result=game.activatePendingPlayerCritical();
    showFeedback('maneuverFeedback',result.woundsAdded>0 ? `Crítico ativado: o grupo perdeu um lacaio.` : 'Ferimento Crítico ativado no adversário.');
    render();
  } catch(e){ showFeedback('maneuverFeedback',e.message); }
});

$('applyDamage').addEventListener('click',()=>{
  try {
    const result=game.applyPlayerDamage({damage:$('incomingDamage').value,pierce:$('incomingPierce').value,damageType:$('incomingDamageType').value});
    showFeedback('damageFeedback',`Proteção efetiva ${result.effectiveSoak}; sofreu ${result.suffered} ${result.damageType==='strain'?'de Tensão':'Ferimentos'}${result.criticalAdded?' e recebeu 1 ferimento crítico':''}. Estado: ${result.status.label}.`);
    render();
  } catch(e){ showFeedback('damageFeedback',e.message); }
});

$('useStimpack').addEventListener('click',()=>{
  try {
    const result=game.usePlayerStimpack({maneuverMethod:$('stimpackManeuverMethod').value});
    showFeedback('stimpackFeedback',`Recuperou ${result.healed} Ferimento${result.healed===1?'':'s'}; restam ${result.remaining} injetor${result.remaining===1?'':'es'}.`);
    render();
  } catch(e){ showFeedback('stimpackFeedback',e.message); }
});

$('medicineButton').addEventListener('click',()=>{
  try {
    const result=game.useMedicine({medicalSupplies:$('medicineSupplies').value==='yes'});
    const outcome=result.check.success ? `Sucesso: recuperou ${result.healed} Ferimento(s) e ${result.strainRecovered} de Tensão.` : 'Falha no tratamento; nenhum Ferimento foi recuperado.';
    showFeedback('medicineFeedback',`${outcome} Dificuldade ${result.difficulty}.`);
    render();
  } catch(e){ showFeedback('medicineFeedback',e.message); }
});

$('restNightButton').addEventListener('click',()=>{
  try {
    const result=game.restFullNight();
    showFeedback('restFeedback',`Descanso concluído: recuperou ${result.woundsRecovered} Ferimento(s) e ${result.strainRecovered} de Tensão.`);
    render();
  } catch(e){ showFeedback('restFeedback',e.message); }
});


$('loadVehicle').addEventListener('click',()=>{ try{ const v=game.addVehicle($('vehicleProfileSelect').value); showFeedback('vehicleFeedback',`${v.shortName ?? v.name} adicionada à campanha.`); render(); }catch(e){showFeedback('vehicleFeedback',e.message);} });
$('startVehicleCombat').addEventListener('click',()=>{ try{ game.beginVehicleCombat({targetProfileKey:'tie_ln',range:'Curto'}); showFeedback('vehicleManeuverFeedback','Encontro veicular iniciado contra um TIE/ln.'); render(); }catch(e){showFeedback('vehicleManeuverFeedback',e.message);} });
$('nextVehicleRound').addEventListener('click',()=>{ try{ game.nextVehicleRound(); showFeedback('vehicleManeuverFeedback','Novo assalto veicular.'); render(); }catch(e){showFeedback('vehicleManeuverFeedback',e.message);} });
$('endVehicleCombat').addEventListener('click',()=>{ try{ game.endVehicleCombat(); showFeedback('vehicleManeuverFeedback','Combate veicular encerrado.'); render(); }catch(e){showFeedback('vehicleManeuverFeedback',e.message);} });
$('vehicleView').addEventListener('click',e=>{});
for(const button of document.querySelectorAll('[data-vehicle-maneuver]')) button.addEventListener('click',()=>{ try{ const result=game.useVehiclePilotManeuver(button.dataset.vehicleManeuver,{method:$('vehicleManeuverMethod').value,direction:button.dataset.direction ?? 'closer'}); showFeedback('vehicleManeuverFeedback',`Manobra registrada. Velocidade ${result.vehicle.speed}; alcance ${game.state.vehicles.combat.range}.`); render(); }catch(e){showFeedback('vehicleManeuverFeedback',e.message);} });
$('fullThrottleAction').addEventListener('click',()=>{ try { const r=game.useFullThrottle({asManeuver:false}); showFeedback('vehicleManeuverFeedback',r.check.success?`Aceleração máxima: Velocidade máxima +${r.bonus} por ${r.durationRounds} assalto(s).`:'Aceleração máxima falhou.'); render(); } catch(e){ showFeedback('vehicleManeuverFeedback',e.message); } });
$('fullThrottleManeuver').addEventListener('click',()=>{ try { const r=game.useFullThrottle({asManeuver:true,secondManeuverMethod:$('vehicleManeuverMethod').value}); showFeedback('vehicleManeuverFeedback',r.check.success?`Aceleração máxima aprimorada: Velocidade máxima +${r.bonus} por ${r.durationRounds} assalto(s); +${r.personalStrainCost} Tensão pessoal.`:`Aceleração máxima aprimorada falhou; +${r.personalStrainCost} Tensão pessoal.`); render(); } catch(e){ showFeedback('vehicleManeuverFeedback',e.message); } });
$('controlledFireAction').addEventListener('click',()=>{ showFeedback('vehicleManeuverFeedback','Fogo controlado pertence ao legado Age of Rebellion e não está ativo no perfil EotE Core.'); });

$('vehicleAttack').addEventListener('click',()=>{ try{ const attack=game.resolveVehicleAttack({weaponIndex:Number($('vehicleWeaponSelect').value)}); renderVehicleAttack(attack); render(); }catch(e){const el=$('vehicleAttackResult');el.className='result fail';el.textContent=e.message;} });
$('applyVehicleDamage').addEventListener('click',()=>{ try{ const r=game.applyVehicleDamage({damage:Number($('vehicleIncomingDamage').value),breach:Number($('vehicleIncomingBreach').value)}); showFeedback('vehicleRepairFeedback',`Casco sofreu ${r.suffered}. Estado: ${r.status.label}.`); render(); }catch(e){showFeedback('vehicleRepairFeedback',e.message);} });
$('applyVehicleStrain').addEventListener('click',()=>{ try{ const r=game.applyVehicleStrain(Number($('vehicleIncomingStrain').value)); showFeedback('vehicleRepairFeedback',`+${r.suffered} de Tensão de sistemas. Estado: ${r.status.label}.`); render(); }catch(e){showFeedback('vehicleRepairFeedback',e.message);} });
$('vehicleDamageControl').addEventListener('click',()=>{ try{ const r=game.vehicleDamageControl(); showFeedback('vehicleRepairFeedback',r.check.success?`Controle de danos: ${r.systemStrainRecovered} Tensão e ${r.hullRecovered} Casco recuperados.`:`Falha no controle de danos. Dificuldade ${r.difficulty}.`); render(); }catch(e){showFeedback('vehicleRepairFeedback',e.message);} });
$('vehicleCritical').addEventListener('click',()=>{ try{ const r=game.applyActiveVehicleCritical(); showFeedback('vehicleRepairFeedback',r.hit.effect); render(); }catch(e){showFeedback('vehicleRepairFeedback',e.message);} });
$('vehicleHazardCheck').addEventListener('click',()=>{ try{ const r=game.vehiclePilotingHazardCheck(); showFeedback('vehicleRepairFeedback',`Pilotagem: ${r.check.success?'sucesso':'falha'} · dificuldade ${r.difficulty} com ${r.upgrades} melhoria(s).`); render(); }catch(e){showFeedback('vehicleRepairFeedback',e.message);} });
$('vehicleRestDay').addEventListener('click',()=>{ try{ const r=game.restVehicleFullDay(); showFeedback('vehicleRepairFeedback',`Dia de recuperação: ${r.recovered} de Tensão de sistemas removido.`); render(); }catch(e){showFeedback('vehicleRepairFeedback',e.message);} });
$('vehicleAstrogation').addEventListener('click',()=>{ try{ const r=game.plotHyperspaceCourse(); const tempo=r.timeMultiplier===0.5?' Cartógrafo galáctico: cálculo consome metade do tempo habitual.':''; showFeedback('vehicleTravelFeedback',`Astronavegação Fácil: ${r.check.success?'rota calculada':'cálculo falhou'}.${tempo}`); render(); }catch(e){showFeedback('vehicleTravelFeedback',e.message);} });

$('imageMapSearch').addEventListener('input',renderMapLibrary);
$('imageMapCatalog').addEventListener('click',e=>{ const b=e.target.closest('[data-map-asset]'); if(!b) return; mapLibraryUi.selectedAssetId=b.dataset.mapAsset; renderMapLibrary(); });
$('imageMapCache').addEventListener('click',cacheSelectedMap);
$('imageMapClearCache').addEventListener('click',clearSelectedMapCache);
$('imageMapRefresh').addEventListener('click',()=>{ mapLibraryUi.statuses.clear(); renderMapLibrary(); });
renderMapLibrary();

$('imageVisualSearch').addEventListener('input',renderVisualLibrary);
$('imageVisualKind').addEventListener('change',renderVisualLibrary);
$('imageVisualCatalog').addEventListener('click',e=>{ const b=e.target.closest('[data-visual-asset]'); if(!b) return; visualLibraryUi.selectedAssetId=b.dataset.visualAsset; renderVisualLibrary(); });
$('imageVisualCache').addEventListener('click',cacheSelectedVisualAsset);
$('imageVisualClearCache').addEventListener('click',clearSelectedVisualAssetCache);
$('imageVisualRefresh').addEventListener('click',()=>{ mapLibraryUi.statuses.clear(); renderVisualLibrary(); });
renderVisualLibrary();

$('mapZoomIn').addEventListener('click',()=>zoomGalaxyMap(.5));
$('mapZoomOut').addEventListener('click',()=>zoomGalaxyMap(-.5));
$('mapReset').addEventListener('click',resetGalaxyMap);
$('mapPlotCourse').addEventListener('click',()=>{
  try{
    const destination=$('mapDestination').value.trim(); if(!destination) throw new Error('Informe um destino antes de calcular a rota.');
    const result=game.plotHyperspaceCourse();
    showFeedback('mapTravelFeedback',`${result.check.success?'Rota calculada':'Cálculo da rota falhou'} para ${destination}. A viagem ainda precisa ser confirmada pelo Mestre.`);
    render();
  }catch(e){ showFeedback('mapTravelFeedback',e.message); }
});
$('mapProposeTravel').addEventListener('click',()=>{
  try{
    const destination=$('mapDestination').value.trim(); if(!destination) throw new Error('Informe um destino para propor a viagem.');
    const result=game.submitIntent(`Quero viajar para ${destination}. Avalie a rota, o tempo, os riscos e os requisitos antes de alterar nossa localização.`);
    showFeedback('mapTravelFeedback',result.master.playerMessage);
    render();
  }catch(e){ showFeedback('mapTravelFeedback',e.message); }
});
const mapViewport=$('galaxyMapViewport');
mapViewport.addEventListener('pointerdown',e=>{ galaxyMapUi.dragging=true; galaxyMapUi.pointerId=e.pointerId; galaxyMapUi.lastX=e.clientX; galaxyMapUi.lastY=e.clientY; mapViewport.classList.add('dragging'); mapViewport.setPointerCapture?.(e.pointerId); });
mapViewport.addEventListener('pointermove',e=>{ if(!galaxyMapUi.dragging||e.pointerId!==galaxyMapUi.pointerId||galaxyMapUi.scale<=1) return; galaxyMapUi.x+=e.clientX-galaxyMapUi.lastX; galaxyMapUi.y+=e.clientY-galaxyMapUi.lastY; galaxyMapUi.lastX=e.clientX; galaxyMapUi.lastY=e.clientY; applyGalaxyMapTransform(); });
const finishMapDrag=e=>{ if(e.pointerId!==galaxyMapUi.pointerId) return; galaxyMapUi.dragging=false; galaxyMapUi.pointerId=null; mapViewport.classList.remove('dragging'); };
mapViewport.addEventListener('pointerup',finishMapDrag); mapViewport.addEventListener('pointercancel',finishMapDrag);
mapViewport.addEventListener('wheel',e=>{ e.preventDefault(); zoomGalaxyMap(e.deltaY<0?.25:-.25); },{passive:false});


$('catalogWeapons').addEventListener('click',e=>{
  const button=e.target.closest('.propose-weapon'); if(!button) return;
  try{ const result=game.proposeWeaponAcquisition(button.dataset.itemId); showFeedback('equipmentCatalogFeedback',result.master.playerMessage); render(); }
  catch(err){ showFeedback('equipmentCatalogFeedback',err.message); }
});

$('talentOptions').addEventListener('click',e=>{
  const button=e.target.closest('.buy-talent'); if(!button) return;
  try{ const row=button.closest('.talent-row'); const characteristicKey=row?.querySelector('.talent-characteristic')?.value ?? null; const r=game.buyTalent(button.dataset.talentId,{characteristicKey}); showFeedback('talentFeedback',`${r.talent.name} adquirido por ${r.talent.cost} PE.`); render(); }
  catch(err){ showFeedback('talentFeedback',err.message); }
});
$('saveGroupBase').addEventListener('click',()=>{ try{ game.updateGroupBase({name:$('groupBaseName').value,location:$('groupBaseLocation').value,description:$('groupBaseDescription').value}); showFeedback('groupBaseFeedback','Refúgio / Base salvo.'); render(); }catch(e){showFeedback('groupBaseFeedback',e.message);} });
$('addGroupObligation').addEventListener('click',()=>{ try{ game.addGroupObligation({value:Number($('groupObligationValue').value),member:$('groupObligationMember').value,type:$('groupObligationType').value,description:$('groupObligationDescription').value}); showFeedback('groupObligationFeedback','Obligation adicionada ao grupo.'); render(); }catch(e){showFeedback('groupObligationFeedback',e.message);} });
$('groupObligationEntries').addEventListener('click',e=>{ const b=e.target.closest('.remove-group-obligation'); if(!b) return; try{game.removeGroupObligation(b.dataset.obligationId); showFeedback('groupObligationFeedback','Obligation removida.'); render();}catch(err){showFeedback('groupObligationFeedback',err.message);} });
$('saveGroupLists').addEventListener('click',()=>{ try{ game.setGroupList('resources',linesFromTextarea('groupResources')); game.setGroupList('belongings',linesFromTextarea('groupBelongings')); game.setGroupList('contacts',linesFromTextarea('groupContacts')); showFeedback('groupListsFeedback','Recursos, Pertences e Contatos salvos.'); render(); }catch(e){showFeedback('groupListsFeedback',e.message);} });
$('saveGroupDestiny').addEventListener('click',()=>{ try{ game.setGroupDestiny({light:Number($('groupDestinyLight').value),dark:Number($('groupDestinyDark').value)}); showFeedback('groupDestinyFeedback','Reserva de Destino salva.'); render(); }catch(e){showFeedback('groupDestinyFeedback',e.message);} });

$('newCampaign').addEventListener('click', () => {
  if (confirm('Criar nova campanha local? O estado atual será substituído.')) {
    const name = prompt('Nome da campanha:', 'Nova campanha') ?? 'Nova campanha';
    game.newCampaign(name); render();
  }
});

$('masterProviderMode').addEventListener('change',()=>{ $('masterEndpointWrap').hidden=$('masterProviderMode').value!=='http'; });
$('saveMasterSettings').addEventListener('click',()=>{
  try {
    const settings=game.configureMasterProvider({mode:$('masterProviderMode').value,endpoint:$('masterEndpoint').value});
    game.configureTts({enabled:$('ttsEnabled').checked,rate:Number($('ttsRate').value)});
    showFeedback('masterSettingsFeedback',settings.masterProvider==='http'?'Ajustes salvos; Mestre remoto configurado sem armazenar chave.':'Ajustes salvos; modo local ativo.');
    render();
  } catch(e) { showFeedback('masterSettingsFeedback',e.message); }
});
$('ttsPlayNarration').addEventListener('click',()=>{
  try {
    if(!game.state.settings?.ttsEnabled) throw new Error('Ative a voz da narração em Ajustes.');
    const result=speakNarration(game.state.scene?.narration,{rate:game.state.settings?.ttsRate ?? 1});
    showFeedback('ttsFeedback',`Lendo a narração em PT-BR · velocidade ${result.rate}.`);
  } catch(e){ showFeedback('ttsFeedback',e.message); }
});
$('ttsStopNarration').addEventListener('click',()=>{ stopNarration(); showFeedback('ttsFeedback','Voz interrompida.'); });

$('importLibraryPdf').addEventListener('click',()=>{
  try { requestPdfImport(); showFeedback('libraryImportFeedback','Selecione um PDF. Ele será copiado e indexado em segundo plano dentro do aplicativo.'); }
  catch(e) { showFeedback('libraryImportFeedback',e.message); }
});

$('searchLibrary').addEventListener('click',()=>{
  try {
    const query=$('libraryQuery').value.trim();
    if (!query) throw new Error('Digite o que deseja buscar nos PDFs.');
    const results=searchImportedLibrary(query,{limit:10});
    renderLibrarySearch(results);
    showFeedback('librarySearchFeedback',results.length?`${results.length} trecho(s) encontrado(s) no índice offline.`:'Nenhum trecho encontrado.');
  } catch(e) { showFeedback('librarySearchFeedback',e.message); }
});
$('libraryQuery').addEventListener('keydown',e=>{ if(e.key==='Enter'){ e.preventDefault(); $('searchLibrary').click(); } });
$('libraryDocuments').addEventListener('change',e=>{
  const row=e.target.closest('.library-row');
  if (!row || !e.target.matches('.library-authority,.library-enabled')) return;
  const authorityType=row.querySelector('.library-authority').value;
  const enabled=row.querySelector('.library-enabled').checked;
  try {
    updateLibraryDocumentPolicy(row.dataset.docId,{authorityType,enabled});
    showFeedback('libraryImportFeedback',`Fonte atualizada: ${libraryAuthorityTypeLabel(authorityType)} · ${enabled?'ativa no Mestre':'desativada no Mestre'}.`);
    renderLibrary();
  } catch(err) { showFeedback('libraryImportFeedback',err.message); renderLibrary(); }
});

$('libraryDocuments').addEventListener('click',e=>{
  const reindex=e.target.closest('.library-reindex');
  if (reindex) {
    try { reindexLibraryDocument(reindex.dataset.docId); showFeedback('libraryImportFeedback','Reindexação iniciada. O PDF permanece disponível durante o processo.'); renderLibrary(); }
    catch(err) { showFeedback('libraryImportFeedback',err.message); }
    return;
  }
  const button=e.target.closest('.library-remove'); if(!button) return;
  if (!confirm('Remover este PDF e seu índice offline da Biblioteca?')) return;
  try { removeLibraryDocument(button.dataset.docId); showFeedback('libraryImportFeedback','PDF removido da Biblioteca local.'); renderLibrary(); }
  catch(err) { showFeedback('libraryImportFeedback',err.message); }
});

window.braseiroLibraryNativeEvent = raw => {
  let event={}; try { event=JSON.parse(String(raw ?? '{}')); } catch {}
  const type=event.type; const doc=event.payload?.document;
  const messages={
    cancelado:'Importação cancelada.',
    indexando:doc?`Anexando e indexando ${doc.fileName ?? 'PDF'}...`:'Indexação iniciada.',
    concluido:doc?.status==='INDEXADO'?`${doc.fileName} pronto para uso offline.`:`${doc?.fileName ?? 'PDF'} foi anexado, mas não contém texto extraível.`,
    duplicado:'Este PDF já existe na Biblioteca. O arquivo duplicado não foi criado.',
    removido:'PDF removido da Biblioteca.',
    politica:doc?`Autoridade de ${doc.fileName ?? 'PDF'} atualizada.`:'Autoridade da fonte atualizada.',
    erro:event.payload?.message || 'Falha ao importar o PDF.'
  };
  showFeedback('libraryImportFeedback',messages[type] ?? 'Biblioteca atualizada.');
  renderLibrary();
};

for (const tab of document.querySelectorAll('.tab')) {
  tab.addEventListener('click',()=>{
    document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('active',t===tab));
    document.querySelectorAll('.view').forEach(v=>v.classList.toggle('active',v.id===tab.dataset.view));
  });
}

initCharacterCreator();
initVehicleProfiles();
render();
const initialView=location.hash.replace(/^#/,'');
if(initialView){
  const tab=[...document.querySelectorAll('.tab')].find(t=>t.dataset.view===initialView);
  if(tab){ document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('active',t===tab)); document.querySelectorAll('.view').forEach(v=>v.classList.toggle('active',v.id===initialView)); }
}
