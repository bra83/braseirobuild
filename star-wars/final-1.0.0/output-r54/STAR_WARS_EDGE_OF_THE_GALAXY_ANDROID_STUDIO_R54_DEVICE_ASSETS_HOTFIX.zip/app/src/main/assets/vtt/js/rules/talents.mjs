import { CHARACTERISTICS } from './character.mjs';
import { TALENT_TREES } from './talentTreesData.mjs';
import { ownedSpecializationRefs, ownsSpecialization } from './progression.mjs';
import { FORCE_SENSITIVE_EXILE_TREE } from './forceData.mjs';
import { forceRating, isForceSensitive, availableForceRating, rollForceDice } from './force.mjs';

function clone(value){ return structuredClone(value); }
function purchases(c){ return Array.isArray(c?.talentPurchases)?c.talentPurchases:[]; }

const ACTIVE_TALENT_TREES=Object.freeze({...TALENT_TREES,universal:Object.freeze({force_sensitive_exile:FORCE_SENSITIVE_EXILE_TREE})});
const allNodes=Object.values(ACTIVE_TALENT_TREES).flatMap(specs=>Object.values(specs).flatMap(tree=>tree.nodes));
const PT_BY_ORIGINAL=new Map(allNodes.map(n=>[n.originalName,n.name]));

function treeRef(character,{careerKey=null,specializationKey=null,nodeId=null}={}){
  const owned=ownedSpecializationRefs(character);
  let career=careerKey;
  let spec=specializationKey;
  if(nodeId && (!career || !spec)){
    const found=owned.find(ref=>ACTIVE_TALENT_TREES?.[ref.careerKey]?.[ref.specializationKey]?.nodes?.some(node=>node.id===nodeId));
    if(found){ career=found.careerKey; spec=found.specializationKey; }
  }
  if(!career || !spec){
    career=character?.creation?.careerKey;
    spec=character?.creation?.specializationKey;
  }
  if(!ownsSpecialization(character,career,spec)) return {career,spec,tree:null,owned:false};
  return {career,spec,tree:ACTIVE_TALENT_TREES?.[career]?.[spec]??null,owned:true};
}
function ownedIds(character){ return new Set(purchases(character).map(p=>p.nodeId)); }

function neighborMap(tree){
  const map=new Map(tree.nodes.map(n=>[n.id,new Set()]));
  for(const [a,b] of tree.edges){
    map.get(a)?.add(b); map.get(b)?.add(a);
  }
  return map;
}

function unlockedIds(character,tree){
  const owned=ownedIds(character);
  const unlocked=new Set(tree.nodes.filter(n=>n.row===1).map(n=>n.id));
  if(!owned.size) return unlocked;
  const neighbors=neighborMap(tree);
  for(const id of owned) for(const n of (neighbors.get(id)??[])) unlocked.add(n);
  return unlocked;
}

function applyImmediateEffect(character,node,{characteristicKey=null}={}){
  const c=character;
  switch(node.originalName){
    case 'APLOMO':
    case 'GRIT':
      c.derived.strain.threshold+=1;
      return {applied:true,label:'+1 no limiar de Tensão'};
    case 'ENDURECIDO':
    case 'TOUGH':
      c.derived.wounds.threshold+=2;
      return {applied:true,label:'+2 no limiar de Ferimentos'};
    case 'RESISTENTE':
    case 'ENDUR':
      c.derived.soak+=1;
      return {applied:true,label:'+1 de Proteção'};
    case 'SEXTO SENTIDO':
    case 'SIXTHSENSE':
      c.derived.defense.ranged+=1;
      return {applied:true,label:'+1 de Defesa contra ataques à distância'};
    case 'SUPREF':
      c.derived.defense.melee+=1;
      return {applied:true,label:'+1 de Defesa corpo a corpo'};
    case 'INSIGHT':
      c.careerSkills=Array.isArray(c.careerSkills)?c.careerSkills:[];
      c.careerSkills=[...new Set([...c.careerSkills,'percepcao','disciplina'])];
      return {applied:true,label:'Percepção e Disciplina tornam-se perícias de carreira'};
    case 'FORCE_RATING':
      c.force={...(c.force??{}),rating:forceRating(c)+1};
      return {applied:true,label:'+1 Force Rating'};
    case 'DEDICACIÓN':
    case 'DEDI': {
      if(!CHARACTERISTICS.includes(characteristicKey)) throw new Error('Dedicação exige escolher uma Característica.');
      if(Number(c.characteristics?.[characteristicKey]??0)>=6) throw new Error('Dedicação não pode elevar uma Característica acima de 6.');
      c.characteristics[characteristicKey]+=1;
      if(characteristicKey==='fortaleza'){
        c.derived.soak+=1;
        c.derived.wounds.threshold+=1;
      }
      if(characteristicKey==='voluntad') c.derived.strain.threshold+=1;
      return {applied:true,label:`+1 em ${characteristicKey}`,characteristicKey};
    }
    default:
      return {applied:false,label:null};
  }
}

export { TALENT_TREES };

export const FIRST_ROW_TALENTS=Object.freeze(Object.fromEntries(
  Object.entries(ACTIVE_TALENT_TREES).map(([career,specs])=>[career,Object.fromEntries(
    Object.entries(specs).map(([spec,tree])=>[spec,tree.nodes.filter(n=>n.row===1).map(n=>({...n}))])
  )])
));

export function treeForCharacter(character,selector={}){
  const {career,spec,tree}=treeRef(character,selector);
  if(!tree) return null;
  return {careerKey:career,specializationKey:spec,nodes:tree.nodes.map(n=>clone(n)),edges:tree.edges.map(e=>[...e])};
}

export function eligibleTalents(character,selector={}){
  const {tree}=treeRef(character,selector);
  if(!tree) return [];
  const owned=ownedIds(character);
  const unlocked=unlockedIds(character,tree);
  const xp=Number(character?.xp?.available??0);
  return tree.nodes.map(n=>({
    ...clone(n),
    purchased:owned.has(n.id),
    unlocked:unlocked.has(n.id),
    available:!owned.has(n.id)&&unlocked.has(n.id)&&xp>=n.cost,
    needsChoice:['DEDICACIÓN','DEDI'].includes(n.originalName)
  }));
}

export function purchaseTalent(character,nodeId,{characteristicKey=null,careerKey=null,specializationKey=null}={}){
  if(!character||typeof character!=='object') throw new Error('Ficha inválida.');
  const ref=treeRef(character,{careerKey,specializationKey,nodeId});
  if(!ref.tree) throw new Error('Talento não pertence a uma especialização possuída por esta ficha.');
  const node=eligibleTalents(character,{careerKey:ref.career,specializationKey:ref.spec}).find(n=>n.id===nodeId);
  if(!node) throw new Error('Talento não pertence a uma especialização possuída por esta ficha.');
  if(node.purchased) throw new Error('Este espaço da árvore já foi adquirido.');
  if(node.forceOnly&&!isForceSensitive(character)) throw new Error('Este talento exige Force Rating 1 ou maior.');
  if(!node.unlocked) throw new Error('Este talento ainda não está conectado a um talento adquirido.');
  if(Number(character.xp?.available??0)<node.cost) throw new Error(`PE insuficientes: são necessários ${node.cost} PE.`);

  const c=clone(character);
  const effect=applyImmediateEffect(c,node,{characteristicKey});
  c.xp.available-=node.cost;
  c.talentPurchases=[...purchases(c),{
    nodeId:node.id,name:node.name,originalName:node.originalName,cost:node.cost,row:node.row,column:node.column,
    source:node.source,careerKey:ref.career,specializationKey:ref.spec,effect:effect.label??null,choice:effect.characteristicKey??null
  }];
  c.talents=Array.isArray(c.talents)?c.talents:[];
  c.talents.push(node.name);
  return {character:c,talent:node,effect};
}

// Compatibilidade com R11 e chamadas já existentes.
export function eligibleFirstRowTalents(character){ return eligibleTalents(character).filter(n=>n.row===1); }
export function purchaseFirstRowTalent(character,nodeId,options={}){
  const node=eligibleTalents(character).find(n=>n.id===nodeId);
  if(!node||node.row!==1) throw new Error('Talento não pertence à primeira linha da especialização inicial desta ficha.');
  return purchaseTalent(character,nodeId,options);
}

export function talentRanks(character){
  const out={};
  for(const t of (character?.talents??[])){
    const name=typeof t==='string'?t:(t?.name??'');
    if(name) out[name]=(out[name]??0)+1;
  }
  return out;
}

export function talentRankByOriginal(character,originalName){
  const pt=PT_BY_ORIGINAL.get(originalName)??originalName;
  return Number(talentRanks(character)[pt]??0);
}


const SKILL_BOOST_TALENTS=Object.freeze([
  Object.freeze({originalName:'STALK',skills:Object.freeze(['sigilo','coordinacion']),label:'Perseguidor'}),
  Object.freeze({originalName:'COM',skills:Object.freeze(['liderazgo']),label:'Comando'}),
  Object.freeze({originalName:'UNCSEN',skills:Object.freeze(['percepcao']),label:'Sentidos sobrenaturais'}),
  Object.freeze({originalName:'UNCREA',skills:Object.freeze(['alerta']),label:'Reações sobrenaturais'}),
  Object.freeze({originalName:'SENSEEMO',skills:Object.freeze(['carisma','coaccion','engano']),label:'Sentir emoções'})
]);

const SKILL_SETBACK_REMOVAL_TALENTS=Object.freeze([
  Object.freeze({originalName:'KILL',skills:Object.freeze(['carisma','liderazgo']),label:'Matar com gentileza'}),
  Object.freeze({originalName:'PLAUSDEN',skills:Object.freeze(['coaccion','engano']),label:'Negação plausível'}),
  Object.freeze({originalName:'STRSMART',skills:Object.freeze(['callejeo','bajos_fondos']),label:'Instinto das ruas'}),
  Object.freeze({originalName:'CONV',skills:Object.freeze(['engano','actividad_criminal']),label:'Atitude convincente'}),
  Object.freeze({originalName:'GALMAP',skills:Object.freeze(['astronavegacion']),label:'Cartógrafo galáctico'}),
  Object.freeze({originalName:'GEARHD',skills:Object.freeze(['mecanica']),label:'Cabeça de engrenagem'}),
  Object.freeze({originalName:'SKILLJOCK',skills:Object.freeze(['pilotar_vehiculo_planetario','pilotar_vehiculo_espacial']),label:'Piloto consumado'})
]);

export function talentSkillPoolModifiers(character,skillKey,{boost=0,setback=0}={}){
  const baseBoost=Math.max(0,Number(boost)||0);
  const baseSetback=Math.max(0,Number(setback)||0);
  let talentBoost=0;
  let removalCapacity=0;
  const details=[];
  for(const rule of SKILL_BOOST_TALENTS){
    if(!rule.skills.includes(skillKey)) continue;
    const rank=talentRankByOriginal(character,rule.originalName);
    if(rank>0){ talentBoost+=rank; details.push({talent:rule.label,originalName:rule.originalName,effect:'boost',amount:rank}); }
  }
  for(const rule of SKILL_SETBACK_REMOVAL_TALENTS){
    if(!rule.skills.includes(skillKey)) continue;
    const rank=talentRankByOriginal(character,rule.originalName);
    if(rank>0){ removalCapacity+=rank; details.push({talent:rule.label,originalName:rule.originalName,effect:'remove_setback',amount:rank}); }
  }
  const setbackRemoved=Math.min(baseSetback,removalCapacity);
  return {
    boost:baseBoost+talentBoost,
    setback:Math.max(0,baseSetback-removalCapacity),
    baseBoost,baseSetback,talentBoost,setbackRemoved,removalCapacity,details
  };
}

export function talentCloseRangeDamageBonus(character,{weapon=null,targetRange=null}={}){
  if(!weapon) return 0;
  const ranged=['armas_distancia_ligeras','armas_distancia_pesadas'];
  if(!ranged.includes(weapon.skill)) return 0;
  if(!['Curto','Interação'].includes(String(targetRange??''))) return 0;
  return talentRankByOriginal(character,'POINTBL');
}

export function talentVehicleDefenseBonus(character){
  return talentRankByOriginal(character,'DEFDRI');
}

export function quickReactionOption(character, requestedStrain=0){
  const rank=talentRankByOriginal(character,'RAPREA');
  const spend=Number(requestedStrain);
  if(!Number.isInteger(spend)||spend<0) throw new Error('Tensão de Reação rápida inválida.');
  if(spend>rank) throw new Error(`Reação rápida permite no máximo ${rank} de Tensão nesta iniciativa.`);
  return {rank,spend,boost:spend};
}

export function talentPilotedVehicleDefenseBonus(character){
  return talentRankByOriginal(character,'DEFDRI');
}

export function talentPilotedVehicleSilhouette(character, silhouette){
  const base=Math.max(0,Number(silhouette)||0);
  return talentRankByOriginal(character,'TRICK')>0 ? Math.max(0,base-1) : base;
}

export function fullThrottleTalentSpec(character){
  const base=talentRankByOriginal(character,'FULLTH');
  const improved=talentRankByOriginal(character,'FULLTHIMP')>0;
  const supreme=talentRankByOriginal(character,'FULLTHSUP')>0;
  return {available:base>0,improved,supreme,bonus:supreme?2:base>0?1:0,actionDifficulty:3,maneuverDifficulty:2,improvedStrainCost:improved?1:0};
}

export function galacticCartographerTimeMultiplier(character){
  return talentRankByOriginal(character,'GALMAP')>0 ? 0.5 : 1;
}

export function expertSkillTalentSpec(character,skillKey){
  const configs={
    astronavegacion:{originalName:'MASSTAR',label:'Navegador mestre'}
  };
  const config=configs[skillKey];
  if(!config) return {available:false,skillKey,originalName:null,label:null,strainCost:0,difficultyReduction:0,minDifficulty:1};
  const rank=talentRankByOriginal(character,config.originalName);
  return {available:rank>0,rank,skillKey,originalName:config.originalName,label:config.label,strainCost:2,difficultyReduction:1,minDifficulty:1};
}

export function quickStrikeBoost(character,{targetActorId=null,actedActorIds=[]}={}){
  const rank=talentRankByOriginal(character,'QUICKST');
  if(rank<1 || !targetActorId) return {rank,boost:0,applies:false};
  const acted=new Set(Array.isArray(actedActorIds)?actedActorIds:[]);
  const applies=!acted.has(String(targetActorId));
  return {rank,boost:applies?rank:0,applies,targetActorId:String(targetActorId)};
}


export function forceTalentSummary(character){
  return {
    forceRating:forceRating(character),
    availableForceRating:availableForceRating(character),
    forceSensitive:isForceSensitive(character),
    overwhelmEmotions:talentRankByOriginal(character,'OVEREMO')>0,
    intenseFocus:talentRankByOriginal(character,'INTFOC')>0,
    senseDanger:talentRankByOriginal(character,'SENSEDANGER')>0,
    balance:talentRankByOriginal(character,'BALANCE')>0,
    touchOfFate:talentRankByOriginal(character,'TOUCHFATE')>0,
    quickDraw:talentRankByOriginal(character,'QUICKDR')>0,
    sixthSense:talentRankByOriginal(character,'SIXTHSENSE')>0,
    superiorReflexes:talentRankByOriginal(character,'SUPREF')>0
  };
}

export function overwhelmEmotionsModifiers(character,skillKey,{light=0,dark=0}={}){
  if(talentRankByOriginal(character,'OVEREMO')<1) return {available:false,forceDice:0,success:0,threat:0};
  if(!['carisma','coaccion','engano'].includes(skillKey)) return {available:false,forceDice:0,success:0,threat:0};
  const l=Math.max(0,Number(light)||0),d=Math.max(0,Number(dark)||0);
  if(skillKey==='carisma') return {available:true,forceDice:forceRating(character),success:l,threat:Math.floor(d/2)};
  return {available:true,forceDice:forceRating(character),success:d,threat:Math.floor(l/2)};
}

export function intenseFocusOption(character){return {available:talentRankByOriginal(character,'INTFOC')>0,strainCost:1,abilityUpgrades:1};}
export function senseDangerOption(character){return {available:talentRankByOriginal(character,'SENSEDANGER')>0,setbackRemoved:2,usesPerSession:1};}
export function touchOfFateOption(character){return {available:talentRankByOriginal(character,'TOUCHFATE')>0,boost:2,usesPerSession:1};}
export function balanceRecovery(character,{rng=Math.random}={}){
  if(talentRankByOriginal(character,'BALANCE')<1) return {available:false,recovered:0,roll:null};
  const roll=rollForceDice(character,{rng});
  return {available:true,recovered:roll.light,roll};
}
