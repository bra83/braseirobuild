migrateState = migrateState;
import * as ids_mjs_1 from "./ids.mjs";
import * as combat_mjs_1 from "../rules/combat.mjs";
import * as sessionFlow_mjs_1 from "../master/sessionFlow.mjs";
import * as vehicles_mjs_1 from "../rules/vehicles.mjs";
import * as fringeGroup_mjs_1 from "../rules/fringeGroup.mjs";
import * as world_mjs_1 from "../world/world.mjs";
export const STATE_VERSION = 14;
export function createCampaign(name = 'Nova campanha') {
    const now = new Date().toISOString();
    return {
        schemaVersion: STATE_VERSION,
        campaignId: ids_mjs_1.newId('camp'),
        sessionId: ids_mjs_1.newId('sess'),
        name,
        createdAt: now,
        updatedAt: now,
        rulesProfile: 'EOTE_CORE',
        campaignMode: 'EOTE',
        player: { character: null },
        world: world_mjs_1.createWorld(),
        scene: { title: 'Abertura', narration: 'Mestre de IA ainda não conectado.', locationId: null, imageAssetId: null, imageSource: null, imageLocked: false, imagePrompt: null },
        combat: combat_mjs_1.createCombatState(),
        events: [],
        appliedActionIds: [],
        lastCheck: null,
        master: { corpusVersion: 1, lastRuleQuery: null, lastRuleResults: [], lastContext: null, pendingQuestion: null, suggestedActions: [], suggestedCheck: null, lastProposalRuleIds: [], lastRuleAuthority: null, pendingAcquisition: null, acquisitionHistory: [], pendingEncounter: null },
        settings: { ttsEnabled: false, ttsRate: 1, masterProvider: 'none', masterEndpoint: null },
        session: sessionFlow_mjs_1.createSessionRuntime(1),
        sessionHistory: [],
        vehicles: vehicles_mjs_1.createVehicleRuntime(),
        group: fringeGroup_mjs_1.createFringeGroup()
    };
}
export function migrateState(value) {
    if (!value || typeof value !== 'object')
        throw new Error('Estado inválido.');
    const version = Number(value.schemaVersion ?? 1);
    if (version > STATE_VERSION)
        throw new Error(`Versão de estado não suportada: ${value.schemaVersion}`);
    const next = structuredClone(value);
    if (version === 1) {
        next.combat = combat_mjs_1.createCombatState();
        next.schemaVersion = 2;
    }
    if (Number(next.schemaVersion) === 2) {
        next.schemaVersion = 3;
    }
    if (Number(next.schemaVersion) === 3) {
        next.schemaVersion = 4;
    }
    if (Number(next.schemaVersion) === 4) {
        next.schemaVersion = 5;
    }
    if (Number(next.schemaVersion) === 5) {
        next.schemaVersion = 6;
    }
    if (Number(next.schemaVersion) === 6) {
        next.schemaVersion = 7;
    }
    if (Number(next.schemaVersion) === 7) {
        next.schemaVersion = 8;
    }
    if (Number(next.schemaVersion) === 8) {
        next.schemaVersion = 9;
    }
    if (Number(next.schemaVersion) === 9) {
        next.schemaVersion = 10;
    }
    if (Number(next.schemaVersion) === 10) {
        next.schemaVersion = 11;
    }
    if (Number(next.schemaVersion) === 11) {
        next.schemaVersion = 12;
    }
    if (Number(next.schemaVersion) === 12) {
        next.schemaVersion = 13;
    }
    if (Number(next.schemaVersion) === 13) {
        next.schemaVersion = 14;
    }
    const combatDefaults = combat_mjs_1.createCombatState();
    next.combat = { ...combatDefaults, ...(next.combat ?? {}), playerTurn: { ...combatDefaults.playerTurn, ...(next.combat?.playerTurn ?? {}) }, adversaries: Array.isArray(next.combat?.adversaries) ? next.combat.adversaries : [], encounter: next.combat?.encounter ?? null, log: Array.isArray(next.combat?.log) ? next.combat.log : [] };
    next.master = { corpusVersion: 1, lastRuleQuery: null, lastRuleResults: [], lastContext: null, pendingQuestion: null, suggestedActions: [], suggestedCheck: null, lastProposalRuleIds: [], lastRuleAuthority: null, pendingAcquisition: null, acquisitionHistory: [], pendingEncounter: null, ...(next.master ?? {}) };
    next.master.suggestedActions = Array.isArray(next.master.suggestedActions) ? next.master.suggestedActions.map(String).filter(Boolean).slice(0, 6) : [];
    next.master.lastRuleResults = Array.isArray(next.master.lastRuleResults) ? next.master.lastRuleResults : [];
    next.master.lastProposalRuleIds = Array.isArray(next.master.lastProposalRuleIds) ? next.master.lastProposalRuleIds : [];
    next.master.acquisitionHistory = Array.isArray(next.master.acquisitionHistory) ? next.master.acquisitionHistory : [];
    next.settings = { ttsEnabled: false, ttsRate: 1, masterProvider: 'none', masterEndpoint: null, ...(next.settings ?? {}) };
    next.settings.ttsRate = Math.max(0.6, Math.min(1.4, Number(next.settings.ttsRate) || 1));
    next.session = sessionFlow_mjs_1.normalizeSessionRuntime(next.session, 1);
    next.sessionHistory = Array.isArray(next.sessionHistory) ? next.sessionHistory : [];
    next.vehicles = vehicles_mjs_1.normalizeVehicleRuntime(next.vehicles);
    const inferredCampaignMode = next.campaignMode ?? (next.rulesProfile === 'AOR_CORE' || next.player?.character?.creation?.rulesProfile === 'AOR_CORE' ? 'AOR' : 'EOTE');
    next.campaignMode = ['EOTE','AOR','MIXED'].includes(String(inferredCampaignMode).toUpperCase()) ? String(inferredCampaignMode).toUpperCase() : 'EOTE';
    if (next.rulesProfile !== 'EOTE_CORE') {
        next.legacyRulesProfile = String(next.rulesProfile ?? 'unknown');
        next.rulesProfile = 'EOTE_CORE';
    }
    if (next.player?.character) {
        next.player.character.statusEffects = Array.isArray(next.player.character.statusEffects) ? next.player.character.statusEffects : [];
    }
    if (next.player?.character?.creation?.rulesProfile === 'AOR_CORE' && next.campaignMode === 'EOTE') {
        const c = next.player.character;
        c.legacyAoR = {
            ...(c.legacyAoR && typeof c.legacyAoR === 'object' ? c.legacyAoR : {}),
            duties: Array.isArray(c.duties) ? structuredClone(c.duties) : [],
            groupContributionRank: Number(c.groupContributionRank ?? 0),
            originalRulesProfile: 'AOR_CORE',
            note: 'Ficha AoR preservada como legado. Nenhum Duty foi convertido em Obligation.'
        };
        c.obligations = Array.isArray(c.obligations) ? c.obligations : [];
    }
    next.scene = { title: 'Abertura', narration: '', locationId: null, imageAssetId: null, imageSource: null, imageLocked: false, imagePrompt: null, ...(next.scene ?? {}) };
    next.group = next.group ? fringeGroup_mjs_1.normalizeFringeGroup(next.group) : fringeGroup_mjs_1.migrateRebelGroupToFringe(next.rebelGroup);
    if ('rebelGroup' in next)
        delete next.rebelGroup;
    next.world = world_mjs_1.normalizeWorld(next.world);
    return next;
}
export function validateState(value) {
    if (!value || typeof value !== 'object')
        throw new Error('Estado inválido.');
    if (value.schemaVersion !== STATE_VERSION)
        throw new Error(`Versão de estado não suportada: ${value.schemaVersion}`);
    for (const key of ['campaignId', 'sessionId', 'name', 'rulesProfile']) {
        if (typeof value[key] !== 'string' || !value[key])
            throw new Error(`Campo obrigatório inválido: ${key}`);
    }
    if (!Array.isArray(value.events) || !Array.isArray(value.appliedActionIds))
        throw new Error('Coleções de estado inválidas.');
    if (!value.combat || typeof value.combat !== 'object' || typeof value.combat.active !== 'boolean')
        throw new Error('Estado de combate inválido.');
    if (!value.combat.playerTurn || !Number.isInteger(value.combat.playerTurn.maneuversUsed))
        throw new Error('Turno de combate inválido.');
    if (!value.master || typeof value.master !== 'object' || !Array.isArray(value.master.lastRuleResults))
        throw new Error('Estado do Mestre inválido.');
    if (!value.session || typeof value.session !== 'object' || !['nao_iniciada', 'ativa', 'encerrada'].includes(value.session.status))
        throw new Error('Estado de sessão inválido.');
    if (!Array.isArray(value.sessionHistory))
        throw new Error('Histórico de sessões inválido.');
    if (!['EOTE','AOR','MIXED'].includes(value.campaignMode))
        throw new Error('Modo de campanha inválido.');
    if (!value.vehicles || typeof value.vehicles !== 'object' || !value.vehicles.combat || typeof value.vehicles.combat.active !== 'boolean')
        throw new Error('Estado de naves/veículos inválido.');
    fringeGroup_mjs_1.validateFringeGroup(value.group);
    const world = world_mjs_1.normalizeWorld(value.world);
    if (world.schemaVersion !== 6 || !world.clock || !world.factions || typeof world.factions !== 'object' || !Array.isArray(world.events) || !Array.isArray(world.hooks) || !Array.isArray(world.history))
        throw new Error('Estado de mundo inválido.');
    return true;
}
