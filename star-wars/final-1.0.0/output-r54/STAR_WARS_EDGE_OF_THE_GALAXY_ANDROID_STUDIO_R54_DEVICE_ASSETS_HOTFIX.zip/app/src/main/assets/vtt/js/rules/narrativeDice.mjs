const FACES = Object.freeze({
  ability: [{}, {success:1}, {success:1}, {success:2}, {advantage:1}, {advantage:1}, {success:1,advantage:1}, {advantage:2}],
  proficiency: [{}, {success:1}, {success:1}, {success:2}, {success:2}, {advantage:1}, {success:1,advantage:1}, {success:1,advantage:1}, {success:1,advantage:1}, {advantage:2}, {advantage:2}, {triumph:1}],
  difficulty: [{}, {failure:1}, {failure:2}, {threat:1}, {threat:1}, {threat:1}, {threat:2}, {failure:1,threat:1}],
  challenge: [{}, {failure:1}, {failure:1}, {failure:2}, {failure:2}, {threat:1}, {threat:1}, {failure:1,threat:1}, {failure:1,threat:1}, {threat:2}, {threat:2}, {despair:1}],
  boost: [{}, {}, {success:1}, {success:1,advantage:1}, {advantage:2}, {advantage:1}],
  setback: [{}, {}, {failure:1}, {failure:1}, {threat:1}, {threat:1}]
});
function asRank(value,label){const n=Number(value); if(!Number.isInteger(n)||n<0||n>7) throw new Error(`${label} deve estar entre 0 e 7.`); return n;}
export function buildPositivePool(characteristic,skill){characteristic=asRank(characteristic,'Característica'); skill=asRank(skill,'Habilidade'); const total=Math.max(characteristic,skill), upgrades=Math.min(characteristic,skill); return {ability:total-upgrades,proficiency:upgrades};}
export function resolveSymbols(raw={}){const triumph=raw.triumph??0,despair=raw.despair??0; const successTotal=(raw.success??0)+triumph,failureTotal=(raw.failure??0)+despair; const netSuccess=successTotal-failureTotal,netAdvantage=(raw.advantage??0)-(raw.threat??0); return {success:netSuccess>0,netSuccess,netAdvantage,triumph,despair,raw:{success:raw.success??0,failure:raw.failure??0,advantage:raw.advantage??0,threat:raw.threat??0,triumph,despair}};}
export function rollPool(pool,rng=Math.random){const raw={success:0,failure:0,advantage:0,threat:0,triumph:0,despair:0},faces=[]; for(const type of ['ability','proficiency','difficulty','challenge','boost','setback']){const count=Number(pool[type]??0); if(!Number.isInteger(count)||count<0||count>12) throw new Error(`Quantidade inválida de dados: ${type}`); for(let i=0;i<count;i++){const die=FACES[type],index=Math.min(die.length-1,Math.floor(rng()*die.length)),face=die[index]; faces.push({type,index,face}); for(const [symbol,value] of Object.entries(face)) raw[symbol]+=value;}} return {...resolveSymbols(raw),faces,pool:{...pool}};}
export const diceFacesForTests=FACES;
