import * as storage_mjs_1 from "./storage.mjs";
import * as snapshots_mjs_1 from "./snapshots.mjs";
import * as character_mjs_1 from "../rules/character.mjs";
import * as eoteCharacterCreation_mjs_1 from "../rules/eoteCharacterCreation.mjs";
import * as characterCreation_mjs_1 from "../rules/characterCreation.mjs";
import * as labelsPtBr_mjs_1 from "../rules/labelsPtBr.mjs";
import * as controller_mjs_1 from "./controller.mjs";
import * as imageLibraryData_mjs_1 from "../library/imageLibraryData.mjs";
import * as sceneLibrary_mjs_1 from "../library/sceneLibrary.mjs";
import * as imageLibrary_mjs_1 from "../library/imageLibrary.mjs";
export const UI_BRIDGE_VERSION = 3;
function clone(value) {
    return value === undefined ? undefined : structuredClone(value);
}
function messageOf(error) {
    return error instanceof Error ? error.message : String(error ?? 'Erro desconhecido.');
}
function ok(data) {
    return { ok: true, data };
}
function fail(error, message) {
    return { ok: false, error, message };
}
const nativeMasterRequests = new Map();
let nativeMasterHookInstalled = false;
function nativeGeminiStatus(target = globalThis) {
    const bridge = target?.BraseiroGemini;
    if (!bridge || typeof bridge.getStatus !== 'function' || typeof bridge.requestMasterProposal !== 'function')
        return { available: false, configured: false };
    try {
        const raw = bridge.getStatus();
        const status = typeof raw === 'string' ? JSON.parse(raw) : raw;
        return { available: true, configured: Boolean(status?.configured), model: status?.masterModel ?? null, generating: Boolean(status?.masterGenerating) };
    }
    catch {
        return { available: true, configured: false, invalid: true };
    }
}
function ensureNativeMasterHook(target = globalThis) {
    if (nativeMasterHookInstalled || !target)
        return;
    nativeMasterHookInstalled = true;
    const previous = typeof target.braseiroMasterNativeEvent === 'function' ? target.braseiroMasterNativeEvent : null;
    target.braseiroMasterNativeEvent = (raw) => {
        try {
            previous?.(raw);
        }
        catch { }
        let event;
        try {
            event = typeof raw === 'string' ? JSON.parse(raw) : raw;
        }
        catch {
            return;
        }
        const requestId = String(event?.requestId ?? '');
        const pending = nativeMasterRequests.get(requestId);
        if (!pending)
            return;
        nativeMasterRequests.delete(requestId);
        clearTimeout(pending.timer);
        if (event?.ok === true && event.proposal && typeof event.proposal === 'object')
            pending.resolve({ proposal: event.proposal, model: event.model ?? null });
        else
            pending.reject(new Error(String(event?.message ?? 'O Mestre Gemini não retornou uma proposta válida.')));
    };
}
function requestNativeGeminiMaster(providerPayload, { timeoutMs = 60000, target = globalThis } = {}) {
    const status = nativeGeminiStatus(target);
    if (!status.available)
        return Promise.reject(new Error('Host Gemini nativo indisponível.'));
    if (!status.configured)
        return Promise.reject(new Error('Configure a chave Gemini em AJUSTES → Gemini / provedor antes de iniciar a narração.'));
    ensureNativeMasterHook(target);
    const requestId = `master_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
    return new Promise((resolve, reject) => {
        const timer = setTimeout(() => { nativeMasterRequests.delete(requestId); reject(new Error('Tempo limite do Mestre Gemini excedido.')); }, Math.max(5000, Number(timeoutMs) || 60000));
        nativeMasterRequests.set(requestId, { resolve, reject, timer });
        try {
            const raw = target.BraseiroGemini.requestMasterProposal(requestId, JSON.stringify(providerPayload));
            const started = typeof raw === 'string' ? JSON.parse(raw) : raw;
            if (!started?.ok) {
                nativeMasterRequests.delete(requestId);
                clearTimeout(timer);
                reject(new Error(String(started?.message ?? 'Não foi possível iniciar o Mestre Gemini.')));
            }
        }
        catch (error) {
            nativeMasterRequests.delete(requestId);
            clearTimeout(timer);
            reject(error instanceof Error ? error : new Error(String(error)));
        }
    });
}
export class BraseiroUiBridge {
    constructor({ repository = null, storage = globalThis.localStorage, snapshots = null } = {}) {
        this.repository = repository ?? new storage_mjs_1.LocalStorageRepository(storage);
        const snapshotStorage = this.repository?.storage ?? storage;
        this.snapshots = snapshots ?? new snapshots_mjs_1.LocalSnapshotRepository(snapshotStorage);
    }
    readState() {
        try {
            const state = this.repository.load();
            return ok(state ? clone(state) : null);
        }
        catch (error) {
            return fail('STATE_READ_FAILED', messageOf(error));
        }
    }
    initializeCampaign() {
        try {
            const existing = this.repository.load();
            if (existing)
                return ok({ created: false, state: clone(existing) });
            const game = new controller_mjs_1.GameController(this.repository);
            return ok({ created: true, state: clone(game.state) });
        }
        catch (error) {
            return fail('CAMPAIGN_INIT_FAILED', messageOf(error));
        }
    }
    campaignModeSummary() {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.campaignModeSummary())); }
        catch (error) { return fail('CAMPAIGN_MODE_FAILED', messageOf(error)); }
    }
    setCampaignMode(mode = 'EOTE') {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.setCampaignMode(mode))); }
        catch (error) { return fail('CAMPAIGN_MODE_FAILED', messageOf(error)); }
    }
    initializeLivingSandbox(options = {}) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.initializeLivingSandbox(options ?? {}))); }
        catch (error) { return fail('SANDBOX_INIT_FAILED', messageOf(error)); }
    }
    livingSandboxStatus() {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.livingSandboxStatus())); }
        catch (error) { return fail('SANDBOX_READ_FAILED', messageOf(error)); }
    }
    sandboxOpening(options = {}) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.sandboxOpening(options ?? {}))); }
        catch (error) { return fail('SANDBOX_READ_FAILED', messageOf(error)); }
    }
    startLivingAdventure(options = {}) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.startLivingAdventure(options ?? {}))); }
        catch (error) { return fail('ADVENTURE_START_FAILED', messageOf(error)); }
    }
    travelToLocation(locationId, options = {}) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.travelToLocation(String(locationId ?? ''), options ?? {}))); }
        catch (error) { return fail('TRAVEL_FAILED', messageOf(error)); }
    }
    scenePlayerView() {
        let state;
        try {
            state = this.repository.load();
        }
        catch (error) {
            return fail('STATE_READ_FAILED', messageOf(error));
        }
        if (!state)
            return fail('NO_CAMPAIGN', 'Nenhuma campanha carregada.');
        try {
            const world = state.world ?? {};
            const sceneLocationId = state.scene?.locationId ?? null;
            const locationCandidate = sceneLocationId ? world.locations?.[sceneLocationId] ?? null : null;
            const location = locationCandidate?.knownToPlayer
                ? { id: locationCandidate.id, name: String(locationCandidate.name ?? ''), description: String(locationCandidate.description ?? '') }
                : null;
            const participants = [];
            const seenNames = new Set();
            const pushParticipant = (value) => {
                const name = String(value?.name ?? '').trim();
                if (!name || seenNames.has(name.toLocaleLowerCase('pt-BR')) || participants.length >= 3)
                    return;
                seenNames.add(name.toLocaleLowerCase('pt-BR'));
                participants.push({
                    name,
                    meta: String(value?.meta ?? '').trim(),
                    status: String(value?.status ?? '').trim(),
                });
            };
            for (const npc of Object.values(world.npcs ?? {})) {
                if (!npc?.knownToPlayer)
                    continue;
                if (sceneLocationId && npc.locationId && npc.locationId !== sceneLocationId)
                    continue;
                pushParticipant({ name: npc.name, meta: npc.relation || 'Conhecido', status: npc.status || '' });
            }
            if (state.combat?.active) {
                for (const adversary of state.combat.adversaries ?? []) {
                    pushParticipant({ name: adversary.name || adversary.id, meta: 'Em confronto', status: adversary.status || '' });
                }
            }
            if (state.vehicles?.combat?.active) {
                const targetId = state.vehicles.combat.targetVehicleId;
                const target = targetId ? state.vehicles.vehicles?.[targetId] ?? null : null;
                if (target)
                    pushParticipant({ name: target.name, meta: 'Veículo / nave alvo', status: 'Em confronto' });
            }
            const activeVehicleId = state.vehicles?.activeVehicleId ?? null;
            const activeVehicle = activeVehicleId ? state.vehicles?.vehicles?.[activeVehicleId] ?? null : null;
            const defense = activeVehicle?.defense ?? null;
            const vehicle = activeVehicle ? {
                name: String(activeVehicle.name ?? ''),
                hull: `${Number(activeVehicle.hullDamage ?? 0)}/${Number(activeVehicle.hullThreshold ?? 0)}`,
                strain: `${Number(activeVehicle.systemStrain ?? 0)}/${Number(activeVehicle.systemStrainThreshold ?? 0)}`,
                speed: `${Number(activeVehicle.speed ?? 0)}/${Number(activeVehicle.speedMax ?? 0)}`,
                defense: defense ? `P${Number(defense.proa ?? 0)} · B${Number(defense.babor ?? 0)} · E${Number(defense.estribor ?? 0)} · R${Number(defense.popa ?? 0)}` : '—',
            } : null;
            const phaseLabels = {
                abertura: 'Abertura', cena: 'Cena', decisao: 'Decisão do jogador', resolucao: 'Resolução',
                consequencia: 'Consequência', conflito: 'Conflito', recuperacao: 'Recuperação', encerramento: 'Encerramento', encerrada: 'Sessão encerrada'
            };
            let situation = '';
            if (state.vehicles?.combat?.active) {
                situation = `Combate veicular / espacial · rodada ${Number(state.vehicles.combat.round ?? 0) || 1} · alcance ${String(state.vehicles.combat.range ?? '—')}.`;
            }
            else if (state.combat?.active) {
                situation = `Combate pessoal · rodada ${Number(state.combat.round ?? 0) || 1}.`;
            }
            else if (location?.description) {
                situation = location.description;
            }
            else if (location?.name) {
                situation = `Local atual: ${location.name}.`;
            }
            else if (state.session?.status === 'ativa') {
                situation = `Sessão ${Number(state.session.number ?? 1)} · ${phaseLabels[state.session.phase] ?? 'Cena'}.`;
            }
            else {
                situation = 'Aguardando o início da próxima cena.';
            }
            const sceneVisual = sceneLibrary_mjs_1.resolveSceneVisualForState(state);
            return ok({
                scene: { title: String(state.scene?.title ?? ''), location, imageAssetId: sceneVisual.asset?.assetId ?? null, imageSource: sceneVisual.source, image: sceneVisual.descriptor, imageFallback: sceneVisual.asset ? null : 'gemini' },
                situation: String(situation).slice(0, 900),
                participants,
                suggestedActions: Array.isArray(state.master?.suggestedActions) ? state.master.suggestedActions.map(String).filter(Boolean).slice(0, 6) : [],
                suggestedCheck: state.master?.suggestedCheck ? clone(state.master.suggestedCheck) : null,
                vehicle,
                session: state.session ? { status: state.session.status, phase: state.session.phase, number: state.session.number } : null,
                lastCheck: state.lastCheck ? clone(state.lastCheck) : null,
            });
        }
        catch (error) {
            return fail('PLAYER_VIEW_FAILED', messageOf(error));
        }
    }
    resolveSuggestedMasterCheck() {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok)
            return controllerResult;
        try {
            const check = controllerResult.data.resolveSuggestedMasterCheck();
            return ok({ check: clone(check), state: clone(controllerResult.data.state) });
        }
        catch (error) {
            return fail('CHECK_REJECTED', messageOf(error));
        }
    }
    _controllerForExistingCampaign() {
        let existing;
        try {
            existing = this.repository.load();
        }
        catch (error) {
            return fail('STATE_READ_FAILED', messageOf(error));
        }
        if (!existing)
            return fail('NO_CAMPAIGN', 'Nenhuma campanha carregada.');
        try {
            return ok(new controller_mjs_1.GameController(this.repository));
        }
        catch (error) {
            return fail('STATE_READ_FAILED', messageOf(error));
        }
    }
    exportCharacterJson() {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok)
            return controllerResult;
        try {
            const game = controllerResult.data;
            const json = game.exportCharacter();
            const name = String(game.state.player?.character?.name ?? 'personagem').trim() || 'personagem';
            const safeName = name.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9._-]+/g, '_').replace(/^_+|_+$/g, '') || 'personagem';
            return ok({ fileName: `${safeName}.json`, json });
        }
        catch (error) {
            return fail('CHARACTER_EXPORT_FAILED', messageOf(error));
        }
    }
    generateRandomCharacter(options = {}, { createSnapshot = true } = {}) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok)
            return controllerResult;
        const game = controllerResult.data;
        let character;
        try {
            character = String(game.state.campaignMode ?? 'EOTE').toUpperCase() === 'AOR'
                ? characterCreation_mjs_1.createRandomAorCoreCharacter(options)
                : game.buildRandomCharacter(options);
        }
        catch (error) {
            return fail('RANDOM_CHARACTER_FAILED', messageOf(error));
        }
        try {
            let snapshotId = null;
            if (createSnapshot && game.state.player?.character)
                snapshotId = this.snapshots.create(game.state, 'Antes de gerar ficha aleatória').id;
            const created = game.setCharacter(character);
            return ok({ character: clone(created), snapshotId, state: clone(game.state) });
        }
        catch (error) {
            return fail('RANDOM_CHARACTER_FAILED', messageOf(error));
        }
    }
    importCharacterJson(text, { createSnapshot = true } = {}) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok)
            return controllerResult;
        let character;
        try {
            character = character_mjs_1.importCharacterJson(String(text ?? ''));
        }
        catch (error) {
            return fail('CHARACTER_IMPORT_FAILED', messageOf(error));
        }
        const game = controllerResult.data;
        try {
            let snapshotId = null;
            if (createSnapshot)
                snapshotId = this.snapshots.create(game.state, 'Antes de importar ficha').id;
            const imported = game.setCharacter(character);
            return ok({ character: clone(imported), snapshotId, state: clone(game.state) });
        }
        catch (error) {
            return fail('CHARACTER_IMPORT_FAILED', messageOf(error));
        }
    }
    exportCampaignBackup() {
        let state;
        try {
            state = this.repository.load();
        }
        catch (error) {
            return fail('STATE_READ_FAILED', messageOf(error));
        }
        if (!state)
            return fail('NO_CAMPAIGN', 'Nenhuma campanha carregada.');
        try {
            const json = storage_mjs_1.exportStateJson(state);
            const name = String(state.name ?? 'campanha').trim() || 'campanha';
            const safeName = name.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9._-]+/g, '_').replace(/^_+|_+$/g, '') || 'campanha';
            return ok({ fileName: `${safeName}.backup.json`, json });
        }
        catch (error) {
            return fail('BACKUP_EXPORT_FAILED', messageOf(error));
        }
    }
    importCampaignBackup(text, { createSnapshot = true } = {}) {
        let imported;
        try {
            imported = storage_mjs_1.importStateJson(String(text ?? ''));
        }
        catch (error) {
            return fail('BACKUP_IMPORT_FAILED', messageOf(error));
        }
        let existing = null;
        try {
            existing = this.repository.load();
        }
        catch (error) {
            return fail('STATE_READ_FAILED', messageOf(error));
        }
        try {
            let snapshotId = null;
            if (createSnapshot && existing)
                snapshotId = this.snapshots.create(existing, 'Antes de restaurar backup').id;
            this.repository.save(imported);
            return ok({ state: clone(imported), snapshotId });
        }
        catch (error) {
            return fail('BACKUP_IMPORT_FAILED', messageOf(error));
        }
    }
    listSnapshots() {
        try {
            return ok(this.snapshots.list().map(item => ({ id: item.id, label: item.label, createdAt: item.createdAt })));
        }
        catch (error) {
            return fail('SNAPSHOT_READ_FAILED', messageOf(error));
        }
    }
    createSnapshot(label = 'backup manual') {
        let state;
        try {
            state = this.repository.load();
        }
        catch (error) {
            return fail('STATE_READ_FAILED', messageOf(error));
        }
        if (!state)
            return fail('NO_CAMPAIGN', 'Nenhuma campanha carregada.');
        try {
            const item = this.snapshots.create(state, String(label ?? 'backup manual').trim() || 'backup manual');
            return ok({ id: item.id, label: item.label, createdAt: item.createdAt });
        }
        catch (error) {
            return fail('SNAPSHOT_CREATE_FAILED', messageOf(error));
        }
    }
    creationCatalog() {
        try {
            const state = this.repository.load();
            const mode = String(state?.campaignMode ?? 'EOTE').toUpperCase();
            const useAor = mode === 'AOR';
            const speciesSource = useAor ? characterCreation_mjs_1.AOR_SPECIES : eoteCharacterCreation_mjs_1.EOTE_SPECIES;
            const careerSource = useAor ? characterCreation_mjs_1.AOR_CAREERS : eoteCharacterCreation_mjs_1.EOTE_CAREERS;
            const species = Object.entries(speciesSource).map(([key, value]) => ({
                key,
                label: value.label,
                characteristics: clone(value.characteristics),
                woundBase: value.woundBase,
                strainBase: value.strainBase,
                xp: value.xp,
                careerFreeCount: value.careerFreeCount ?? 4,
                specializationFreeCount: value.specFreeCount ?? 2,
                freeSkill: value.freeSkill ? clone(value.freeSkill) : null,
                freeTalents: clone(value.freeTalents ?? []),
                speciesChoice: value.speciesChoice ? clone(value.speciesChoice) : null,
                abilities: clone(value.abilities ?? []),
            }));
            const careers = Object.entries(careerSource).map(([key, value]) => ({
                key,
                label: value.label,
                skills: clone(value.skills),
                specializations: Object.entries(value.specializations ?? {}).map(([specializationKey, specialization]) => ({ key: specializationKey, label: specialization.label, skills: clone(specialization.skills) })),
            }));
            return ok({
                profile: 'EOTE_CORE',
                activeProfile: useAor ? 'AOR_CORE' : 'EOTE_CORE',
                campaignMode: mode,
                species,
                careers,
                obligationTypes: clone(useAor ? characterCreation_mjs_1.DUTY_TYPES_PT_BR : eoteCharacterCreation_mjs_1.OBLIGATION_TYPES_PT_BR),
                characteristicLabels: clone(labelsPtBr_mjs_1.CHARACTERISTIC_LABELS_PT_BR),
                skillLabels: clone(labelsPtBr_mjs_1.SKILL_LABELS_PT_BR),
            });
        }
        catch (error) { return fail('CREATION_CATALOG_FAILED', messageOf(error)); }
    }
    creationPreview(options = {}) {
        try {
            const state = this.repository.load();
            const useAor = String(state?.campaignMode ?? 'EOTE').toUpperCase() === 'AOR';
            if (!useAor) {
                const preview = eoteCharacterCreation_mjs_1.eoteCreationPreview(options);
                if (!preview) return fail('INVALID_INPUT', 'Selecione uma espécie válida para calcular o orçamento de criação.');
                return ok(clone(preview));
            }
            const mapped = { ...clone(options), dutyType: options.obligationType, dutyReductions: clone(options.obligationBenefits ?? {}) };
            const preview = characterCreation_mjs_1.creationPreview(mapped);
            if (!preview) return fail('INVALID_INPUT', 'Selecione uma espécie válida para calcular o orçamento de criação.');
            return ok({
                xpBudget: preview.xpBudget, characteristicCost: preview.characteristicCost, xpRemaining: preview.xpRemaining, credits: preview.credits,
                obligation: preview.duty, startingObligation: preview.duty + preview.dutySpent, additionalObligation: -preview.dutySpent,
                obligationOfficial: preview.dutyOfficial, obligationNote: preview.dutyNote ?? null, speciesXpBonus: 0,
                activeProfile: 'AOR_CORE', duty: preview.duty, dutySpent: preview.dutySpent
            });
        }
        catch (error) { return fail('CREATION_PREVIEW_FAILED', messageOf(error)); }
    }
    createCustomCharacter(options = {}, { createSnapshot = true } = {}) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        const game = controllerResult.data;
        let snapshotId = null;
        try {
            const mode = String(game.state.campaignMode ?? 'EOTE').toUpperCase();
            let mapped = null;
            if (mode === 'AOR') {
                mapped = { ...clone(options), dutyType: options.obligationType, dutyReductions: clone(options.obligationBenefits ?? {}) };
                characterCreation_mjs_1.createAorCoreCharacter(mapped);
            } else {
                eoteCharacterCreation_mjs_1.createEoteCoreCharacter(options);
            }
            if (createSnapshot && game.state.player?.character) snapshotId = this.snapshots.create(game.state, 'Antes de criar ficha manual').id;
            const created = mode === 'AOR' ? game.createAorCharacter(mapped) : game.createCustomCharacter(options);
            return ok({ character: clone(created), snapshotId, state: clone(game.state) });
        }
        catch (error) {
            if (snapshotId) { try { this.snapshots.remove(snapshotId); } catch {} }
            return fail('CUSTOM_CHARACTER_FAILED', messageOf(error));
        }
    }
    ownedSpecializations() {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.ownedSpecializations())); }
        catch (error) { return fail('PROGRESSION_FAILED', messageOf(error)); }
    }
    specializationPurchaseCost(careerKey, specializationKey) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.specializationPurchaseCost(String(careerKey ?? ''), String(specializationKey ?? '')))); }
        catch (error) { return fail('PROGRESSION_FAILED', messageOf(error)); }
    }
    buySpecialization(careerKey, specializationKey) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.buySpecialization(String(careerKey ?? ''), String(specializationKey ?? '')))); }
        catch (error) { return fail('PROGRESSION_FAILED', messageOf(error)); }
    }
    talentTree(selector = {}) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.talentTree(selector ?? {}))); }
        catch (error) { return fail('PROGRESSION_FAILED', messageOf(error)); }
    }
    eligibleTalents(selector = {}) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.eligibleTalents(selector ?? {}))); }
        catch (error) { return fail('PROGRESSION_FAILED', messageOf(error)); }
    }
    buyTalent(nodeId, options = {}) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.buyTalent(String(nodeId ?? ''), options ?? {}))); }
        catch (error) { return fail('PROGRESSION_FAILED', messageOf(error)); }
    }
    forceStatus() {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.forceStatus())); }
        catch (error) { return fail('FORCE_FAILED', messageOf(error)); }
    }
    forceCatalog() {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.forceCatalog())); }
        catch (error) { return fail('FORCE_FAILED', messageOf(error)); }
    }
    buyForcePower(powerKey) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.buyForcePower(String(powerKey ?? '')))); }
        catch (error) { return fail('FORCE_FAILED', messageOf(error)); }
    }
    buyForceUpgrade(powerKey, upgradeId) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.buyForceUpgrade(String(powerKey ?? ''), String(upgradeId ?? '')))); }
        catch (error) { return fail('FORCE_FAILED', messageOf(error)); }
    }
    rollForcePowerCheck(options = {}) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.rollForcePowerCheck(options ?? {}))); }
        catch (error) { return fail('FORCE_FAILED', messageOf(error)); }
    }
    commitForce(effectId, count = 1) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.commitForce(String(effectId ?? ''), Number(count)))); }
        catch (error) { return fail('FORCE_FAILED', messageOf(error)); }
    }
    releaseForce(effectId) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.releaseForce(String(effectId ?? '')))); }
        catch (error) { return fail('FORCE_FAILED', messageOf(error)); }
    }
    startSession(options = {}) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.startSession(options ?? {}))); }
        catch (error) { return fail('SESSION_RULES_FAILED', messageOf(error)); }
    }
    closeSession(options = {}) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.closeSession(options ?? {}))); }
        catch (error) { return fail('SESSION_RULES_FAILED', messageOf(error)); }
    }
    encumbranceStatus() {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.encumbranceStatus())); }
        catch (error) { return fail('ENCUMBRANCE_FAILED', messageOf(error)); }
    }
    liftingDifficulty(objectEncumbrance, options = {}) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.liftingDifficulty(Number(objectEncumbrance), options ?? {}))); }
        catch (error) { return fail('ENCUMBRANCE_FAILED', messageOf(error)); }
    }
    statusSummary() {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.statusSummary())); }
        catch (error) { return fail('STATUS_FAILED', messageOf(error)); }
    }
    applyStatus(payload = {}) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.applyStatus(payload ?? {}))); }
        catch (error) { return fail('STATUS_FAILED', messageOf(error)); }
    }
    spendDestiny(side) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.spendDestiny(String(side ?? '')))); }
        catch (error) { return fail('DESTINY_FAILED', messageOf(error)); }
    }
    resolveFearCheck(options = {}) {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok) return controllerResult;
        try { return ok(clone(controllerResult.data.resolveFearCheck(options ?? {}))); }
        catch (error) { return fail('FEAR_FAILED', messageOf(error)); }
    }
    equipmentCatalog() {
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok)
            return controllerResult;
        try {
            const game = controllerResult.data;
            return ok(clone(game.equipmentCatalog()));
        }
        catch (error) {
            return fail('EQUIPMENT_CATALOG_FAILED', messageOf(error));
        }
    }
    proposeWeaponAcquisition(itemId) {
        const id = String(itemId ?? '').trim();
        if (!id)
            return fail('INVALID_INPUT', 'Selecione uma arma do catálogo auditado.');
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok)
            return controllerResult;
        try {
            const game = controllerResult.data;
            const result = game.proposeWeaponAcquisition(id);
            return ok({
                result: clone(result),
                pendingAcquisition: clone(game.state.master?.pendingAcquisition ?? null),
                state: clone(game.state),
            });
        }
        catch (error) {
            return fail('EQUIPMENT_ACQUISITION_FAILED', messageOf(error));
        }
    }
    restoreSnapshot(id) {
        let before = null;
        try {
            before = this.repository.load();
        }
        catch (error) {
            return fail('STATE_READ_FAILED', messageOf(error));
        }
        if (!before)
            return fail('NO_CAMPAIGN', 'Nenhuma campanha carregada.');
        try {
            const restored = this.snapshots.restore(String(id ?? ''));
            this.repository.save(restored);
            return ok({ state: clone(restored) });
        }
        catch (error) {
            return fail('SNAPSHOT_RESTORE_FAILED', messageOf(error));
        }
    }
    imageLibraryInfo() {
        try {
            const validation = imageLibrary_mjs_1.validateImageManifest(imageLibraryData_mjs_1.IMAGE_LIBRARY_MANIFEST);
            if (!validation.ok)
                return fail('IMAGE_LIBRARY_INVALID', validation.errors.join('; '));
            return ok({
                libraryId: imageLibraryData_mjs_1.IMAGE_LIBRARY_MANIFEST.libraryId,
                schemaVersion: imageLibraryData_mjs_1.IMAGE_LIBRARY_MANIFEST.schemaVersion,
                counts: clone(imageLibraryData_mjs_1.IMAGE_LIBRARY_MANIFEST.counts),
                policy: clone(imageLibraryData_mjs_1.IMAGE_LIBRARY_MANIFEST.policy),
            });
        }
        catch (error) {
            return fail('IMAGE_LIBRARY_FAILED', messageOf(error));
        }
    }
    searchImageLibrary(criteria = {}) {
        try {
            const validation = imageLibrary_mjs_1.validateImageManifest(imageLibraryData_mjs_1.IMAGE_LIBRARY_MANIFEST);
            if (!validation.ok)
                return fail('IMAGE_LIBRARY_INVALID', validation.errors.join('; '));
            return ok(clone(imageLibrary_mjs_1.searchImageAssets(imageLibraryData_mjs_1.IMAGE_LIBRARY_MANIFEST, criteria)));
        }
        catch (error) {
            return fail('IMAGE_LIBRARY_SEARCH_FAILED', messageOf(error));
        }
    }
    imageAsset(assetId) {
        const id = String(assetId ?? '').trim();
        if (!id)
            return fail('INVALID_INPUT', 'Informe o assetId da imagem.');
        try {
            const asset = imageLibrary_mjs_1.getImageAsset(imageLibraryData_mjs_1.IMAGE_LIBRARY_MANIFEST, id);
            if (!asset)
                return fail('IMAGE_ASSET_NOT_FOUND', 'Imagem não encontrada na biblioteca.');
            return ok(clone(asset));
        }
        catch (error) {
            return fail('IMAGE_LIBRARY_FAILED', messageOf(error));
        }
    }
    imageMapCatalog(criteria = {}) {
        try {
            const validation = imageLibrary_mjs_1.validateImageManifest(imageLibraryData_mjs_1.IMAGE_LIBRARY_MANIFEST);
            if (!validation.ok)
                return fail('IMAGE_LIBRARY_INVALID', validation.errors.join('; '));
            return ok(clone(imageLibrary_mjs_1.searchImageAssets(imageLibraryData_mjs_1.IMAGE_LIBRARY_MANIFEST, { ...criteria, category: 'map', limit: criteria?.limit ?? 500 })));
        }
        catch (error) {
            return fail('IMAGE_LIBRARY_SEARCH_FAILED', messageOf(error));
        }
    }
    imageVisualEntityCatalog(criteria = {}) {
        try {
            const validation = imageLibrary_mjs_1.validateImageManifest(imageLibraryData_mjs_1.IMAGE_LIBRARY_MANIFEST);
            if (!validation.ok)
                return fail('IMAGE_LIBRARY_INVALID', validation.errors.join('; '));
            const kind = String(criteria?.kind ?? 'all').trim().toLowerCase();
            const limit = Math.max(0, Math.min(Number(criteria?.limit) || 500, 500));
            const common = { ...criteria, limit: 500 };
            delete common.kind;
            const groups = [];
            if (kind === 'all' || kind === 'npc')
                groups.push(...imageLibrary_mjs_1.searchImageAssets(imageLibraryData_mjs_1.IMAGE_LIBRARY_MANIFEST, { ...common, category: 'portrait', subtype: 'npc', limit: 500 }));
            if (kind === 'all' || kind === 'droid')
                groups.push(...imageLibrary_mjs_1.searchImageAssets(imageLibraryData_mjs_1.IMAGE_LIBRARY_MANIFEST, { ...common, category: 'droid', limit: 500 }));
            if (kind === 'all' || kind === 'beast' || kind === 'creature')
                groups.push(...imageLibrary_mjs_1.searchImageAssets(imageLibraryData_mjs_1.IMAGE_LIBRARY_MANIFEST, { ...common, category: 'creature', subtype: 'beast', limit: 500 }));
            if (kind === 'all' || kind === 'vehicle' || kind === 'vehicles' || kind === 'ship' || kind === 'starship' || kind === 'starships')
                groups.push(...imageLibrary_mjs_1.searchImageAssets(imageLibraryData_mjs_1.IMAGE_LIBRARY_MANIFEST, { ...common, category: 'vehicle', limit: 500 }));
            if (!['all', 'npc', 'droid', 'beast', 'creature', 'vehicle', 'vehicles', 'ship', 'starship', 'starships'].includes(kind))
                return fail('INVALID_INPUT', 'Tipo visual inválido.');
            groups.sort((a, b) => a.title.localeCompare(b.title, 'pt-BR') || a.assetId.localeCompare(b.assetId));
            return ok(clone(groups.slice(0, limit)));
        }
        catch (error) {
            return fail('IMAGE_LIBRARY_SEARCH_FAILED', messageOf(error));
        }
    }
    imageAssetRuntime(assetId) {
        const id = String(assetId ?? '').trim();
        if (!id)
            return fail('INVALID_INPUT', 'Informe o assetId da imagem.');
        try {
            const asset = imageLibrary_mjs_1.getImageAsset(imageLibraryData_mjs_1.IMAGE_LIBRARY_MANIFEST, id);
            if (!asset)
                return fail('IMAGE_ASSET_NOT_FOUND', 'Imagem não encontrada na biblioteca.');
            return ok(clone(imageLibrary_mjs_1.imageAssetRuntimeDescriptor(imageLibraryData_mjs_1.IMAGE_LIBRARY_MANIFEST, asset)));
        }
        catch (error) {
            return fail('IMAGE_LIBRARY_FAILED', messageOf(error));
        }
    }
    async submitPlayerIntent(text, { fetchImpl = globalThis.fetch, timeoutMs = 60000, signal = null } = {}) {
        const intentText = String(text ?? '').trim();
        if (!intentText)
            return fail('INVALID_INPUT', 'Digite uma ação.');
        const controllerResult = this._controllerForExistingCampaign();
        if (!controllerResult.ok)
            return controllerResult;
        const game = controllerResult.data;
        try {
            // Provider HTTP explícito continua sendo autoridade quando configurado.
            if (game.state.settings?.masterProvider === 'http') {
                const result = await game.requestMasterTurn({
                    intentText,
                    endpoint: game.state.settings.masterEndpoint,
                    fetchImpl,
                    timeoutMs,
                    signal,
                });
                return ok({ mode: 'http', result: clone(result), state: clone(game.state) });
            }
            // No Android final, Gemini é o narrador padrão quando a chave está configurada.
            // A mutação continua passando exclusivamente por requestMasterTurn/validateMasterProposal.
            const native = nativeGeminiStatus(globalThis);
            if (native.available && native.configured) {
                if (game.state.player?.character && game.state.session?.status !== 'ativa')
                    game.startSession();
                const nativeFetch = async (_url, init = {}) => {
                    let providerPayload;
                    try {
                        providerPayload = JSON.parse(String(init.body ?? '{}'));
                    }
                    catch {
                        throw new Error('Contexto serializado do Motor Barbara inválido.');
                    }
                    const remote = await requestNativeGeminiMaster(providerPayload, { timeoutMs, target: globalThis });
                    return { ok: true, status: 200, json: async () => ({ proposal: remote.proposal, meta: { provider: 'gemini-native', model: remote.model ?? native.model ?? null } }) };
                };
                const result = await game.requestMasterTurn({
                    intentText,
                    endpoint: 'https://braseiro.native/master',
                    fetchImpl: nativeFetch,
                    timeoutMs,
                    signal,
                });
                return ok({ mode: 'gemini-native', result: clone(result), state: clone(game.state) });
            }
            // Fallback local deliberadamente não inventa prosa: registra a intenção, consulta o
            // contexto/regras canônicas e mantém a campanha utilizável mesmo sem rede/chave.
            const result = game.submitIntent(intentText);
            return ok({
                mode: 'local',
                result: clone(result),
                state: clone(game.state),
                masterNotice: native.available && !native.configured
                    ? 'Configure a chave Gemini em AJUSTES → Gemini / provedor para habilitar a narração automática.'
                    : 'Narrador remoto indisponível; o Motor Barbara local preservou estado e contexto de regras.',
            });
        }
        catch (error) {
            return fail('ENGINE_REJECTED', messageOf(error));
        }
    }
}
export function createBraseiroUiBridge(options = {}) {
    return new BraseiroUiBridge(options);
}
export function installBraseiroUiBridge(target = globalThis, options = {}) {
    if (!target || (typeof target !== 'object' && typeof target !== 'function'))
        throw new Error('Alvo global inválido para a ponte de UI.');
    if (target.BraseiroGameBridge)
        return target.BraseiroGameBridge;
    const bridge = createBraseiroUiBridge(options);
    Object.defineProperty(target, 'BraseiroGameBridge', {
        value: bridge,
        configurable: false,
        enumerable: false,
        writable: false,
    });
    return bridge;
}
