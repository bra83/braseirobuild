# STAR WARS — EDGE OF THE GALAXY — Android Studio FINAL 1.0.0

Projeto Android Studio mobile-first do VTT, com shell R46 em 415×915 e Motor Barbara local. O modo padrão continua **Edge of the Empire (`EOTE_CORE`) + Obligation**, com seleção explícita de **EOTE / AOR / MIXED**. Duty de criação e a estrutura Duty/Contribution usam somente as autoridades AoR recuperadas/auditadas; comportamento de runtime sem página primária preservada fica marcado como política local testada.

## Abrir no Android Studio

1. Extraia o ZIP final inteiro.
2. Abra a pasta raiz que contém `settings.gradle.kts`.
3. Use JDK 17.
4. Instale/seleciona Android SDK 36.
5. Aguarde o primeiro sync. `gradlew`/`gradlew.bat` delegam ao `gradle-wrapper.jar`; URL e SHA-256 da distribuição Gradle 8.13 ficam centralizados em `gradle-wrapper.properties`.
6. Execute o módulo `app` em Android 8.0 (API 26) ou superior.

Não é necessário GitHub, npm, servidor web ou build separado da interface. A shell, React runtime, Motor Barbara e assets usados pelo app ficam em `app/src/main/assets/vtt/`.

## Primeiro uso

- O app cria explicitamente a campanha local canônica no primeiro boot, antes de montar a shell.
- Em **PERSONAGEM**, abra o fluxo de criação e crie uma ficha pelas regras auditadas ou importe uma ficha `.json`.
- Em **AJUSTES → Gemini / provedor**, salve sua chave Gemini para habilitar narração automática e geração opcional de imagem de cena. A chave é protegida pelo Android Keystore e não é gravada no projeto.
- Sem chave/rede, o Motor Barbara local continua preservando campanha, regras, intenções, contexto, fichas, snapshots, mundo e resolução mecânica; ele não inventa prosa remota.
- PDFs podem ser importados pela Biblioteca/RAG local.

## Arquitetura congelada

Navegação principal: **CENA / PERSONAGEM / ITENS / NAVE / REGISTROS**. Combate pessoal e espacial são estados de CENA. Mapa e Ajustes são utilidades. A UI não aplica mecânica por conta própria; mutações passam pelo Motor Barbara.

## Recursos fechados em 1.0.0

- shell visual R46 415×915;
- Motor Barbara com estado canônico e validação de propostas;
- dados narrativos FFG/Edge e resolução de perícias;
- combate pessoal e veicular/espacial;
- NPCs persistentes, memória e mundo vivo;
- situação, participantes, ações sugeridas e teste sugerido ligados à CENA real;
- criação manual e aleatória de personagem;
- inventário e aquisição mediada pelo Mestre;
- save/load de ficha JSON, backup de campanha e snapshots;
- importação/indexação de PDF e RAG;
- Gemini nativo para Mestre e imagem de cena;
- TTS PT-BR somente da narração visível;
- acessibilidade e preferências locais;
- biblioteca visual V3.8 congelada com 369 assets validados.

## Validação

Estado reproduzível final: **742/742 testes PASS + 6/6 stress PASS**. Catálogo inicial: **60 itens pessoais + 25 veículos/naves mecanicamente completos**. RAG: **54/54 TESTADO**; Motor Barbara: **56 módulos**. Veja `FINAL_1.0.0_VALIDATION.md`, `RETOMADA_ATUAL.md` e `validation/LATEST_SOURCE_VALIDATION.txt`. O ambiente de geração não contém Android SDK/emulador/aparelho, portanto compilação/instalação física Android precisa ser repetida no Android Studio. Nenhum APK/AAB foi gerado ou incluído.

### Integridade do Gradle Wrapper
O pacote final inclui `gradle/wrapper/gradle-wrapper.jar`, `gradle-wrapper.properties`, `gradlew` e `gradlew.bat`, além dos arquivos Gradle Kotlin DSL do projeto.
