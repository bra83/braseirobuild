# STAR WARS — RETOMADA CANÔNICA ÚNICA

> **AUTORIDADE DE RETOMADA — NÃO REGREDIR**
> Este cabeçalho prevalece sobre qualquer handoff, relatório FINAL, ZIP ou checkpoint mais antigo.
> Nunca diminuir contagens, remover blocos promovidos ou restaurar baseline antiga sobre a árvore atual.

## PONTEIRO ATUAL — 2026-09-14 — BLOCO 37 PROMOVIDO / FONTE FINAL PRONTA

- Projeto: **STAR WARS — EDGE OF THE GALAXY**.
- Visual: **R46 415×915 congelada**. Não redesenhar.
- Motor compartilhado: campanha **EOTE / AOR / MIXED**; EotE continua autoridade das mecânicas EotE, e conteúdo AoR fica separado por perfil/proveniência.
- Blocos **30, 31 e 32 preservados integralmente**.
- Bloco 33 preservado: **sandbox de mundo vivo + campanha mista promovido**.
- Bloco 34 preservado: **economia genérica do sandbox promovida** para armas, armaduras, gear e veículos.
- Bloco 35 preservado: **catálogo veicular Core EotE**, com 15 perfis ativos mecanicamente completos.
- Bloco 36 promovido: **catálogo veicular EotE ampliado para 25 perfis completos**, usando `Fly Casual` como fonte primária suplementar.
- Bloco 37 promovido: **Duty/Contribution AoR com proveniência recuperada e guardada**, mais catálogo pessoal inicial fechado em **60 itens** (31 armas + 7 armaduras + 22 gear).
- Regressão integral vigente: **742/742 PASS, 0 falhas**.
- Stress canônico: **6/6 PASS**, incluindo suítes de 33 sessões.
- Sandbox inicial: **6 facções / 36 NPCs persistentes / 12 locais / 6 clocks / 12 oportunidades**, além de mercados e rotas.
- Duty + Obligation funcionam simultaneamente em `MIXED`; Contribution possui milestone estruturado. Duty de criação e estrutura Duty/Contribution têm autoridade AoR recuperada; comportamento de runtime sem página primária preservada permanece explicitamente política local testada.
- Facções/PNPCs/planos/eventos/consequências/aftermaths continuam persistentes; Mestre recebe fatos estruturados separados da narrativa.
- Aventuras publicadas são **conteúdo opcional**, nunca trilho obrigatório.
- Android físico continua `BLOCKED_EXTERNAL` apenas por ausência de SDK/ADB/sdkmanager neste host.
- Entrega continua sendo **um único ZIP final do projeto Android Studio, sem APK/AAB intermediário**.

### Próxima ação exata

**Nenhuma expansão adicional antes da entrega.** A fonte R37 está pronta para o ZIP Android Studio final. O único gate restante é build/instalação em Android com SDK/ADB externo.

## REGRA DE RECUPERAÇÃO EM CHAT NOVO

Se o estado encontrado não contiver **BLOCO 37 + 742/742 + MIXED + sandbox 6/36/12 + economia genérica + 25 veículos EotE + 60 itens pessoais + RAG 54**, ele é histórico e não pode ser usado como baseline.

---

# STAR WARS — EDGE OF THE GALAXY — RETOMADA ATUAL

Atualizado em 2026-09-11.

## Baseline vigente

- Baseline física de recuperação: `STAR_WARS_EDGE_OF_THE_GALAXY_ANDROID_STUDIO_FINAL_1.0.0_CORRIGIDO.zip`.
- **Fonte canônica atual:** baseline CORRIGIDO + Blocos 2–8 deste workspace. Não reextrair o ZIP por cima do código atual: isso reintroduz regressões AoR já corrigidas.
- SHA-256 verificado nesta retomada: `38bb5e5f6e1ae19d63033bd69a328506cd81ebc90d1b43d2d12700aea99113a2`.
- Não usar R47 como baseline: ele permanece apenas como histórico/fallback.
- Não redesenhar a shell R46 aprovada e não criar R48/R49 sem uma nova necessidade funcional comprovada.

## Bloco executado nesta retomada

1. ZIP CORRIGIDO extraído e hash conferido contra o registro consolidado.
2. Suíte completa repetida no código desta revisão: **473/473 PASS, 0 falhas**.
3. Stress explícito repetido: **4/4 PASS**, cada suíte cobrindo 33 sessões simuladas no subsistema correspondente.
4. Validação estática repetida: **51 JS/ESM**, **25 JSON**, **2 XML**, todos válidos; scan de segredo com **0 hits**; **0 APK/AAB** no pacote-fonte.
5. Gradle Wrapper conferido: `gradle-wrapper.jar` presente e contendo `org/gradle/wrapper/GradleWrapperMain.class`.
6. Gate Android tentado novamente. O host atual não possui `ANDROID_HOME`/`ANDROID_SDK_ROOT`, `adb` ou `sdkmanager`, e não consegue resolver `services.gradle.org`; portanto `assemble`, instalação e smoke físico continuam bloqueados externamente.

## Alterações desta retomada

- Nenhuma regra, tela ou comportamento do jogo foi alterado, pois os testes não reproduziram defeito funcional nesta revisão.
- Adicionado `tools/verify-final-source.mjs`, verificador reproduzível dos gates executáveis sem Android SDK.
- Adicionado/atualizado `validation/LATEST_SOURCE_VALIDATION.txt` com a evidência da última execução.
- Este arquivo (`RETOMADA_ATUAL.md`) passa a ser o primeiro registro de continuidade antes de nova alteração.

## Estado atual

`SOURCE_GREEN / REAL_ANDROID_BUILD_DEVICE_GATE_PENDING`

O código desta revisão está verde nos gates executáveis. O próximo bloco comprovado continua sendo **homologação Android real**: Gradle/AGP com acesso às dependências, SDK Android 36, build do app, instalação em aparelho/emulador e smoke 415×915. Um bloqueio do ambiente não deve ser reinterpretado como falta de implementação.

## Regra para a próxima retomada

Antes de editar código, rodar:

```bash
node tools/verify-final-source.mjs
```

Se os gates de fonte continuarem verdes, não reabrir mecânicas antigas. Se houver Android SDK/Gradle disponível, executar `./gradlew :app:assembleDebug`, instalar o APK gerado e validar o fluxo real. Registrar separadamente teste automatizado e teste físico Android.

## Tentativa adicional de smoke visual neste host

Foi tentado smoke headless em Chromium 415×915 sobre `r46-shell.html`. O binário Chromium deste ambiente não completa nem `about:blank` e fica bloqueado em dependências/DBus do host até timeout; portanto **nenhuma falha da shell foi inferida dessa tentativa**. O smoke visual/browser permanece sem evidência nova neste host e não substitui a homologação Android real.

## Bloco automático 2 — robustez do build bootstrap (2026-09-11)

O próximo gate comprovado continuava sendo a homologação Android. Como SDK/ADB e rede externa seguem indisponíveis neste host, foi avançado o máximo executável **sem alterar regras, conteúdo ou shell R46**:

1. O `gradle-wrapper.jar` customizado foi exercitado offline com uma distribuição Gradle mínima simulada.
   - distribuição com SHA-256 correto: executou e repassou argumentos corretamente;
   - distribuição com SHA-256 incorreto: recusada com `Gradle SHA-256 mismatch`.
2. `gradlew` e `gradlew.bat` foram corrigidos para delegarem ao mesmo `gradle-wrapper.jar` e a `gradle-wrapper.properties`, removendo duas implementações paralelas de download/checksum (curl/wget no Unix e PowerShell no Windows). Isso reduz divergência entre plataformas e torna URL/SHA do wrapper a única fonte de verdade.
3. Adicionado `tools/JavaSyntaxCheck.java`, que usa o parser do JDK para validar sintaxe Java sem exigir Android SDK ou resolver tipos Android.
4. `tools/verify-final-source.mjs` passou a executar também o gate de sintaxe Java.
5. Adicionado `tests/gradle-bootstrap-final.test.mjs` com 3 testes de bootstrap/checksum/launchers e fixture offline mínima `tests/fixtures/gradle-8.13-bin.zip`.
6. Suíte completa após o patch: **476/476 PASS, 0 falhas**.
7. Stress explícito: **4/4 PASS**, mantendo 33 sessões simuladas por suíte/subsistema.
8. Verificação reproduzível atual: **51 JS/ESM**, **26 JSON**, **5 Java (parse)**, **2 XML**, secrets **0**, APK/AAB **0** — todos PASS.
9. Tentativa real `./gradlew --version` com cache de teste removido: launcher chegou ao downloader do wrapper e falhou apenas por `java.net.UnknownHostException: services.gradle.org`.

### Estado após o bloco 2

`SOURCE_GREEN / BUILD_BOOTSTRAP_GREEN / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`

Não há nova pendência funcional comprovada. O próximo trabalho legítimo continua sendo obter um host com rede para Gradle/AGP + Android SDK 36, executar `./gradlew :app:assembleDebug`, instalar em aparelho/emulador e fazer smoke físico 415×915. Não reabrir mecânicas ou redesenhar a shell por causa desse bloqueio de infraestrutura.

## Bloco automático 3 — gate compilatório Java e retomada robusta (2026-09-11)

O Bloco 2 foi preservado. Este bloco avançou sobre ele e encontrou uma falha de compilação real que o parser sintático anterior não detectava:

1. `javac -XDrawDiagnostics` sobre os 5 arquivos Java revelou `compiler.err.already.defined` em `MainActivity.java`: havia **duas declarações de `public void onBackPressed()`**.
2. Foi removida somente a declaração duplicada no fim do arquivo. Permaneceu a implementação anterior, mais completa, com `@SuppressWarnings("deprecation")`, `webView.goBack()` e fallback `super.onBackPressed()`.
3. O teste existente `FINAL: Android host disables WebView debugging and supports system back navigation` passou a exigir exatamente **uma** ocorrência de `public void onBackPressed()`, protegendo a correção sem adicionar um redesenho ou mudar regra de jogo.
4. O gate Java foi substituído por `tools/java-syntax-gate.mjs`, que usa o diagnóstico real do `javac` e reprova erros sintáticos/declaratórios, incluindo métodos duplicados, enquanto tolera somente erros de resolução esperados quando Android SDK/dependências não estão no classpath.
5. Os launchers `gradlew` e `gradlew.bat` continuam unificados no `gradle-wrapper.jar`; o teste novo `tests/gradle-wrapper-bootstrap.test.mjs` cria uma distribuição Gradle local efêmera, prova execução/working-directory/argumentos e prova rejeição de SHA inválido, sem depender de rede.
6. `tools/verify-final-source.mjs` foi endurecido: inclui o gate Java real, registra os quatro testes de stress como parte da suíte completa e paraleliza `node --check` para evitar falso timeout do host.
7. Suíte após a correção: **476/476 PASS, 0 falhas**.
8. Stress isolado adicional: **4/4 PASS**; os mesmos quatro arquivos também estão incluídos na suíte completa.
9. Verificação consolidada: **51 JS/ESM PASS, 5 Java PASS no gate sintático/declaratório, 26 JSON PASS, 2 XML PASS, secrets 0, APK/AAB 0**.
10. Tentativa real `./gradlew --version` com `GRADLE_USER_HOME` limpo chega ao `GradleWrapperMain` e falha apenas em `java.net.UnknownHostException: services.gradle.org`. O host continua sem `ANDROID_HOME`/`ANDROID_SDK_ROOT`, `adb` e `sdkmanager`.

### Estado após o Bloco 3

`SOURCE_GREEN / BUILD_COMPILE_BLOCKER_FIXED / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`

O próximo trabalho legítimo continua sendo o build Android real assim que houver rede/toolchain. **Não reabrir mecânicas nem redesenhar a shell R46.** Se uma próxima retomada não tiver Android SDK/rede, deve primeiro executar `node tools/verify-final-source.mjs`; se continuar verde, não inventar nova pendência funcional.


## Bloco automático 4 — recuperação do runtime Edge of the Empire (2026-09-11)

A auditoria do runtime revelou que o ZIP CORRIGIDO ainda carregava mecânicas de **Age of Rebellion** apesar de existir evidência posterior de uma conversão EotE verde. A revisão mais nova foi recuperada e promovida sem redesenhar a shell R46.

1. `rulesProfile` ativo promovido para `EOTE_CORE`; estado para schema 14.
2. Criação canônica EotE recuperada: **8 espécies, 6 carreiras e 18 especializações**; Obligation ativa; Duty/Contribution ficam apenas em migração/guards de legado.
3. Grupo EotE (`state.group`) recuperado; corrigido bug real no reducer de `GROUP_UPDATED`, que antes não persistia a mutação emitida pelo controller.
4. Reconstruídas as **18 árvores Core × 20 posições = 360 nós**, com custos 5/10/15/20/25, 72 entradas e conectividade integral pelas arestas estruturadas.
5. Talentos ativos migrados para IDs EotE (`TRICK`, `RAPREC`, `SURG`, `FINETUN`, `SOLREP`, `MASSTAR`, `COM`, Full Throttle etc.). `Controlled Fire` fica bloqueado como legado AoR.
6. Stimpacks corrigidos para **5→4→3→2→1** por uso no mesmo dia; `Stim Application` permanece mecânica separada.
7. Gerador do Motor Barbara corrigido para não deixar `import` ESM dentro do wrapper CJS; bundle canônico regenerado com **44 módulos**.

## Bloco automático 5 — RAG EotE e falha fechada (2026-09-11)

Foi removida outra regressão funcional: o RAG ativo ainda indexava 78 entradas AoR/VTT e podia ensinar Duty/Contribution/raridade AoR ao Mestre Barbara.

1. `rules_matrix.json` reduzido para **24 entradas EotE/VTT verificadas**, sem IDs `SW-AOR-*`.
2. Corpus e manifesto RAG regenerados; `rulesCorpus.mjs` sincronizado com a matriz.
3. Obligation, estrutura 8/6/18, árvores 18×20 e talentos EotE comprovados permanecem recuperáveis pelo RAG.
4. Lacunas sem fonte EotE Core disponível no corpus passam a **falhar fechado**, em vez de reutilizar AoR: dado/poderes da Força, compra de especialização adicional e raridade/availability antiga.
5. PDFs importados pelo usuário continuam podendo fornecer evidência adicional pelo fluxo normal de biblioteca/RAG.
6. Resultado após a limpeza: **488/488 PASS** e **6/6 stress PASS**.

## Bloco automático 6 — fixtures EotE e fronteira de referência cruzada (2026-09-11)

Foi removida a última dependência de personagem AoR ainda incluída no bundle e criada uma fronteira explícita para conteúdo cruzado preservado.

1. `starterPresets.mjs` deixou de declarar seis personagens da Caja de Inicio como pregens oficiais. Os mesmos IDs (`zal`, `vendri`, `tendaar`, `jin-rio`, `cael`, `arkhan`) permanecem somente como **fixtures determinísticas locais de teste** para não destruir a cobertura acumulada.
2. Fixtures agora usam `source.type = eote_test_fixture`, `official:false`, `authority:NONE`, `creation.rulesProfile:EOTE_CORE`; não possuem Duty/Contribution nem alegam fonte oficial.
3. O bundle canônico não contém mais `starter_pregen` nem títulos de pregen AoR para esses seis IDs.
4. Dados cruzados ainda úteis de adversários, veículos, armas, blindagens e equipamento mantêm a proveniência AoR real, mas agora são marcados explicitamente `authority:CROSS_LINE_REFERENCE`, `rulesProfile:AOR_REFERENCE_ONLY`, `activeRulesAuthority:false`.
5. Esses dados **não entram no RAG mecânico verificado** e não podem ser confundidos com autoridade EotE; não foram relabelados falsamente nem apagados sem substituto comprovado.
6. `tools/verify-final-source.mjs` passou a executar os **6** testes de stress conhecidos, não apenas quatro.
7. Promoção atual: **491/491 PASS, 0 falhas**; stress explícito **6/6 PASS**.
8. Verificador consolidado: **54 JS/ESM**, **5 Java**, **28 JSON**, **2 XML**, secrets **0**, APK/AAB **0**, Gradle Wrapper PASS.

### Estado canônico após o Bloco 6

`SOURCE_GREEN / EOTE_CORE_RUNTIME_GREEN / RAG_EOTE_GREEN / CROSS_LINE_REFERENCES_GUARDED / BUILD_COMPILE_BLOCKER_FIXED / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`

O único gate que continua sem execução física é Android: este host segue sem SDK/ADB/sdkmanager e sem acesso necessário para resolver a distribuição/dependências Gradle. Isso **não autoriza** reabrir mecânicas EotE, reintroduzir AoR ou redesenhar a shell R46.

### Próxima retomada obrigatória

1. Tratar este workspace/patch Blocos 2–8 como autoridade sobre o ZIP CORRIGIDO.
2. Rodar `node tools/verify-final-source.mjs` antes de qualquer edição.
3. Se verde, só mexer em novo defeito reproduzível.
4. Com Android SDK/rede disponíveis: `./gradlew :app:assembleDebug`, instalar em aparelho/emulador e fazer smoke físico 415×915.

## Bloco automático 7 — harness web auxiliar EotE + reconstrução limpa (2026-09-11)

A shell R46 Android já estava em EotE, mas a rota web auxiliar `index.html` + `js/ui/app.mjs`, usada como harness por várias suítes, ainda expunha criação/grupo AoR. Esse resíduo executável foi removido sem redesenhar a shell aprovada.

1. Criador auxiliar migrado de `AOR_SPECIES`/`AOR_CAREERS`/Duty para `EOTE_SPECIES`/`EOTE_CAREERS`/Obligation.
2. Benefícios de Obligation corrigidos para **aumentar** Obligation (+5/+10), incluindo PE/créditos; preview usa `eoteCreationPreview`.
3. Adicionada escolha fisiológica do Gand (com pulmões / sem pulmões) no harness auxiliar, sem alterar a shell R46.
4. Painel de grupo auxiliar migrou de Dever/Contribution para Obligation e `groupSummary()`/`addGroupObligation()`/`removeGroupObligation()`.
5. Removidas alegações visíveis de “Caixa de Início/personagem verificado”; os seis IDs antigos aparecem apenas como fixtures locais EotE não oficiais, com rótulos coerentes às especializações atuais.
6. Adicionados guards permanentes: `legacy-ui-eote-guard.test.mjs` impede reativação AoR e `legacy-ui-dom-contract.test.mjs` garante que todo `$('id')` literal do harness existe no HTML.
7. Regressão completa após o patch: **493/493 PASS, 0 falhas**. Stress explícito: **6/6 PASS**.
8. Verificador consolidado: **54 JS/ESM**, **5 Java**, **28 JSON**, **2 XML**, secrets **0**, APK/AAB **0**, Gradle Wrapper PASS; Android físico segue `BLOCKED_EXTERNAL`.
9. Prova de retomada limpa: o ZIP CORRIGIDO foi extraído do zero e recebeu apenas o delta atual; comparação byte a byte da árvore relevante resultou em **0 divergências, 0 extras, 0 deleções**. Delta atual: **65 arquivos**.
10. Na cópia reconstruída, os guards EotE críticos passaram **15/15**.

### Estado canônico após o Bloco 7

`SOURCE_GREEN / EOTE_CORE_RUNTIME_GREEN / RAG_EOTE_GREEN / LEGACY_WEB_HARNESS_EOTE_GREEN / CROSS_LINE_REFERENCES_GUARDED / BUILD_COMPILE_BLOCKER_FIXED / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`

O próximo avanço funcional comprovável continua sendo o build/instalação Android real quando houver SDK/rede. Até lá, não reintroduzir AoR, não reextrair a baseline sobre este delta e não redesenhar a shell R46.



## Bloco automático 8 — contrato shell R46 ↔ Motor Barbara (2026-09-11)

O contrato entre a shell R46 aprovada e o Motor Barbara foi transformado em gate permanente, sem alteração visual ou de regra.

1. `BraseiroGameBridgeContract` declara **24 métodos** e `BraseiroUiBridge` implementa exatamente os mesmos **24 métodos públicos**; nenhum faltante e nenhum extra.
2. Todos os símbolos importados de `gameBridgeClient.ts` por `VTTApp.tsx`, `Templates.tsx` e `imageLibraryBridgeClient.ts` existem de fato entre os exports do cliente.
3. A superfície pública da ponte não expõe métodos Duty/Contribution/AoR; criação EotE (`creationCatalog`, `creationPreview`, `createCustomCharacter`) permanece disponível.
4. Novo guard permanente: `tests/r46-bridge-contract.test.mjs` (**3/3 PASS**).
5. Regressão completa após o guard: **496/496 PASS, 0 falhas**. Stress explícito: **6/6 PASS**.
6. Verificador consolidado: **54 JS/ESM**, **5 Java**, **29 JSON**, **2 XML**, secrets **0**, APK/AAB **0**, Gradle Wrapper PASS.
7. Reconstrução limpa baseline CORRIGIDO + delta: **66 arquivos**, **0 divergências**, **0 deleções**; guards críticos reconstruídos **8/8 PASS**.
8. Android físico continua `BLOCKED_EXTERNAL` por ausência de SDK/ADB/sdkmanager neste host.

### Estado canônico após o Bloco 8

`SOURCE_GREEN / EOTE_CORE_RUNTIME_GREEN / RAG_EOTE_GREEN / LEGACY_WEB_HARNESS_EOTE_GREEN / R46_BRIDGE_CONTRACT_GREEN / CROSS_LINE_REFERENCES_GUARDED / BUILD_COMPILE_BLOCKER_FIXED / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`

A próxima retomada deve preservar este contrato e não reabrir mecânicas ou layout se o gate continuar verde.


## Bloco automático 9 — bridges Android ↔ JavaScript (2026-09-11)

1. Cinco bridges nativos registrados no `MainActivity`: Library, Gemini, Images, TTS e Files.
2. Contratos JS→Java travados por `tests/native-bridge-contract.test.mjs`: métodos consumidos pela shell existem nos hosts Java.
3. Nenhuma mudança visual ou mecânica; apenas fechamento de integração Android/WebView.

## Bloco automático 10 — documentação de entrada alinhada à linha EotE (2026-09-11)

1. `README.md`, `LEIA_PRIMEIRO.md` e `FINAL_1.0.0_VALIDATION.md` deixaram de anunciar o estado antigo 473/AoR como atual.
2. Documentação agora aponta `EOTE_CORE`, Obligation e `RETOMADA_ATUAL.md` como continuidade obrigatória.
3. `tests/documentation-current-state.test.mjs` impede regressão documental.

## Bloco automático 11 — callbacks Java → JavaScript (2026-09-11)

1. Callbacks Library, Images, Gemini e Master foram validados nos dois lados do WebView.
2. Envelopes `payload`/`data`, `requestId`, `proposal` e `model` são consumidos com os mesmos nomes emitidos pelos hosts Java.
3. Guard permanente: `tests/native-callback-contract.test.mjs`.

## Bloco automático 12 — fechamento dos assets do runtime R46 (2026-09-11)

1. Todo `script src`, `link href` e `url(...)` local carregado por `r46-shell.html` existe fisicamente.
2. Ordem de boot validada: vendor React → Motor Barbara → bootstrap → shell R46 → runtime final.
3. Guard permanente: `tests/r46-runtime-asset-closure.test.mjs`.

## Bloco automático 13 — projeção EotE da shell R46 (2026-09-11)

1. Corrigido defeito executável: projeção R46 ainda exigia schema 13 e `state.rebelGroup`; agora exige schema 14 e `state.group`.
2. A projeção da ficha deixou de ler `duties` e passa a mostrar **Obligation** (valor + tipo) de personagens EotE reais.
3. Teste dinâmico executa o módulo `r21Projection` extraído do bundle contra estado/character canônicos.
4. Guard: `tests/r46-state-projection-eote.test.mjs`.

## Bloco automático 14 — atualização ao vivo do estado na mesma WebView (2026-09-11)

Foi corrigido outro defeito funcional real: a shell R46 escutava `braseiro:r21-state-changed`, porém o repositório que salva o estado nunca emitia esse evento; o evento nativo `storage` não é disparado na mesma janela que executa `localStorage.setItem`.

1. `LocalStorageRepository.save()` e `.clear()` agora emitem `braseiro:r21-state-changed` após persistir/remover o estado.
2. O evento inclui `detail.key` e `detail.operation` (`save`/`clear`) e falha de forma segura fora do browser.
3. Uma mutação real via `GameController` foi testada e dispara o mesmo evento que a shell R46 já escuta.
4. Motor Barbara regenerado: **44 módulos**.
5. Regressão atual: **519/519 PASS, 0 falhas**. Stress canônico: **6/6 PASS**.
6. Verificador: JS/ESM 54, Java 5, JSON 25, XML 2, secrets 0, APK/AAB 0, Gradle Wrapper PASS.
7. Único gate restante continua externo: Android SDK/ADB/sdkmanager ausentes neste host.

### Estado canônico após o Bloco 14

`SOURCE_GREEN / EOTE_CORE_RUNTIME_GREEN / RAG_EOTE_GREEN / R46_PROJECTION_EOTE_GREEN / R46_LIVE_REFRESH_GREEN / NATIVE_BRIDGES_GREEN / CROSS_LINE_REFERENCES_GUARDED / BUILD_COMPILE_BLOCKER_FIXED / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`

## Bloco automático 15 — backup/snapshot + refresh na mesma WebView (2026-09-11)

Foi fechado o ciclo de persistência que depende diretamente do evento corrigido no Bloco 14, sem alterar runtime nem layout:

1. Novo guard dinâmico `tests/backup-restore-live-refresh-r15.test.mjs` executa um estado EotE real em memória.
2. Round-trip comprovado: campanha A → exporta backup → salva campanha B → importa backup A. O estado A volta a ser persistido e `braseiro:r21-state-changed` é emitido com `operation: save`.
3. Antes da importação, o estado B é preservado como snapshot; restaurar esse snapshot persiste B novamente e emite novo refresh pela mesma rota.
4. `LocalStorageRepository.clear()` também foi exercitado e emite `operation: clear`.
5. O guard confirma estaticamente que `BraseiroUiBridge.importCampaignBackup()` e `restoreSnapshot()` continuam passando por `repository.save()`, impedindo bypass do refresh da shell.
6. Resultado focado: **3/3 PASS**. Nenhum defeito de runtime foi reproduzido, portanto nenhuma regra/tela/código de produção foi alterado neste bloco.
7. A última regressão completa promovida permanece a do Bloco 14: **519/519 PASS + 6/6 stress PASS**; este bloco apenas acrescenta cobertura focada até que a suíte completa seja reconstruída/executada novamente no próximo gate.

### Estado após o Bloco 15

`SOURCE_GREEN / EOTE_CORE_RUNTIME_GREEN / RAG_EOTE_GREEN / R46_PROJECTION_EOTE_GREEN / R46_LIVE_REFRESH_GREEN / BACKUP_SNAPSHOT_REFRESH_GUARDED / NATIVE_BRIDGES_GREEN / CROSS_LINE_REFERENCES_GUARDED / BUILD_COMPILE_BLOCKER_FIXED / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`

Próximo trabalho sem decisão do usuário: continuar somente por defeitos reproduzíveis; priorizar o ciclo de importação de arquivos/backup no host Android e, quando houver SDK/rede, executar build/instalação/smoke físico 415×915.

## Bloco automático 16 — seletor JSON Android + limite de importação (2026-09-11)

Foi auditada a fronteira real entre `<input type="file">` da shell R46 e o `WebChromeClient` Android.

1. A R46 possui exatamente dois inputs de arquivo, ambos `accept="application/json,.json"`: importação de ficha e importação de backup.
2. O host Android usa `ACTION_OPEN_DOCUMENT` + `CATEGORY_OPENABLE`, MIME principal `application/json` e aceita também `text/json`/`text/plain`; `onActivityResult()` devolve o URI ao WebView via `FileChooserParams.parseResult`.
3. Guard permanente `tests/android-json-file-chooser-contract-r16.test.mjs` protege esse contrato e força revisão do host se um novo tipo de upload for adicionado à shell.
4. Corrigido defeito de robustez: o exportador nativo já limitava JSON a 16 MB, mas os imports executavam `file.text()` sem teto. `VTTApp.tsx` e o bundle R46 agora rejeitam ficha/backup acima de **16 MB antes da leitura integral**.
6. Guard permanente `tests/json-import-size-guard-r16.test.mjs` garante paridade fonte/bundle e que a checagem ocorre antes de `file.text()`.
6. Validação focada após o patch: **6/6 PASS**; `r46-shell.bundle.js` também passa `node --check`.
7. A árvore completa foi reconstruída e a regressão integral repetida: **530/530 PASS, 0 falhas**.
8. Stress canônico repetido isoladamente: **6/6 PASS**, incluindo as suítes de 33 sessões.
9. `tools/verify-final-source.mjs` foi endurecido contra hangs do runner: a suíte usa o reporter TAP gravado diretamente em arquivo temporário (`--test-reporter-destination`) com timeout do processo, evitando pipes que podiam deadlockar neste host; o CLI também encerra explicitamente após gravar o relatório. Guards `verifier-async-suite-r16.test.mjs` e `verifier-process-exit-r16.test.mjs` protegem essas correções.
10. Verificador consolidado: **node tests 530/530**, JS/ESM **54**, Java **5**, JSON **25**, XML **2**, secrets **0**, APK/AAB **0**, Gradle Wrapper PASS.
11. Tentativa externa `./gradlew --version` repetida: continua bloqueada por DNS de `services.gradle.org`; `ANDROID_HOME`/`ANDROID_SDK_ROOT` vazios e sem `adb`/`sdkmanager`.

### Estado canônico após o Bloco 16 — PROMOVIDO

`SOURCE_GREEN / EOTE_CORE_RUNTIME_GREEN / RAG_EOTE_GREEN / R46_PROJECTION_EOTE_GREEN / R46_LIVE_REFRESH_GREEN / R46_JSON_IMPORT_GUARDED / BACKUP_SNAPSHOT_REFRESH_GUARDED / NATIVE_BRIDGES_GREEN / CROSS_LINE_REFERENCES_GUARDED / BUILD_COMPILE_BLOCKER_FIXED / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`

Próximo trabalho legítimo sem decisão do usuário: somente novo defeito reproduzível ou, quando o host oferecer SDK/rede, build `:app:assembleDebug`, instalação e smoke físico 415×915. Não reabrir mecânicas EotE nem redesenhar a shell R46.


## Bloco automático 17 — compatibilidade atual da Gemini Interactions API + retomada limpa (2026-09-11)

Foi auditado o contrato REST atual usado pelo host Gemini sem alterar a shell R46 nem as regras do jogo.

1. Os modelos ativos continuam válidos: Mestre `gemini-3.8-flash` e imagem `gemini-3.1-flash-image`, usando `POST /v1beta/interactions`.
2. Corrigido defeito funcional no `masterProposalSchema()`: o host enviava `maxLength` em strings, keyword que não pertence ao subconjunto atual suportado de JSON Schema da Interactions API. Esses `maxLength` foram removidos do schema remoto e substituídos por `description` orientativa.
3. Os limites não foram relaxados: `validateMasterProposal()` continua impondo localmente 5000 caracteres de narração, 500 na pergunta, 180 por ação, 120 no título, 160 no ID de local e máximo de 6 ações.
4. Novo guard `tests/gemini-interactions-schema-r17.test.mjs` prova a ausência de `maxLength` no schema remoto e a manutenção dos limites locais.
5. Corrigido também o verificador de retomada limpa: `tools/verify-final-source.mjs` agora cria `validation/` antes de abrir reporter/relatório. Sem isso uma reconstrução legítima sem a pasta de evidências terminava em `ENOENT` apesar da suíte verde.
6. Novo guard `tests/verifier-validation-dir-r17.test.mjs` protege a criação antecipada do diretório e o uso de um único `validationDir`.
7. Regressão integral: **535/535 PASS, 0 falhas**.
8. Stress canônico: **6/6 PASS**.
9. Verificador executado com `validation/` removida de propósito: recriou o diretório, registrou **535/535**, JS/ESM 54, Java 5, JSON 25, XML 2, secrets 0, APK/AAB 0 e Gradle Wrapper PASS.
10. O único gate externo permanece Android físico/Gradle: sem SDK/ADB/sdkmanager e sem resolução DNS de `services.gradle.org` neste host.

### Estado canônico após o Bloco 17 — PROMOVIDO

`SOURCE_GREEN / EOTE_CORE_RUNTIME_GREEN / RAG_EOTE_GREEN / R46_PROJECTION_EOTE_GREEN / R46_LIVE_REFRESH_GREEN / R46_JSON_IMPORT_GUARDED / GEMINI_INTERACTIONS_SCHEMA_GREEN / BACKUP_SNAPSHOT_REFRESH_GUARDED / NATIVE_BRIDGES_GREEN / CROSS_LINE_REFERENCES_GUARDED / CLEAN_RECOVERY_VERIFIER_GREEN / BUILD_COMPILE_BLOCKER_FIXED / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`

Próximo trabalho legítimo sem decisão do usuário: somente novo defeito reproduzível ou, quando o host oferecer SDK/rede, build `:app:assembleDebug`, instalação e smoke físico 415×915.


## Bloco automático 18 — seletor PDF Android robusto (2026-09-11)

A auditoria continuou sobre o checkpoint já promovido do Bloco 17, sem reabrir shell ou mecânicas.

1. Encontrado defeito Android real em `LibraryBridge.pickPdf()`: o `try/catch` externo não capturava exceções de `startActivityForResult()` disparadas dentro da lambda de `runOnUiThread`, podendo derrubar a Activity quando nenhum seletor PDF compatível estivesse disponível.
2. O picker PDF agora captura a exceção **dentro da própria UI thread** e emite evento `erro` da Biblioteca, sem crash.
3. Removida escrita duplicada de `reindexRequestedAt` em `reindexDocument()`.
4. Guard permanente `tests/pdf-picker-ui-thread-r17.test.mjs` protege o catch da UI thread e a escrita única do timestamp.
5. O verificador mais novo do Bloco 17 foi preservado integralmente; ele já espera o resumo TAP completo e reprova evidência incompleta, portanto nenhum fallback mais fraco foi promovido.
6. Regressão integral combinando Bloco 17 + Bloco 18: **537/537 PASS, 0 falhas**.
7. Stress canônico: **6/6 PASS**, embutido na suíte completa.
8. Verificador consolidado: node tests **537/537**, JS/ESM **54**, Java **5**, JSON **27**, XML **2**, secrets **0**, APK/AAB **0**, Gradle Wrapper PASS.
9. O único gate externo permanece Android físico/Gradle: sem SDK/ADB/sdkmanager e sem resolução DNS de `services.gradle.org`.

### Estado canônico após o Bloco 18 — PROMOVIDO

`SOURCE_GREEN / EOTE_CORE_RUNTIME_GREEN / RAG_EOTE_GREEN / R46_PROJECTION_EOTE_GREEN / R46_LIVE_REFRESH_GREEN / R46_JSON_IMPORT_GUARDED / GEMINI_INTERACTIONS_SCHEMA_GREEN / PDF_PICKER_ANDROID_GUARDED / BACKUP_SNAPSHOT_REFRESH_GUARDED / NATIVE_BRIDGES_GREEN / CROSS_LINE_REFERENCES_GUARDED / CLEAN_RECOVERY_VERIFIER_GREEN / BUILD_COMPILE_BLOCKER_FIXED / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`

Próximo trabalho legítimo sem decisão do usuário: somente novo defeito reproduzível ou, quando o host oferecer SDK/rede, build `:app:assembleDebug`, instalação e smoke físico 415×915.


## Bloco automático 19 — seletor de imagem de cena Android robusto (2026-09-11)

A auditoria prosseguiu pelos launchers Android após o fechamento do seletor PDF.

1. Encontrado o mesmo defeito assíncrono em `GeminiBridge.pickSceneImage()`: o `catch` externo não capturava exceções de `startActivityForResult()` executadas dentro de `runOnUiThread`.
2. O seletor de imagem agora protege `startActivityForResult()` **dentro da UI thread**.
3. Em falha, `pendingImportSceneKey` é limpo e `image_error` é enviado à shell, evitando crash da Activity e estado pendente órfão.
4. Guard permanente `tests/gemini-image-picker-ui-thread-r19.test.mjs`: **2/2 PASS**.
5. Regressão integral: **539/539 PASS, 0 falhas**.
6. Stress canônico: **6/6 PASS**, embutido na suíte completa.
7. Verificador consolidado: node tests **539/539**, JS/ESM **54**, Java **5**, JSON **28**, XML **2**, secrets **0**, APK/AAB **0**, Gradle Wrapper PASS.
8. O único gate externo permanece Android físico/Gradle: sem SDK/ADB/sdkmanager e sem resolução DNS de `services.gradle.org`.

### Estado canônico após o Bloco 19 — PROMOVIDO

`SOURCE_GREEN / EOTE_CORE_RUNTIME_GREEN / RAG_EOTE_GREEN / R46_PROJECTION_EOTE_GREEN / R46_LIVE_REFRESH_GREEN / R46_JSON_IMPORT_GUARDED / GEMINI_INTERACTIONS_SCHEMA_GREEN / PDF_PICKER_ANDROID_GUARDED / GEMINI_IMAGE_PICKER_ANDROID_GUARDED / BACKUP_SNAPSHOT_REFRESH_GUARDED / NATIVE_BRIDGES_GREEN / CROSS_LINE_REFERENCES_GUARDED / CLEAN_RECOVERY_VERIFIER_GREEN / BUILD_COMPILE_BLOCKER_FIXED / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`

Próximo trabalho legítimo sem decisão do usuário: somente novo defeito reproduzível ou, quando o host oferecer SDK/rede, build `:app:assembleDebug`, instalação e smoke físico 415×915.

## Bloco automático 20 — política da Biblioteca preservada durante indexação PDF (2026-09-11)

O pente-fino continuou somente na integração Android da Biblioteca, sem alterar regras EotE, RAG, shell R46 ou layout.

1. Foi reproduzida uma corrida de metadados: `indexPdf()` mantinha um `JSONObject` antigo enquanto indexava em background e podia gravá-lo depois de `setDocumentPolicy()`, sobrescrevendo uma alteração recente de `authorityType`/`enabled` feita pelo usuário.
2. Adicionado `libraryMetadataLock`, compartilhado entre a alteração de política e as gravações do indexador.
3. O indexador agora relê e reaplica `authorityType`, `enabled` e `policyUpdatedAt` do metadado persistido imediatamente antes das gravações de progresso, conclusão e erro, sob o mesmo lock. Assim não existe janela entre reler a política e persistir o estado do índice.
4. `reindexDocument()` também faz seu read-modify-write de metadados sob o mesmo lock, evitando outra atualização concorrente parcial no início da reindexação.
5. `removeDocument()` agora compartilha o lock, confirma que o diretório foi realmente removido e as leituras/gravações de `metadata.json` são serializadas; o indexador recusa recriar metadados se o documento tiver sido removido no meio da indexação.
6. Guard permanente novo: `tests/pdf-policy-index-race-r20.test.mjs`.
7. Regressão focada de integração de arquivos/pickers: **11/11 PASS** (JSON chooser, PDF picker, image picker e nova proteção de política).
8. Gate Java sobre as fontes Android materializadas neste bloco: **PASS** (`files=2`, apenas símbolos Android externos não resolvidos como esperado sem SDK).
9. A última regressão integral promovida permanece a do Bloco 19: **539/539 PASS + 6/6 stress PASS**. Este bloco não altera essa evidência nem a apresenta como rerodada.
10. Gate Android repetido neste host: `ANDROID_HOME`/`ANDROID_SDK_ROOT` vazios, `adb`/`sdkmanager` ausentes e `./gradlew --version` bloqueado por falha de DNS em `services.gradle.org`. Build/instalação/smoke Android real 415×915 continua externamente bloqueado.

### Estado após o Bloco 20

`BLOCK20_FOCUSED_GREEN / PDF_POLICY_INDEX_RACE_GUARDED / BLOCK19_FULL_REGRESSION_539_GREEN / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`

Próxima ação legítima: executar a regressão integral no workspace completo se ele estiver materializado no host; caso contrário, o próximo gate funcional é diretamente `./gradlew :app:assembleDebug`, instalação e smoke 415×915 em ambiente Android real. Não reabrir mecânicas EotE nem redesenhar a shell R46.


### Promoção integral do Bloco 20 — reconstrução limpa (2026-09-11)

Após o foco verde, o ZIP CORRIGIDO foi reextraído do zero e recebeu o delta vigente desta retomada, incluindo os Blocos 18–20.

1. Suíte integral na reconstrução limpa: **542/542 PASS, 0 falhas**.
2. Stress canônico isolado: **6/6 PASS**, cobrindo novamente as seis suítes que incluem cenários de 33 sessões.
3. `tools/verify-final-source.mjs`: **PASS** com node **542/542**, JS/ESM **54**, Java **5**, JSON **25**, XML **2**, secrets **0**, APK/AAB **0** e Gradle Wrapper PASS.
4. A documentação corrente foi atualizada para 542/542; o histórico do Bloco 19 permanece 539/539 como evidência daquela revisão, sem reescrever o passado.
5. O gate Android continua externo: SDK/ADB/sdkmanager ausentes neste host.
6. Nenhuma regra EotE, shell R46 ou comportamento visual foi reaberto nesta promoção.

#### Estado canônico após promoção do Bloco 20

`SOURCE_GREEN / EOTE_CORE_RUNTIME_GREEN / RAG_EOTE_GREEN / R46_PROJECTION_EOTE_GREEN / R46_LIVE_REFRESH_GREEN / R46_JSON_IMPORT_GUARDED / GEMINI_INTERACTIONS_SCHEMA_GREEN / PDF_PICKER_ANDROID_GUARDED / GEMINI_IMAGE_PICKER_ANDROID_GUARDED / PDF_POLICY_INDEX_RACE_GUARDED / BACKUP_SNAPSHOT_REFRESH_GUARDED / NATIVE_BRIDGES_GREEN / CROSS_LINE_REFERENCES_GUARDED / CLEAN_RECOVERY_VERIFIER_GREEN / BLOCK20_FULL_REGRESSION_542_GREEN / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`

Próxima ação legítima: em ambiente com Android SDK/rede, executar `./gradlew :app:assembleDebug`, instalar em aparelho/emulador e fazer smoke real 415×915. Até surgir defeito reproduzível, não reabrir mecânicas nem redesenhar a R46.


## Bloco automático 21 — clear concorrente do cache de imagens (2026-09-11)

1. Reproduzida corrida: `clearCachedAsset()` podia remover o cache enquanto `fetchAndCache()` ainda baixava; ao terminar, o download antigo recriava imagem/metadata.
2. Cada solicitação recebe uma geração monotônica por `assetId`; nova solicitação ou clear invalida gerações anteriores.
3. Rede e leitura remota ficam fora do lock; somente o commit final de imagem/metadata usa `cacheCommitLock`.
4. `clearCachedAsset()` invalida a geração e remove imagem, metadata e temporário sob o mesmo lock.
5. Downloads invalidados abandonam o commit e não publicam erro tardio após `cleared`.
6. Guard `tests/image-cache-clear-race-r21.test.mjs`: **4/4 PASS**; foco biblioteca/bridges: **27/27 PASS**.
7. Gate Java: PASS. Regressão integral pré-promoção: **546/546 PASS**; stress: **6/6 PASS**.

Verifier consolidado final repetido: **PASS** com node **546/546**, stress embutido **6/6**, JS/ESM **54**, Java **5**, JSON **27**, XML **2**, secrets **0**, APK/AAB **0** e Gradle Wrapper PASS. A tentativa direta `./gradlew --version` segue bloqueada por `UnknownHostException: services.gradle.org`, sem SDK/ADB/sdkmanager neste host.

### Estado canônico após promoção do Bloco 21

`SOURCE_GREEN / EOTE_CORE_RUNTIME_GREEN / RAG_EOTE_GREEN / R46_PROJECTION_EOTE_GREEN / R46_LIVE_REFRESH_GREEN / R46_JSON_IMPORT_GUARDED / GEMINI_INTERACTIONS_SCHEMA_GREEN / PDF_PICKER_ANDROID_GUARDED / GEMINI_IMAGE_PICKER_ANDROID_GUARDED / PDF_POLICY_INDEX_RACE_GUARDED / IMAGE_CACHE_CLEAR_RACE_GUARDED / BACKUP_SNAPSHOT_REFRESH_GUARDED / NATIVE_BRIDGES_GREEN / CROSS_LINE_REFERENCES_GUARDED / CLEAN_RECOVERY_VERIFIER_GREEN / BLOCK21_FULL_REGRESSION_546_GREEN / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`

Próxima ação legítima: build `:app:assembleDebug`, instalação e smoke real 415×915 assim que houver Android SDK + rede. Sem novo defeito reproduzível, não reabrir mecânicas nem layout.


## Bloco automático 22 — clear concorrente da imagem principal de cena (2026-09-11)

1. Reproduzida corrida em `GeminiBridge`: `clearSceneImage()` podia remover a imagem atual enquanto uma geração Gemini ou importação manual já estava em andamento; ao concluir, a operação antiga recriava `current.image/current.json` e publicava `generated/imported` depois de `image_cleared`.
2. Adicionados `sceneImageGeneration` monotônico e `sceneImageCommitLock`.
3. Toda geração de imagem e toda importação bem-sucedida recebem uma geração própria; uma operação mais nova invalida a anterior.
4. `clearSceneImage()` incrementa a geração e remove imagem, metadata e `current.tmp` sob o mesmo lock.
5. Persistência + metadata + evento de sucesso são confirmados apenas se a geração ainda for atual; o evento fica ordenado no mesmo commit curto.
6. Erros tardios de geração/importação invalidadas deixam de chegar à UI.
7. Guard novo `tests/gemini-scene-image-clear-race-r22.test.mjs`: **4/4 PASS**; foco Gemini/bridges: **17/17 PASS**.
8. Regressão integral após ajustar o guard legado para a nova assinatura segura: **550/550 PASS, 0 falhas**.
9. Stress canônico continua **6/6 PASS**; gate Java PASS. Verifier consolidado: node **550/550**, stress embutido **6/6**, JS/ESM **54**, Java **5**, JSON **30**, XML **2**, secrets **0**, APK/AAB **0**, Gradle Wrapper PASS.
10. Gate Android físico continua `BLOCKED_EXTERNAL`: host sem SDK/ADB/sdkmanager e sem resolução de `services.gradle.org`.

### Estado canônico após promoção do Bloco 22

`SOURCE_GREEN / EOTE_CORE_RUNTIME_GREEN / RAG_EOTE_GREEN / R46_PROJECTION_EOTE_GREEN / R46_LIVE_REFRESH_GREEN / R46_JSON_IMPORT_GUARDED / GEMINI_INTERACTIONS_SCHEMA_GREEN / PDF_PICKER_ANDROID_GUARDED / GEMINI_IMAGE_PICKER_ANDROID_GUARDED / GEMINI_SCENE_IMAGE_CLEAR_RACE_GUARDED / PDF_POLICY_INDEX_RACE_GUARDED / IMAGE_CACHE_CLEAR_RACE_GUARDED / BACKUP_SNAPSHOT_REFRESH_GUARDED / NATIVE_BRIDGES_GREEN / CROSS_LINE_REFERENCES_GUARDED / CLEAN_RECOVERY_VERIFIER_GREEN / BLOCK22_FULL_REGRESSION_550_GREEN / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`

Próxima ação legítima: somente novo defeito reproduzível em integração estática ou, quando houver SDK/rede, `./gradlew :app:assembleDebug`, instalação e smoke 415×915. Não reabrir regras EotE nem shell R46.


## Bloco automático 23 — consistência de leitura das imagens nativas (2026-09-11)

1. Reproduzida janela de leitura: `exists()` de imagem/metadata podia passar e `clear/commit` trocar/remover os arquivos antes de `readJson`/`FileInputStream`, produzindo 500 transitório ou status incoerente.
2. `GeminiBridge.openSceneImageResponse()` e o trecho de imagem de `statusJson()` agora usam `sceneImageCommitLock`.
3. `ImageLibraryBridge.openCachedImageResponse()` e `statusJson(assetId)` agora usam `cacheCommitLock`; a validação existente de `assetId` da metadata foi preservada.
4. O lock cobre apenas acesso local curto; rede/download continuam fora do lock.
5. Guard novo `tests/native-image-read-consistency-r23.test.mjs`: **4/4 PASS**; foco de imagem/bridges: **17/17 PASS**.
6. Regressão integral: **554/554 PASS, 0 falhas**.
7. Stress canônico: **6/6 PASS**; gate Java PASS. Verifier consolidado: node **554/554**, stress **6/6**, JS/ESM **54**, Java **5**, JSON **31**, XML **2**, secrets **0**, APK/AAB **0**, Gradle Wrapper PASS.
8. Gate Android permanece `BLOCKED_EXTERNAL` por ausência de SDK/ADB/sdkmanager e DNS externo.

### Estado canônico após promoção do Bloco 23

`SOURCE_GREEN / EOTE_CORE_RUNTIME_GREEN / RAG_EOTE_GREEN / R46_PROJECTION_EOTE_GREEN / R46_LIVE_REFRESH_GREEN / R46_JSON_IMPORT_GUARDED / GEMINI_INTERACTIONS_SCHEMA_GREEN / PDF_PICKER_ANDROID_GUARDED / GEMINI_IMAGE_PICKER_ANDROID_GUARDED / GEMINI_SCENE_IMAGE_CLEAR_RACE_GUARDED / PDF_POLICY_INDEX_RACE_GUARDED / IMAGE_CACHE_CLEAR_RACE_GUARDED / NATIVE_IMAGE_READ_CONSISTENCY_GUARDED / BACKUP_SNAPSHOT_REFRESH_GUARDED / NATIVE_BRIDGES_GREEN / CROSS_LINE_REFERENCES_GUARDED / CLEAN_RECOVERY_VERIFIER_GREEN / BLOCK23_FULL_REGRESSION_554_GREEN / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`


## Bloco automático 24 — lifecycle do TTS nativo (2026-09-11)

1. Reproduzida janela de lifecycle: `TextToSpeech.onInit()` pode chegar depois de `MainActivity.onDestroy()`/`TtsBridge.shutdown()` e voltar a marcar `ready=true` para um engine já encerrado.
2. Adicionados `closed` idempotente e `lifecycleLock`, compartilhado entre `onInit()` e `shutdown()`.
3. `shutdown()` marca indisponível antes de encerrar o engine e não executa duas vezes.
4. `speak()` recusa bridge fechado e o runnable na UI revalida `closed` antes de chamar `stop/setSpeechRate/speak`; `stop()` segue a mesma proteção.
5. Guard novo `tests/tts-lifecycle-r24.test.mjs`: **4/4 PASS**; foco TTS/bridges: **22/22 PASS**.
6. Regressão integral: **558/558 PASS, 0 falhas**.
7. Stress canônico: **6/6 PASS**; gate Java PASS. Verifier consolidado: node **558/558**, stress **6/6**, JS/ESM **54**, Java **5**, JSON **32**, XML **2**, secrets **0**, APK/AAB **0**, Gradle Wrapper PASS.
8. Gate Android continua `BLOCKED_EXTERNAL`.

### Estado canônico após promoção do Bloco 24

`SOURCE_GREEN / EOTE_CORE_RUNTIME_GREEN / RAG_EOTE_GREEN / R46_PROJECTION_EOTE_GREEN / R46_LIVE_REFRESH_GREEN / GEMINI_SCENE_IMAGE_CLEAR_RACE_GUARDED / IMAGE_CACHE_CLEAR_RACE_GUARDED / NATIVE_IMAGE_READ_CONSISTENCY_GUARDED / TTS_LIFECYCLE_GUARDED / BACKUP_SNAPSHOT_REFRESH_GUARDED / NATIVE_BRIDGES_GREEN / CLEAN_RECOVERY_VERIFIER_GREEN / BLOCK24_FULL_REGRESSION_558_GREEN / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`


## Bloco automático 25 — publicação do JSON no MediaStore (2026-09-11)

1. Reproduzido falso sucesso potencial em Android Q+: após escrever o JSON com `IS_PENDING=1`, o retorno de `ContentResolver.update(... IS_PENDING=0)` era ignorado.
2. O bridge agora exige `published == 1` antes de retornar `ok:true`.
3. Escrita e publicação ficam no mesmo bloco protegido; qualquer exceção ou publicação sem efeito remove o `Uri` pendente antes de propagar a falha.
4. Evita arquivo invisível/orfão no MediaStore e impede a UI de afirmar que salvou quando o Android não publicou.
5. Guard novo `tests/filebridge-mediastore-publish-r25.test.mjs`: **3/3 PASS**; foco FileBridge/bridges: **21/21 PASS**.
6. Regressão integral: **561/561 PASS, 0 falhas**.
7. Stress canônico: **6/6 PASS**; gate Java PASS. Verifier consolidado: node **561/561**, stress **6/6**, JS/ESM **54**, Java **5**, JSON **33**, XML **2**, secrets **0**, APK/AAB **0**, Gradle Wrapper PASS.
8. Gate Android continua `BLOCKED_EXTERNAL`.

### Estado canônico após promoção do Bloco 25

`SOURCE_GREEN / EOTE_CORE_RUNTIME_GREEN / RAG_EOTE_GREEN / R46_LIVE_REFRESH_GREEN / GEMINI_SCENE_IMAGE_CLEAR_RACE_GUARDED / IMAGE_CACHE_CLEAR_RACE_GUARDED / NATIVE_IMAGE_READ_CONSISTENCY_GUARDED / TTS_LIFECYCLE_GUARDED / FILEBRIDGE_MEDIASTORE_PUBLISH_GUARDED / NATIVE_BRIDGES_GREEN / CLEAN_RECOVERY_VERIFIER_GREEN / BLOCK25_FULL_REGRESSION_561_GREEN / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`


## Bloco automático 27 — Core EotE real: especializações adicionais + raridade (2026-09-12)

1. O PDF real `EotE Core Rulebook.pdf` passou a ser autoridade primária; matriz/datasets antigos permanecem evidência secundária.
2. A divergência 557↔561 do ZIP de handoff foi explicada: faltava somente `tests/image-cache-clear-race-r21.test.mjs`, com 4 casos; o histórico 561/561 do Bloco 25 estava correto.
3. Implementada `purchaseSpecialization`: não há limite de especializações; custo dentro da carreira = 10 × total após compra; fora da carreira = mesmo custo +10 PE.
4. A nova especialização adiciona suas career skills sem ranks gratuitos e libera a respectiva árvore; a árvore inicial continua disponível.
5. `talents.mjs` passou a resolver e comprar talentos em qualquer especialização possuída, mantendo compatibilidade com a árvore inicial.
6. Raridade/availability e mercado negro deixam de ser gap: tabela 0–10+, upgrades acima de 10, modificadores de localização explícitos, Negociação para disponibilidade legal e Vida nas Ruas para restritos são fundamentados no Core real.
7. `rules_matrix.json`/RAG ganharam `SW-EOTE-SPECIALIZATION-PURCHASE-001`, `SW-EOTE-RARITY-AVAILABILITY-001` e `SW-EOTE-BLACK-MARKET-001`; corpus agora possui 27 entradas auditadas.
8. AoR continua fora da autoridade mecânica ativa.
9. Regressão integral: **569/569 PASS, 0 falhas**. Stress canônico: **6/6 PASS**. Verifier: JS/ESM 54, Java 5, JSON 25, XML 2, secrets 0, APK/AAB 0, Gradle Wrapper PASS.
10. Força continua deliberadamente `fail-closed`: agora a fonte Core existe, mas a implementação local ainda precisa ser revalidada antes de promoção.

### Estado canônico após promoção do Bloco 27

`SOURCE_GREEN / EOTE_CORE_REAL_SOURCE_GROUNDED / ADDITIONAL_SPECIALIZATIONS_GREEN / RARITY_AVAILABILITY_GREEN / RAG_EOTE_27_GREEN / BLOCK27_FULL_REGRESSION_569_GREEN / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`

Próxima ação: revalidar e corrigir o subsistema de Força diretamente contra o Core EotE; depois seguir a matriz exaustiva Core + suplementos disponíveis.


## Bloco automático 28 — Força Core EotE + alcance pela R46 (2026-09-12)

1. `EotE Core Rulebook.pdf` foi usado como autoridade primária para Force die/Force Rating, Destiny/Tensão, efeitos contínuos, Force Sensitive Exile e os três poderes Core.
2. `Force Sensitive Exile` é especialização universal: custo 10 × total após compra, sem sobretaxa de fora da carreira; droides são bloqueados; a compra concede Force Rating 1 se ainda não houver.
3. Árvore oficial do Exilado implementada com 20 nós e conexões visuais reais. Corrigidos atalhos falsos inicialmente detectados sob Insight/Forager antes da promoção.
4. Dado da Força: 12 faces oficiais; dados comprometidos deixam de ficar disponíveis; uso de resultados do lado oposto exige Destiny apropriado e causa Tensão por ponto usado.
5. Poderes Core `Sense`, `Influence` e `Move`: custo básico 10 PE, upgrades/conexões/custos oficiais e efeitos estruturados, incluindo pensamentos/emocional, efeitos contínuos, influência mental/social e Move com Strength/Range/Magnitude/Hurl.
6. O contrato R46 ↔ Barbara foi ampliado de 24 para 37 métodos, expondo especializações, árvores/talentos e Força sem alterar layout. `uiBridge.bundle.js` foi regenerado com 46 módulos.
7. `rules_matrix.json`/RAG ganharam 7 entradas oficiais de Força e passaram de 27 para 34 documentos auditados. O antigo `EOTE_FORCE_AUTHORITY_GAP` foi removido somente após a implementação passar.
8. Foco combinado: 40/40 PASS. Regressão integral: **589/589 PASS, 0 falhas**. Stress canônico: **6/6 PASS**.
9. Verifier consolidado: node **589/589**, JS/ESM **56**, Java **5**, JSON **26**, XML **2**, secrets **0**, APK/AAB **0**, Gradle Wrapper PASS.
10. Android físico continua `BLOCKED_EXTERNAL` por SDK/ADB/sdkmanager ausentes.

### Estado canônico após promoção do Bloco 28

`SOURCE_GREEN / EOTE_CORE_REAL_SOURCE_GROUNDED / ADDITIONAL_SPECIALIZATIONS_GREEN / RARITY_AVAILABILITY_GREEN / FORCE_CORE_GREEN / FORCE_R46_BRIDGE_GREEN / RAG_EOTE_34_GREEN / BLOCK28_FULL_REGRESSION_589_GREEN / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`

Próxima ação: continuar a auditoria exaustiva Core + suplementos presentes, implementando o próximo gap mecânico comprovado; não usar RAG como substituto de mecânica codificada.

## Bloco 29 — saúde, Critical Injuries e recuperação Core (promovido)
- tabela d100 completa, +10 por Critical Injury prévio, Wounds limitados a 2× threshold;
- Stimpacks 5→4→3→2→1→0; Medicine/Mechanics, autotratamento, bacta/oil bath e recuperação pós-encontro;
- checkpoint reproduzível: 592/592 PASS + 6/6 stress.

## Etapa 30 — Core sistêmico (promovida, 2026-09-13)
- Encumbrance/carga, levantamento, armadura vestida, mochila/cinto e penalidades por excesso integrados ao fluxo real;
- Fear checks e estados staggered/immobilized/disoriented integrados;
- Destiny inicial por sessão, flips e upgrades de pools integrados;
- Obligation rolada no início de sessão, penalties/doubles e bloqueio de gasto de XP acima de 100;
- bridge R46: 45 métodos; Motor Barbara: 51 módulos; RAG/matriz: 43 regras/políticas auditadas;
- regressão integral: 638/638 PASS; stress canônico: 6/6 PASS; Android físico permanece gate externo.
- verifier consolidado: JS/ESM 62, Java 5, JSON 25, XML 2, secrets 0, APK/AAB 0, Gradle Wrapper PASS; Android SDK/ADB/sdkmanager bloqueados externamente.
- estado: SOURCE_GREEN / EOTE_CORE_SYSTEMIC_GREEN / RAG_EOTE_43_GREEN / BLOCK30_FULL_REGRESSION_638_GREEN / REAL_ANDROID_SDK_DEVICE_GATE_PENDING.

## BLOCO 34 — ECONOMIA GENÉRICA DO SANDBOX — PROMOVIDO (2026-09-14)

1. O piso do Bloco 33 foi preservado: MIXED, sandbox 6 facções / 36 NPCs / 12 locais / 6 clocks / 12 oportunidades e R46 congelada.
2. Implementado módulo de economia/ownership persistente para armas, armaduras, gear e veículos.
3. Fluxos fechados: compra, recompensa, saque, presente/roubo, perda, dano, reparo e venda.
4. Separação estrutural mantida entre `visual`, `profile`, `availability`, `ownership` e `state`; campos mecânicos ausentes falham fechado, inclusive raridade/preço veicular nulos.
5. Compatibilidade do fluxo antigo de armas mantida; aquisição genérica usa `kind + itemId`.
6. Motor Barbara regenerado e confirmado com **56 módulos**. O único guard quebrado durante a transição ainda esperava `modules:55`; foi atualizado depois de confirmar o grafo real.
7. RAG/matriz passaram a **49/49 TESTADO**; novas entradas de economia/sandbox/misto são políticas locais explícitas, sem declarar Duty/AoR como autoridade EotE.
8. Foco R34: **26/26 PASS**. Lote estrutural crítico pós-reconstrução: **23/23 PASS**.
9. Regressão integral final via verificador: **703/703 PASS, 0 falhas**.
10. Stress canônico: **6/6 PASS**, incluindo as suítes de 33 sessões.
10a. Verificador consolidado final: JS/ESM **65**, Java **5**, JSON **25**, XML **2**, secrets **0**, APK/AAB **0**, Gradle Wrapper PASS.
11. O ZIP CORRIGIDO foi usado apenas como fonte estrutural `copy-if-missing`; SHA-256 conferido `38bb5e5f6e1ae19d63033bd69a328506cd81ebc90d1b43d2d12700aea99113a2`. Revisões posteriores foram sobrepostas e o bug histórico de `onBackPressed()` duplicado não retornou.
12. `gradlew`/`gradlew.bat` voltaram a delegar exclusivamente ao `gradle-wrapper.jar`; teste offline de distribuição válida/checksum inválido passou.
13. Shell R46 não foi redesenhada. Nenhum ZIP/APK/AAB intermediário foi criado.
14. Android físico permanece `BLOCKED_EXTERNAL` até existir SDK/ADB/sdkmanager no host.

### Estado canônico após promoção do Bloco 34

`SOURCE_GREEN / EOTE_CORE_REAL_SOURCE_GROUNDED / MIXED_SANDBOX_GREEN / SANDBOX_ECONOMY_GREEN / RAG_49_TESTADO_GREEN / BARBARA_56_MODULES_GREEN / R46_FROZEN / BLOCK34_FULL_REGRESSION_703_GREEN / STRESS_6_OF_6_GREEN / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`

Próxima ação: ampliar catálogo mecânico por fonte real, priorizando veículos/equipamentos usados em campanha aberta; não reabrir R33/R46 e não transformar RAG em substituto de regra codificada.



## BLOCO 35 — CATÁLOGO VEICULAR CORE EotE — PROMOVIDO (2026-09-14)

1. O piso R34 foi preservado integralmente: sandbox, economia genérica, R46 congelada, Barbara 56 módulos e fail-closed para ficha/preço/raridade ausentes.
2. `EotE Core Rulebook.pdf` foi usado como autoridade primária para os novos perfis; não foram inferidos campos ausentes.
3. Catálogo econômico veicular Core EotE ampliado de 3 para **15 perfis ativos completos**: X-34, Digger Crawler, Personnel Carrier, AT-PT, AT-EST, CloakShape, JM-5000 JumpMaster, Firespray, Lambda T-4A, TIE/ln, BTL Y-Wing, Z-95-AF4, GAT-12h Skipray, Wayfarer e YT-1300.
4. TIE/ln e Lambda T-4A passam a usar autoridade EotE Core. O X-Wing legado permanece referência cruzada e não entra na economia sem preço/raridade EotE comprovados.
5. RAG/matriz passaram a **50/50 TESTADO**; Motor Barbara permanece **56 módulos**.
6. Foco de catálogo R35: **21/21 PASS**.
7. Regressão integral isolada por arquivo: **724/724 PASS, 0 falhas**.
8. Stress canônico: **6/6 PASS**, incluindo as suítes de 33 sessões com reaberturas, histórico causal, planos de facções e adversário persistente.
9. Shell R46 não foi redesenhada. Nenhum ZIP/APK/AAB intermediário foi criado.
10. Android físico continua `BLOCKED_EXTERNAL` por ausência de SDK/ADB/sdkmanager.

### Estado canônico após promoção do Bloco 35

`SOURCE_GREEN / EOTE_CORE_REAL_SOURCE_GROUNDED / MIXED_SANDBOX_GREEN / SANDBOX_ECONOMY_GREEN / EOTE_CORE_VEHICLE_CATALOG_15_GREEN / RAG_50_TESTADO_GREEN / BARBARA_56_MODULES_GREEN / R46_FROZEN / BLOCK35_FULL_REGRESSION_724_GREEN / STRESS_6_OF_6_GREEN / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`

Próxima ação: ampliar equipamentos/veículos dos suplementos EotE por fonte real, mantendo conteúdo repetitivo como dados + proveniência e codificando somente exceções mecânicas novas.


## BLOCO 36 — CATÁLOGO VEICULAR FLY CASUAL — PROMOVIDO (2026-09-14)

1. `Fly Casual` foi usado como fonte primária EotE suplementar para completar o catálogo inicial de veículos/naves.
2. Foram adicionados 10 perfis completos: Alpha-class Xg-1 Star Wing, VT-49 Decimator, WUD-500, Starlight-class Light Freighter, YKL-37R Nova Courier, GX1 Short Hauler, Baudo-class Star Yacht, Gozanti-class Armed Transport, HWK-1000 e YT-2000.
3. Catálogo veicular ativo total: **25 perfis mecanicamente completos**, atingindo o alvo inicial de 20–30.
4. Economia continua usando preço, raridade/restrição e ficha comprovados; X-Wing permanece fail-closed quando faltam dados EotE suficientes para compra.
5. Regressão R36 fechada: **738/738 PASS + 6/6 stress**.

## BLOCO 37 — DUTY AOR GUARDADO + CATÁLOGO PESSOAL FINAL — PROMOVIDO (2026-09-14)

1. Foram restauradas **somente duas autoridades AoR auditadas** no RAG: `SW-AOR-CHAR-DUTY-002` (Duty inicial/reduções, SWA02 pp. 46–50) e `SW-AOR-BASE-DUTY-CONTRIBUTION-001` (estrutura Base/Duty/Contribution).
2. O runtime de Duty que não possui página primária preservada permanece rotulado como política local testada; Barbara não pode apresentá-lo como regra editorial oficial.
3. Guards de cruzamento de linha permitem exatamente essas duas entradas AoR e bloqueiam promoção de qualquer outro conteúdo AoR como autoridade ativa.
4. Catálogo pessoal inicial fechado em **60 itens**: 31 armas, 7 armaduras e 22 equipamentos. O 60º item é `Appraiser's Eye` / **Olho do Avaliador**, `Fly Casual`, Table 2-4: Gear, preço 700, raridade 7.
5. Catálogo veicular permanece em **25**; Motor Barbara permanece em **56 módulos**; RAG/matriz em **54/54 TESTADO**.
6. Regressão comum pós-catálogo final: **736/736 PASS**. Stress R37: **6/6 PASS**, com suítes de 33 sessões. Total canônico: **742/742 PASS, 0 falhas**.
7. Gates estáticos finais: **218 JS/ESM**, **5 Java**, **27 JSON**, **2 XML**, **0 secrets**, **0 APK/AAB**.
8. Android físico continua `BLOCKED_EXTERNAL` somente por ausência de SDK/ADB/sdkmanager neste host.

### Estado canônico final R37

`SOURCE_GREEN / EOTE_AOR_MIXED_SANDBOX_GREEN / DUTY_AOR_PROVENANCE_GUARDED / SANDBOX_ECONOMY_GREEN / PERSONAL_CATALOG_60_GREEN / EOTE_VEHICLE_CATALOG_25_GREEN / RAG_54_TESTADO_GREEN / BARBARA_56_MODULES_GREEN / R46_FROZEN / BLOCK37_FULL_REGRESSION_742_GREEN / STRESS_6_OF_6_GREEN / FINAL_ANDROID_STUDIO_ZIP_READY / REAL_ANDROID_SDK_DEVICE_GATE_PENDING`
