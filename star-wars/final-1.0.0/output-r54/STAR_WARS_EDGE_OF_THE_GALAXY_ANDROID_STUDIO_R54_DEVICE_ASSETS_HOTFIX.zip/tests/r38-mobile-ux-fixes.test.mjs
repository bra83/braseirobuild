import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=p=>fs.readFileSync(p,'utf8');
const runtime=read('app/src/main/assets/vtt/r46/final-runtime.js');
const css=read('app/src/main/assets/vtt/r46/r46.css')+'\n'+read('app/src/main/assets/vtt/r46/final-runtime.css');
const controller=read('app/src/main/assets/vtt/js/core/controller.mjs');
const ui=read('app/src/main/assets/vtt/js/core/uiBridge.mjs');
const bundle=read('app/src/main/assets/vtt/js/core/uiBridge.bundle.js');
const shell=read('app/src/main/assets/vtt/r46/r46-shell.bundle.js');
const main=read('app/src/main/java/com/braseiro/starwarsedge/MainActivity.java');
const manifest=read('app/src/main/AndroidManifest.xml');
const gemini=read('app/src/main/java/com/braseiro/starwarsedge/GeminiBridge.java');

test('R38: início do mundo não exige texto livre e oferece lista, mapa e aleatório',()=>{
  assert.match(runtime,/data-start-mode="list"/);
  assert.match(runtime,/data-start-mode="map"/);
  assert.match(runtime,/data-start-mode="random"/);
  assert.match(runtime,/assets\/maps\/galaxy_map\.jpg/);
  assert.doesNotMatch(runtime,/id="sandbox-start"[^>]*<input|id="sandbox-start"/);
});

test('R38: existe gate explícito INICIAR AVENTURA ligado ao motor',()=>{
  assert.match(runtime,/INICIAR AVENTURA/);
  assert.match(runtime,/bridgeResult\('startLivingAdventure'/);
  assert.match(controller,/startLivingAdventure\(/);
  assert.match(ui,/startLivingAdventure\(/);
  assert.match(bundle,/startLivingAdventure\(/);
});

test('R38: cena oferece geração Gemini diretamente e modelos configuráveis',()=>{
  assert.match(runtime,/GERAR ILUSTRAÇÃO/);
  assert.match(runtime,/generateSceneImage/);
  assert.match(runtime,/SALVAR MODELOS/);
  assert.match(gemini,/configureModels\(/);
  assert.match(gemini,/DEFAULT_MASTER_MODEL/);
  assert.match(gemini,/DEFAULT_IMAGE_MODEL/);
  assert.match(gemini,/DEFAULT_TTS_MODEL/);
});

test('R38: Gemini TTS é funcional com Android TTS como fallback',()=>{
  assert.match(gemini,/speakTts\(/);
  assert.match(gemini,/response_format/);
  assert.match(gemini,/speech_config/);
  assert.match(runtime,/Gemini TTS/);
  assert.match(runtime,/Android TTS/);
});

test('R38: personagem vazio oferece geração completa aleatória e import JSON',()=>{
  assert.match(runtime,/GERAR FICHA ALEATÓRIA/);
  assert.match(runtime,/IMPORTAR \.JSON/);
  assert.match(runtime,/generateRandomCharacter/);
  assert.match(runtime,/importCharacterJson/);
  assert.match(shell,/Exportar JSON/);
});

test('R38: Biblioteca é descoberta por utilidade e atalho de Ajustes',()=>{
  assert.match(shell,/label: 'BIBLIOTECA'/);
  assert.match(runtime,/>BIBLIOTECA<\/button>/);
  assert.match(shell,/Biblioteca \/ PDFs/);
});

test('R38: Android respeita insets e teclado sem sobrepor UI',()=>{
  assert.match(main,/setOnApplyWindowInsetsListener/);
  assert.match(main,/getSystemWindowInsetTop/);
  assert.match(main,/getSystemWindowInsetBottom/);
  assert.match(manifest,/windowSoftInputMode="adjustResize"/);
  assert.match(css,/PERSONAGEM|font-size:clamp\(/);
});

test('R38: launcher profissional aprovado está configurado',()=>{
  assert.match(manifest,/android:icon="@mipmap\/ic_launcher"/);
  assert.match(manifest,/android:roundIcon="@mipmap\/ic_launcher_round"/);
  for(const d of ['mdpi','hdpi','xhdpi','xxhdpi','xxxhdpi']) assert.ok(fs.existsSync(`app/src/main/res/mipmap-${d}/ic_launcher.png`));
});

import { GameController } from '../app/src/main/assets/vtt/js/core/controller.mjs';
import { LocalStorageRepository } from '../app/src/main/assets/vtt/js/core/storage.mjs';
class MemoryStorageR38 { constructor(){this.m=new Map()} getItem(k){return this.m.has(k)?this.m.get(k):null} setItem(k,v){this.m.set(k,String(v))} removeItem(k){this.m.delete(k)} }

test('R38: startLivingAdventure produz narração e ações sem exigir prompt do jogador',()=>{
  const g=new GameController(new LocalStorageRepository(new MemoryStorageR38(),'r38-start'));
  g.loadStarterCharacter('zal');
  g.initializeLivingSandbox({startingPoint:'Mos Eisley · Tatooine',regionLabel:'Tatooine'});
  const result=g.startLivingAdventure({rng:()=>0.99});
  assert.equal(g.state.session.status,'ativa');
  assert.ok(String(g.state.scene.narration||'').length>30);
  assert.ok(Array.isArray(g.state.master.suggestedActions));
  assert.ok(g.state.master.suggestedActions.length>=3);
  assert.match(g.state.scene.narration,/Nada obriga você|campanha começa/i);
  assert.ok(result.opening.ready);
});

test('R38: chave de imagem da cena é compatível entre shell, botão direto e host Android',()=>{
  assert.match(shell,/stableGeminiSceneKey/);
  assert.match(shell,/scene_\$\{\(h >>> 0\)\.toString\(16\)\.padStart\(8, '0'\)\}/);
  assert.match(shell,/scene\.narration \?\? scene\.narrative/);
  assert.match(runtime,/currentSceneKey\(\)/);
  assert.match(runtime,/sceneKeyFor\(scene\?\.id\?\?scene\?\.sceneId\?\?scene\?\.title\?\?'Cena'\)/);
  assert.match(gemini,/scene_\[0-9a-f\]\{8\}/);
});
