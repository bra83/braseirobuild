# LEIA PRIMEIRO — STAR WARS EDGE OF THE GALAXY FINAL 1.0.0

Esta pasta é a entrega-fonte final do projeto Android Studio.

- Abra a raiz no Android Studio.
- JDK 17 + Android SDK 36.
- Execute o módulo `app`.
- Não substitua a shell R46.
- Não transforme combate em aba principal.
- Não aplique regras diretamente na UI: mutações passam pelo Motor Barbara.
- A chave Gemini é configurada dentro do app e protegida pelo Android Keystore.
- O projeto não contém APK/AAB.

Baseline ativa: modo padrão **Edge of the Empire (`EOTE_CORE`) + Obligation**, com campanhas **EOTE / AOR / MIXED** selecionáveis. Duty/Contribution ficam ativos apenas em AOR/MIXED e são separados por proveniência; somente o subconjunto AoR auditado é tratado como autoridade oficial.

Validação interna final: **742/742 PASS** + **6/6 stress PASS**; cada suíte de stress cobre 33 sessões simuladas conforme o subsistema. Catálogo inicial: **60 itens pessoais + 25 veículos/naves**.

Para retomar trabalho, leia primeiro `RETOMADA_ATUAL.md`; não reextraia o ZIP CORRIGIDO por cima do código atual sem reaplicar o delta registrado.

A única homologação que não pôde ser feita no ambiente de geração foi compilar/instalar em Android real ou emulador, porque esse runtime não fornece Android SDK/ADB.
