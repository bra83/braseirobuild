package com.braseiro.dnd5e;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;
import static org.junit.Assert.*;

/** Settings and story-to-TTS boundary must be deterministic and non-mutating. */
public final class GeminiVoiceAndNarrativeQualityTest {
    @Test public void androidRatePersistsInSafeLimits() {
        assertEquals(60,AndroidTtsBackend.clampSpeedPercent(-10));
        assertEquals(100,AndroidTtsBackend.clampSpeedPercent(100));
        assertEquals(160,AndroidTtsBackend.clampSpeedPercent(800));
        assertEquals(1.25f,AndroidTtsBackend.adjustedRate(1.0f,125),.0001f);
    }
    @Test public void characterContrastIsStableAndDoesNotAlterNarrator() {
        String narrator="Charon";
        assertEquals(narrator,GeminiTtsPerformance.voice(narrator,"Kore","Narrador",100));
        assertEquals(narrator,GeminiTtsPerformance.voice(narrator,"Kore","Estilhaço",0));
        assertEquals(narrator,GeminiTtsPerformance.voice(narrator,"Kore","Estilhaço",25));
        String first=GeminiTtsPerformance.voice(narrator,"Kore","Estilhaço",75);
        assertNotEquals(narrator,first);
        assertEquals(first,GeminiTtsPerformance.voice(narrator,"Kore","Estilhaço",75));
        assertTrue(GeminiTtsPerformance.direction("Estilhaço",75).contains("Pronounced character differentiation"));
        assertEquals("",GeminiTtsPerformance.direction("Narrador",100));
    }
    @Test public void tagsOnlyInSynthesizedCopyAndOnlyForExpressedPause() {
        String narration="Um estudante hesita... e responde.";
        assertEquals("Um estudante hesita... <short pause> e responde.",
                GeminiTtsPerformance.taggedTranscript(narration));
        assertEquals("Um estudante hesita... e responde.",narration);
        assertEquals("Uma manhã clara.",GeminiTtsPerformance.taggedTranscript("Uma manhã clara."));
    }
    @Test public void staleDebtDoesNotGenerateUnrelatedGardenChoices() throws Exception {
        String narration="No Jardim dos Livros, três arbustos despertados ajustam as raízes "
            +"e observam estudantes passando ao longo dos canteiros.";
        JSONObject stale=new JSONObject()
            .put("present_npcs",new JSONArray().put(new JSONObject().put("name","Estilhaço")))
            .put("objective","cobrar pagamento a Estilhaço");
        JSONArray previous=new JSONArray()
            .put(new JSONObject().put("label","EXIGIR PROVA DA COBRANÇA")
                .put("action","Exigir prova da cobrança de Estilhaço."));
        JSONArray actual=SceneOptionDiversifier.ensureAlways(previous,new JSONArray(),
                narration,"Caminho pelo jardim",stale,1);
        assertEquals(4,actual.length());
        assertTrue(StoryMomentumAction.isRequest(actual.getJSONObject(0).optString("action")));
        assertTrue(actual.toString().contains("ARBUSTOS"));
        assertFalse(actual.toString().contains("COBRANÇA"));
        assertFalse(actual.toString().contains("ESTILHAÇO"));
    }
    @Test public void socialNarratorRequiresDialogueWithoutWritingHeroSpeech() {
        String instruction=HumanMasterNarrativeProfile.systemInstruction();
        assertTrue(instruction.contains("2 a 5 falas"));
        assertTrue(instruction.contains("não faça o protagonista dizer"));
    }
    @Test public void narrativeDirectionEncouragesMasterTablePresenceAndSensoryDetails() {
        String instruction=HumanMasterNarrativeProfile.systemInstruction();
        assertTrue(instruction.contains("VOZ E DRAMATIZAÇÃO DO MESTRE DE MESA (PILAR DE IMERSÃO VIVA)"));
        assertTrue(instruction.contains("Vocês veem..."));
        assertTrue(instruction.contains("postura, sombras e oportunidades táticas"));
        assertTrue(instruction.contains("guarda está parado distraído"));
        String turn=HumanMasterNarrativeProfile.turnInstruction("Investigo a sala",true);
        assertTrue(turn.contains("VOZ DE MESTRE"));
        assertTrue(turn.contains("Vocês veem..."));
    }
    @Test public void narrativeDirectionEncouragesThreeContextualRpgActionsPlusOneMomentumAction() {
        String instruction=HumanMasterNarrativeProfile.systemInstruction();
        assertTrue(instruction.contains("OBSERVAR / PERCEBER"));
        assertTrue(instruction.contains("INVESTIGAR / EXPLORAR"));
        assertTrue(instruction.contains("AGIR / CONVERSAR"));
        assertTrue(instruction.contains("ação que faz o jogo andar"));
        String turn=HumanMasterNarrativeProfile.turnInstruction("Aproximo-me do portão",true);
        assertTrue(turn.contains("SUGESTÕES DA CENA"));
        assertTrue(turn.contains("OBSERVAR"));
        assertTrue(turn.contains("INVESTIGAR"));
        assertTrue(turn.contains("AGIR ou CONVERSAR"));
        assertTrue(turn.contains("ação que faz o jogo andar"));
    }
    @Test public void offlineMasterGeneratesThreeClassicRpgActionSlots() throws Exception {
        OfflineMasterEngine engine=new OfflineMasterEngine();
        JSONObject bus=new JSONObject();
        JSONObject scene=new JSONObject().put("location","Portão de Baldur").put("objective","entrar na cidade baixa");
        scene.put("present_npcs_json",new JSONArray().put(new JSONObject().put("name","Dara")).toString());
        JSONObject context=new JSONObject().put("scene",scene).put("game_bus",bus);
        MasterOrchestrator.Plan plan=MasterOrchestrator.Plan.forTest("continuation",context.toString(),"continuation","PLAYER_ACTION");
        JSONObject answer=engine.generate("Narrador","Olho a entrada",plan,new java.util.ArrayList<JSONObject>());
        JSONArray options=answer.optJSONArray("options");
        assertNotNull(options);
        assertEquals(3,options.length());
        assertEquals("OBSERVAR",options.getJSONObject(0).optString("action_type"));
        assertEquals("INVESTIGAR",options.getJSONObject(1).optString("action_type"));
        assertEquals("CONVERSAR",options.getJSONObject(2).optString("action_type"));
        assertTrue(options.getJSONObject(0).optString("label").startsWith("OBSERVAR"));
        assertTrue(options.getJSONObject(1).optString("label").startsWith("INVESTIGAR"));
        assertTrue(options.getJSONObject(2).optString("label").startsWith("CONVERSAR"));
    }
}
