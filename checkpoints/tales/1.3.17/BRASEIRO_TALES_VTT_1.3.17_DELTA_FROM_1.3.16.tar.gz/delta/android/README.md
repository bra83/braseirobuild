# BRASEIRO TALES VTT — Android Studio Source 1.3.17

Projeto Android/Jetpack Compose mobile-first (415×915) para dois perfis jogáveis e mecanicamente separados:

- **Tales from the Loop — Kids**
- **Things from the Flood — Teens**

## Estado deste source

- roteamento real Tales/Kids ↔ Flood/Teens em CENA, personagem, GRUPO, MISTÉRIO, MAPA, MOCHILA, TROUBLE, CLÍMAX e ENCERRAMENTO;
- criação manual completa para os 8 Types Tales e os 10 Types Flood, além de criação rápida válida;
- regras mecânicas locais, sem RAG como autoridade: pools, Conditions/Broken, Push, Sorte/Orgulho, Shame/Scars/Friction, Items, Bonus Effects, Lead, Extended Trouble, XP e Change;
- firewall Tales/Flood também no Motor Barbara, ajuda global, rotas e import/export de ficha;
- Items normais +1..+3 e Iconic Item +2 persistentes durante o Mistério, com tratamento de Change;
- mapa interativo com pinos, seleção, viagem, filtros, bloqueios, importância, notas e rotas persistentes;
- início de aventura e viagem aplicados localmente antes de qualquer chamada ao Gemini;
- mundo livre com memória privada local de NPCs, fatos e ameaças;
- TTS da narrativa visível com chunks e fallback automático Gemini → TTS Android;
- imagem de cena para ambos os perfis, vinculada à cena/perfil corretos;
- save/load local e backup portátil unificado v3 com Tales, Flood, mapas, perfil ativo, memória privada, estado de aventura e imagens de cena;
- import/export JSON de Kid/Teen, incluindo inventário; Teen removido corretamente aos 20 anos mantém round-trip da ficha;
- Biblioteca/RAG permanece consulta/contexto, nunca autoridade mecânica.

## Validação local final

No estado de fechamento 1.3.17 foram executados:

- fechamento local de TGUF/OFM com ruleIds determinísticos e sem autoridade numérica do RAG;

- Tales engine: **113/113 PASS**;
- Flood engine: **46/46 PASS**;
- fechamento cruzado: **17/17 PASS**;
- criação manual: **108 casos PASS** (8 Types Tales + 10 Types Flood);
- regressão comparativa: **33/33 PASS**;
- sessões finais: **33 Tales + 33 Flood PASS**, 594 verificações de ciclo;
- reducer fuzz: **250.000 eventos PASS**, 0 exceções;
- auditoria estática: PASS;
- auditoria do firewall Tales/Flood: PASS.

Os relatórios ficam em `docs/`.

## Abrir no Android Studio

1. Extraia o ZIP final.
2. Abra a pasta `android/` no Android Studio.
3. Faça o sync das dependências no seu ambiente Android.
4. Configure a chave Gemini pelo MENU (ou por `.env`, localmente).
5. Para RAG: MENU → BIBLIOTECA & RAG → ADICIONAR PDFs.

## Limite externo deste ambiente

Gradle/APK e aparelho/emulador **não são gates deste runtime**, conforme definido durante o fechamento. Portanto este pacote não afirma prova física de:

- lançamento no aparelho;
- áudio TTS realmente audível;
- toque físico em cada pino;
- chamadas Gemini reais com a chave do usuário.

Esses itens são smoke externo e não alteram o fechamento mecânico/source-level. Nenhuma chave API real é incluída no ZIP.

## Autoridade

`docs/FINAL_CLOSURE_1.3.17.md` e `docs/HANDOFF_FINAL_1.3.17.md` registram o estado congelado e o que deve ou não ser reaberto.
